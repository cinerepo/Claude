#!/bin/bash
# Stops the running capture without processing it: no post snapshot, no
# summary, no package. The folder and everything recorded so far are kept.
# Use Stop-CinesysCapture.sh for a normal stop.
#
#     sudo bash Cancel-CinesysCapture.sh

CINESYS_ROOT=$(cd "$(dirname "$0")" && pwd)
source "$CINESYS_ROOT/lib/common.sh"

cs_read_state || { echo "No capture is running."; exit 0; }
source "$CAP/Raw/config.sh"
if ! cs_is_root && [[ $ALLOW_NONROOT != yes ]]; then cs_die "Run with sudo:  sudo bash $0"; fi
source "$CINESYS_ROOT/lib/manifest.sh"

cs_log "Cancelling capture $CAP ..."
STOPPED=$(cs_now)
: > "$CAP/Raw/collector-status.tsv"
while IFS=$'\t' read -r name pid started out match; do
    if cs_pid_is "$pid" "$match"; then
        cs_stop_pid "$pid"
        printf '%s\t%s\t%s\n' "$name" Cancelled "$STOPPED" >> "$CAP/Raw/collector-status.tsv"
    else
        printf '%s\t%s\t\n' "$name" "Had already exited" >> "$CAP/Raw/collector-status.tsv"
    fi
done < <(tac "$CAP/Raw/collectors.tsv")
cs_write_manifest Cancelled
if cs_is_root && [[ -n $RUN_USER && $RUN_USER != root ]]; then chown -R "$RUN_USER" "$CAP" 2>/dev/null; fi
rm -f "$CINESYS_STATE" "$CAP/Raw/stopping"
cs_log "Cancelled. Data recorded so far is kept in $CAP"
