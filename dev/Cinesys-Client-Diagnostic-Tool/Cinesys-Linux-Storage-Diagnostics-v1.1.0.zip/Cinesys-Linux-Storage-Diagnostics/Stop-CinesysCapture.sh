#!/bin/bash
# Stops the running capture, writes the post-capture snapshot, builds
# Cinesys-Performance.csv and Capture-Summary.txt, and packs the summary zip.
#
#     sudo bash Stop-CinesysCapture.sh
#     sudo bash Stop-CinesysCapture.sh --no-package

CINESYS_ROOT=$(cd "$(dirname "$0")" && pwd)
source "$CINESYS_ROOT/lib/common.sh"

PACKAGE=yes
AUTO_CAP=""
while (( $# )); do
    case $1 in
        --no-package) PACKAGE=no; shift ;;
        --auto) AUTO_CAP=$2; shift 2 ;;   # used by the automatic stop
        -h|--help) echo "Usage: sudo bash Stop-CinesysCapture.sh [--no-package]"; exit 0 ;;
        *) cs_die "Unknown option: $1" ;;
    esac
done

cs_read_state || cs_die "No capture is running (nothing recorded in $CINESYS_STATE)."
[[ -n $AUTO_CAP && $AUTO_CAP != "$CAP" ]] && exit 0
source "$CAP/Raw/config.sh"
if ! cs_is_root && [[ $ALLOW_NONROOT != yes ]]; then cs_die "Run with sudo:  sudo bash $0"; fi
[[ -f $CAP/Raw/stopping ]] && cs_die "This capture is already being stopped: $CAP"
echo $$ > "$CAP/Raw/stopping"

source "$CINESYS_ROOT/lib/detect.sh"
source "$CINESYS_ROOT/lib/snapshot.sh"
source "$CINESYS_ROOT/lib/manifest.sh"
[[ -n $AUTO_CAP ]] && cs_log "Automatic stop (time limit reached)."
cs_log "Stopping capture $CAP ..."

# ---------------------------------------------------------------------------
# Collectors, newest first
# ---------------------------------------------------------------------------
STOPPED=$(cs_now)
: > "$CAP/Raw/collector-status.tsv"
while IFS=$'\t' read -r name pid started out match; do
    if [[ -n $AUTO_CAP && $name == AutoStop ]]; then printf '%s\t%s\t%s\n' "$name" Finished "$STOPPED" >> "$CAP/Raw/collector-status.tsv"; continue; fi
    if cs_pid_is "$pid" "$match"; then
        cs_stop_pid "$pid"
        printf '%s\t%s\t%s\n' "$name" Stopped "$STOPPED" >> "$CAP/Raw/collector-status.tsv"
    else
        printf '%s\t%s\t\n' "$name" "Had already exited" >> "$CAP/Raw/collector-status.tsv"
        [[ $name == KeepAwake || $name == AutoStop ]] || cs_warn "$name was no longer running when the capture was stopped. See Raw/$name.log."
    fi
done < <(tac "$CAP/Raw/collectors.tsv")
cs_log "Collectors stopped."

# ---------------------------------------------------------------------------
# Post-capture state
# ---------------------------------------------------------------------------
cs_snapshot Post
cs_detect "$CAP/Storage-Post.txt"
printf '%s\n' "${CS_DET[@]}" > "$CAP/Raw/storage-post.txt"
cs_topology Post

# Kernel and storage-service log for the window, in the format the Windows
# analyzer reads (Storage-Events-*.csv)
cs_log "Writing Storage-Events-Kernel.csv ..."
logsrc=$CAP/Raw/kernel-log-stream.txt
if [[ ! -s $logsrc ]] && cs_have journalctl; then
    journalctl -k --since "$STARTED" --until "$STOPPED" -o short-iso-precise --no-pager > "$CAP/Raw/kernel-log-window.txt" 2>&1
    logsrc=$CAP/Raw/kernel-log-window.txt
fi
{
    echo 'TimeCreated,Provider,Id,Level,Message'
    awk -v re="$CS_KLOG_RE" '
        function q(s) { gsub(/"/, "\"\"", s); return "\"" s "\"" }
        # journalctl short-iso-precise: 2026-10-16T10:00:00.123456-05:00 host ident[pid]: message
        # dmesg --time-format iso:      2026-10-16T10:00:00,123456-05:00 message
        $1 ~ /^[0-9]{4}-[0-9]{2}-[0-9]{2}T/ {
            t = substr($1, 1, 10) " " substr($1, 12, 12); gsub(/,/, ".", t)
            if ($3 ~ /:$/) { prov = $3; sub(/\[.*/, "", prov); sub(/:$/, "", prov); first = 4 } else { prov = "kernel"; first = 2 }
            msg = ""; for (i = first; i <= NF; i++) msg = msg (i > first ? " " : "") $i
            lv = "Information"
            if (msg ~ /[Ee]rror|[Ff]ail|timed out|not responding|blocked for more than|[Aa]bort/) lv = "Error"
            else if (msg ~ /[Rr]eset|[Ll]ink is [Dd]own|[Ll]ink down|[Rr]econnect|[Tt]imeout|[Ww]arn/) lv = "Warning"
            print t "," q(prov) ",0," lv "," q(msg)
        }' "$logsrc" 2>/dev/null
} > "$CAP/Storage-Events-Kernel.csv"

# ---------------------------------------------------------------------------
# Cinesys-Performance.csv and Capture-Summary.txt
# ---------------------------------------------------------------------------
cs_log "Building Cinesys-Performance.csv ..."
if [[ -s $CAP/Raw/sampler.csv ]]; then
    # drop the epoch column (first field; header names never contain it)
    awk '{ print substr($0, index($0, ",") + 1) }' "$CAP/Raw/sampler.csv" > "$CAP/Cinesys-Performance.csv"
else
    cs_warn "The sampler recorded no data (Raw/sampler.csv is missing or empty). See Raw/Sampler.log."
fi

cs_log "Writing Capture-Summary.txt ..."
names=""; for k in "${!SERVER_NAME[@]}"; do names+="${SERVER_NAME[$k]}=$k;"; done
roles=""; for k in "${!TARGET_ROLE[@]}"; do roles+="$k=${TARGET_ROLE[$k]};"; done
{
    echo "CINESYS STORAGE DIAGNOSTICS FOR LINUX $CINESYS_VERSION - CAPTURE SUMMARY"
    echo "=================================================================="
    echo "Host:      $HOSTTAG ($(. /etc/os-release 2>/dev/null; echo "$PRETTY_NAME"), kernel $(uname -r))"
    echo "Capture:   $STARTED to $STOPPED${LABEL:+   Label: $LABEL}"
    echo "Folder:    $CAP"
    [[ $ALLOW_NONROOT == yes ]] && ! cs_is_root && echo "Mode:      test mode without sudo (packet capture and firewall rules not collected)"
    echo ""
    echo "COLLECTORS"
    echo "----------"
    while IFS=$'\t' read -r name st at; do printf '%-26s %s\n' "$name" "$st"; done < "$CAP/Raw/collector-status.tsv"
    if [[ -f $CAP/Raw/collector-notes.tsv ]]; then
        while IFS=$'\t' read -r name at st note; do printf '%-26s %s: %s\n' "$name" "$st" "$note"; done < "$CAP/Raw/collector-notes.tsv"
    fi
    echo ""
    echo "FINDINGS"
    echo "--------"
    if [[ -s $CAP/Raw/findings-pre.txt || -s $CAP/Raw/findings-post.txt ]]; then
        awk -F'|' 'FNR == NR { pre[$0] = 1; printf "%-5s %s\n", $1, $2; next } !($0 in pre) { printf "%-5s %s (seen after the capture)\n", $1, $2 }' \
            "$CAP/Raw/findings-pre.txt" "$CAP/Raw/findings-post.txt" 2>/dev/null
    else
        echo "(none)"
    fi
    echo ""
    if [[ -s $CAP/Cinesys-Performance.csv ]]; then
        nexis=$(grep -c '^NEXIS|' "$CAP/Raw/storage-pre.txt" 2>/dev/null)
        awk -v stalls="$CAP/Stalls.csv" -v mindrop=2 -v names="$names" -v roles="$roles" -v nexis="${nexis:-0}" -f "$CINESYS_ROOT/lib/summarize.awk" "$CAP/Cinesys-Performance.csv"
    fi
    echo "EVENTS"
    echo "------"
    ne=$(( $(wc -l < "$CAP/Storage-Events-Kernel.csv") - 1 ))
    echo "Kernel and storage-service log lines in the capture window: $ne (Storage-Events-Kernel.csv)"
    if (( ne > 0 )); then
        awk -F'"' 'NR > 1 { m = $4; gsub(/[0-9]+/, "#", m); c[$2 ": " m]++ } END { for (k in c) printf "%6d  %s\n", c[k], k }' "$CAP/Storage-Events-Kernel.csv" | sort -rn | head -10
    fi
    nchg=$(awk -F, 'NR > 1 && $4 != "\"(baseline)\""' "$CAP/Path-Health-Changes.csv" 2>/dev/null | wc -l)
    echo "Path changes (link, route, reachability, mounts, sessions): $nchg (Path-Health-Changes.csv)"
    awk -F, 'NR > 1 && $4 != "\"(baseline)\""' "$CAP/Path-Health-Changes.csv" 2>/dev/null | head -20 | sed 's/^/    /'
    echo ""
    big=$(ls "$CAP"/Raw/Packets-*.pcap* 2>/dev/null)
    if [[ -n $big ]]; then
        echo "LARGE FILES (not in the .summary.zip; New-CinesysPackage.sh --kind full includes them)"
        echo "-------------------------------------------------------------------------------------"
        for f in $big; do printf '%-36s %s\n' "${f#$CAP/}" "$(cs_bytes_h "$(stat -c %s "$f")")"; done
        echo ""
    fi
    echo "NEXT STEP"
    echo "---------"
    echo "Engineers: run Invoke-CinesysAnalysis.ps1 (Windows toolkit) on this folder"
    echo "together with the server's capture to line up both sides of each drop."
} > "$CAP/Capture-Summary.txt" 2>&1

cs_write_manifest Completed

# Captures are taken with sudo; hand the files to the user who ran it.
if cs_is_root && [[ -n $RUN_USER && $RUN_USER != root ]]; then chown -R "$RUN_USER" "$CAP" 2>/dev/null; fi
rm -f "$CINESYS_STATE" "$CAP/Raw/stopping"

echo ""
sed -n '/^FINDINGS/,/^$/p' "$CAP/Capture-Summary.txt"
nd=$(( $(wc -l < "$CAP/Stalls.csv" 2>/dev/null || echo 1) - 1 ))
cs_log "Throughput drops found: $(( nd < 0 ? 0 : nd )) (details in Capture-Summary.txt)"
for f in "$CAP"/Raw/Packets-*.pcap*; do
    [[ -f $f ]] && cs_log "Large file kept in the capture folder (not in the summary zip): $f ($(cs_bytes_h "$(stat -c %s "$f")"))"
done
if [[ $PACKAGE == yes ]]; then
    bash "$CINESYS_ROOT/New-CinesysPackage.sh" --capture "$CAP" --kind summary
fi
cs_log "Capture saved in $CAP"
