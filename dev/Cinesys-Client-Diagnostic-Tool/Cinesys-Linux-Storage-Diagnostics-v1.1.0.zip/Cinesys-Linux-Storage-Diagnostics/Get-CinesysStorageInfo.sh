#!/bin/bash
# Quick check of a client, no capture: what storage it uses (SMB, NFS,
# StorNext SAN or DLC, iSCSI, Fibre Channel, NVMe-oF, multipath), how it is
# connected, network configuration, hardware inventory and findings.
# Takes under a minute and only reads.
#
#     sudo bash Get-CinesysStorageInfo.sh
#     sudo bash Get-CinesysStorageInfo.sh --target 10.1.2.3

CINESYS_ROOT=$(cd "$(dirname "$0")" && pwd)
source "$CINESYS_ROOT/lib/common.sh"

usage() {
    cat <<USAGE
Cinesys Storage Diagnostics for Linux $CINESYS_VERSION - storage and network check

Usage: sudo bash Get-CinesysStorageInfo.sh [options]

  --target NAME|IP   Also check the path to this server (repeat or comma-separate).
  --output FOLDER    Where the result goes. Default: $CINESYS_DEFAULT_OUTPUT
  -h, --help         This text.

Without sudo it still runs, but StorNext (cvadmin), multipath, firewall,
DMI serial number and some adapter details are left out.
USAGE
}

ARG_SERVERS=()
OUTPUT=$CINESYS_DEFAULT_OUTPUT
ARGS_TEXT="$*"
while (( $# )); do
    case $1 in
        --target|--server) IFS=, read -r -a _t <<< "$2"; ARG_SERVERS+=("${_t[@]}"); shift 2 ;;
        --output) OUTPUT=$2; shift 2 ;;
        -h|--help) usage; exit 0 ;;
        *) usage; cs_die "Unknown option: $1" ;;
    esac
done
cs_is_root || echo "Note: without sudo, StorNext (cvadmin), multipath, firewall and some hardware details are left out."

# Settings the shared snapshot and manifest code expects
INTERVAL=1; LABEL=""; PACKET_MODE=none; ALLOW_NONROOT=yes
RUN_USER=${SUDO_USER:-$USER}
HOSTTAG=$(hostname -s)
START_EPOCH=$(cs_epoch)
STARTED=$(cs_now)
CAP=$OUTPUT/${HOSTTAG}_$(date -d "@$START_EPOCH" '+%Y%m%d-%H%M%S')_info
mkdir -p "$CAP/Raw" || cs_die "Cannot create $CAP"
chmod 755 "$OUTPUT" "$CAP" 2>/dev/null

source "$CINESYS_ROOT/lib/detect.sh"
source "$CINESYS_ROOT/lib/discover.sh"
source "$CINESYS_ROOT/lib/snapshot.sh"
source "$CINESYS_ROOT/lib/manifest.sh"

cs_log "Cinesys Storage Diagnostics for Linux $CINESYS_VERSION - storage and network check"
cs_log "Folder: $CAP"
cs_log "Looking for network and SAN storage ..."
cs_discover "$CAP/Storage-Info.txt"
printf '%s\n' "${CS_DET[@]}" > "$CAP/Raw/storage-info.txt"
for s in "${SERVER_IPS[@]}"; do cs_log "Target: $s ${SERVER_NAME[$s]:+(${SERVER_NAME[$s]}) }- ${TARGET_ROLE[$s]}"; done
for i in "${WATCH_IFS[@]}"; do cs_log "Adapter: ${IF_INST[$i]}$(cs_in "$i" "${STORAGE_IFS[@]}" && echo ' (carries storage traffic)')"; done

cs_snapshot Info
cs_inventory
cs_topology Info
STOPPED=$(cs_now)
cs_write_manifest Info
if cs_is_root && [[ -n $RUN_USER && $RUN_USER != root ]]; then chown -R "$RUN_USER" "$CAP" 2>/dev/null; fi

echo ""
echo "STORAGE FOUND (Storage-Info.txt)"
sed -n '/^FOUND/,/^$/p' "$CAP/Storage-Info.txt" | sed '1,2d'
sed -n '/^STORNEXT CLIENT MODE/,/^$/p' "$CAP/Storage-Info.txt"
if [[ -s $CAP/Raw/findings-info.txt ]]; then
    echo "FINDINGS (Topology-Info.txt)"
    awk -F'|' '{printf "  %-5s %s\n", $1, $2}' "$CAP/Raw/findings-info.txt"
    echo ""
fi
bash "$CINESYS_ROOT/New-CinesysPackage.sh" --capture "$CAP" --kind summary
cs_log "Saved in $CAP"
