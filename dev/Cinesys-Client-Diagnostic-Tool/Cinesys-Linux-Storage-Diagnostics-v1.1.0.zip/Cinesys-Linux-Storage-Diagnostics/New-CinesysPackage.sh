#!/bin/bash
# Packs a capture folder for sending to Cinesys.
#
#     bash New-CinesysPackage.sh --capture <folder>               summary (default)
#     bash New-CinesysPackage.sh --capture <folder> --kind full   everything, packet files too
#
# Writes <folder name>.summary.tar.gz (or .full.tar.gz) next to the folder.
# Uses zip instead when it is installed (Debian does not install it by default).

CINESYS_ROOT=$(cd "$(dirname "$0")" && pwd)
source "$CINESYS_ROOT/lib/common.sh"

CAPTURE=""; KIND=summary; OUTDIR=""
while (( $# )); do
    case $1 in
        --capture) CAPTURE=$2; shift 2 ;;
        --kind) KIND=$(tr '[:upper:]' '[:lower:]' <<< "$2"); shift 2 ;;
        --output) OUTDIR=$2; shift 2 ;;
        -h|--help) echo "Usage: bash New-CinesysPackage.sh --capture <folder> [--kind summary|full] [--output <folder>]"; exit 0 ;;
        *) cs_die "Unknown option: $1" ;;
    esac
done
[[ -d $CAPTURE ]] || cs_die "--capture must be a capture folder."
[[ $KIND == summary || $KIND == full ]] || cs_die "--kind must be summary or full."
CAPTURE=$(cd "$CAPTURE" && pwd)
parent=$(dirname "$CAPTURE"); name=$(basename "$CAPTURE")
OUTDIR=${OUTDIR:-$parent}

excl=()
[[ $KIND == summary ]] && excl=("$name/Raw/Packets-*" "$name/Raw/stopping")
if cs_have zip; then
    out=$OUTDIR/$name.$KIND.zip
    rm -f "$out"
    echo "Creating $out ..."
    zx=(); for e in "${excl[@]}"; do zx+=(-x "$e"); done
    ( cd "$parent" && zip -r -q -X "$out" "$name" "${zx[@]}" )
else
    out=$OUTDIR/$name.$KIND.tar.gz
    echo "Creating $out ..."
    ( cd "$parent" && tar -czf "$out" "${excl[@]/#/--exclude=}" "$name" )
fi
[[ -n ${SUDO_USER:-} ]] && chown "$SUDO_USER" "$out" 2>/dev/null
left=$(ls "$CAPTURE"/Raw/Packets-* 2>/dev/null | wc -l)
echo "Package: $out ($(cs_bytes_h "$(stat -c %s "$out")"))"
[[ $KIND == summary ]] && (( left > 0 )) && echo "Left out of the summary: $left packet file(s). Cinesys will ask for the full package if needed."
exit 0
