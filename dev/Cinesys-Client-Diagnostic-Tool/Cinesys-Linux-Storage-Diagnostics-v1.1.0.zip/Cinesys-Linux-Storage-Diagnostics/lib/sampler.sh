#!/bin/bash
# Per-second sampler. Started in the background by Start-CinesysCapture.sh:
#     bash lib/sampler.sh <capture folder>
# Each tick dumps the kernel's counters (/proc and /sys, plus ss for the
# connections to the targets) as one block; lib/tick.awk turns consecutive
# blocks into rates and writes one row per tick to Raw/sampler.csv
# (epoch, PerfMon time, counters). Nothing here needs root.

CAP=$1
CINESYS_ROOT=$(cd "$(dirname "$0")/.." && pwd)
source "$CINESYS_ROOT/lib/common.sh"
source "$CAP/Raw/config.sh"

# ss filter for the targets: "( dst a or dst b )"
ssfilter=""
for s in "${SERVER_IPS[@]}"; do
    [[ $s == 127.* ]] && s=127.0.0.1
    ssfilter+="${ssfilter:+ or }dst $s"
done
[[ -n $ssfilter ]] && ssfilter="( $ssfilter )"

now() { if [[ -n ${EPOCHREALTIME:-} ]]; then echo "$EPOCHREALTIME"; else date +%s.%N; fi; }
usec() { local s=${1%.*} f=${1#*.}000000; echo $(( s * 1000000 + 10#${f:0:6} )); }

block() {
    local t=$1 sec=${1%.*} f=${1#*.} ts
    printf -v ts '%(%m/%d/%Y %H:%M:%S)T' "$sec"
    echo "@T $t $ts.${f:0:3}"
    echo "@DEV";  cat /proc/net/dev
    echo "@DISK"; cat /proc/diskstats
    echo "@STAT"; cat /proc/stat
    echo "@MEM";  cat /proc/meminfo
    echo "@VM";   grep -E '^(pswpin|pswpout|pgmajfault) ' /proc/vmstat
    echo "@SNMP"; cat /proc/net/snmp
    echo "@NETSTAT"; cat /proc/net/netstat
    echo "@PSI"
    local p; for p in cpu memory io; do [[ -r /proc/pressure/$p ]] && sed "s/^/$p /" /proc/pressure/$p 2>/dev/null; done
    echo "@LOAD"; cat /proc/loadavg
    if [[ -r /proc/fs/cifs/Stats ]]; then echo "@CIFS"; cat /proc/fs/cifs/Stats 2>/dev/null; fi
    if (( ${#NFS_MOUNTS[@]} )); then echo "@NFS"; cat /proc/self/mountstats 2>/dev/null; fi
    if [[ -n $ssfilter ]]; then echo "@SS"; ss -tin state established "$ssfilter" 2>/dev/null; fi
    echo "@THERM"; cat /sys/class/thermal/thermal_zone*/temp /sys/class/hwmon/hwmon*/temp*_input 2>/dev/null
    echo "@END"
}

# Instance lists for the awk side ("key=label;...")
ifs=""; for i in "${WATCH_IFS[@]}"; do ifs+="$i=${IF_INST[$i]:-$i};"; done
disks=""; for d in "${DISKS[@]}"; do disks+="$d=${DISK_INST[$d]:-$d};"; done
smb=""; for m in "${MOUNTS[@]}"; do smb+="${MOUNT_INST[$m]};"; done
nfs=""; for m in "${NFS_MOUNTS[@]}"; do nfs+="$m=${NFS_INST[$m]};"; done
smbt=" ${SMB_SERVERS[*]} "
phys=" "; for i in "${WATCH_IFS[@]}"; do [[ $(cs_if_kind "$i") == ethernet || $(cs_if_kind "$i") == wifi ]] && phys+="$i "; done

start=$(usec "$(now)"); n=0
step=$(( INTERVAL * 1000000 ))
while :; do
    block "$(now)"
    n=$(( n + 1 ))
    wait_us=$(( start + n * step - $(usec "$(now)") ))
    if (( wait_us > 0 )); then sleep "$(( wait_us / 1000000 )).$(printf '%06d' $(( wait_us % 1000000 )))"; fi
done | CS_SMB=$smb awk -v host="$HOSTTAG" -v ifs="$ifs" -v disks="$disks" -v nfs="$nfs" \
           -v targets="${SERVER_IPS[*]}" -v smbt="$smbt" -v phys="$phys" -f "$CINESYS_ROOT/lib/tick.awk" >> "$CAP/Raw/sampler.csv"
