#!/bin/bash
# Path health watcher. Started in the background by Start-CinesysCapture.sh:
#     bash lib/pathhealth.sh <capture folder>
# Every 5 seconds: link state, speed and MTU of each watched adapter, bond
# members, the route to each target and the default route, target and
# gateway reachability, each SMB/NFS mount, iSCSI session state, FC port
# state, NVMe-oF controller state, multipath paths. Writes
# Path-Health-Samples.csv and Path-Health-Changes.csv (same columns as the
# Windows toolkit). Also guards disk space for the packet capture.

CAP=$1
CINESYS_ROOT=$(cd "$(dirname "$0")/.." && pwd)
source "$CINESYS_ROOT/lib/common.sh"
source "$CAP/Raw/config.sh"

SAMPLES=$CAP/Path-Health-Samples.csv
CHANGES=$CAP/Path-Health-Changes.csv
STEP=5
running=1
trap 'running=0' TERM INT HUP

[[ -f $SAMPLES ]] || echo 'Time,Category,Key,State,Detail' > "$SAMPLES"
[[ -f $CHANGES ]] || echo 'Time,Category,Key,Before,After' > "$CHANGES"

declare -A last=() stopped=()
csvq() { local s=${1//\"/\"\"}; printf '"%s"' "$s"; }

record() {
    # category key state [detail]
    local k="$1|$2" now
    now=$(cs_now)
    echo "$now,$(csvq "$1"),$(csvq "$2"),$(csvq "$3"),$(csvq "${4:-}")" >> "$SAMPLES"
    if [[ -z ${last[$k]+x} ]]; then
        echo "$now,$(csvq "$1"),$(csvq "$2"),\"(baseline)\",$(csvq "$3")" >> "$CHANGES"
    elif [[ ${last[$k]} != "$3" ]]; then
        echo "$now,$(csvq "$1"),$(csvq "$2"),$(csvq "${last[$k]}"),$(csvq "$3")" >> "$CHANGES"
        printf '%s  Path change: %s %s: %s -> %s\n' "$now" "$1" "$2" "${last[$k]}" "$3" >> "$CAP/Capture-Log.txt"
    fi
    last[$k]=$3
}

ping1() { ping -n -c 1 -W 1 "$1" 2>/dev/null | awk -F'time=' '/time=/{split($2, a, " "); print a[1]; exit}'; }

stop_collectors() {
    # prefix reason: stops size-limited collectors (packet capture)
    local name pid rest
    while IFS=$'\t' read -r name pid rest; do
        [[ $name == "$1"* ]] || continue
        if kill -0 "$pid" 2>/dev/null; then
            cs_stop_pid "$pid"
            printf '%s\t%s\t%s\t%s\n' "$name" "$(cs_now)" "Stopped early" "$2" >> "$CAP/Raw/collector-notes.tsv"
            printf '%s\n' "$name stopped early: $2" >> "$CAP/Raw/warnings.txt"
        fi
    done < "$CAP/Raw/collectors.tsv"
}

while (( running )); do
    t0=$(date +%s)
    tbl=$(cs_ipv4_table)
    for i in "${WATCH_IFS[@]}"; do
        ip=$(awk -v d="$i" '$1 == d {print $2; exit}' <<< "$tbl")
        sp=$(cs_if_speed "$i")
        record Link "${IF_INST[$i]:-$i}" "$(cs_if_state "$i") ${sp:-?}Mb/s $(cs_if_duplex "$i") mtu $(cs_if_mtu "$i") ip ${ip:-none}"
        if [[ -f /sys/class/net/$i/bonding/active_slave ]]; then
            record Bond "$i" "active $(cat /sys/class/net/$i/bonding/active_slave 2>/dev/null) members $(cat /sys/class/net/$i/bonding/slaves 2>/dev/null)"
        fi
    done
    for s in "${SERVER_IPS[@]}"; do
        rif=$(cs_route_if "$s")
        record Route "$s" "${rif:-none}"
        rtt=$(ping1 "$s")
        if [[ -n $rtt ]]; then record Server "$s" reachable "$rtt ms"; else record Server "$s" "no reply"; fi
    done
    gw=$(cs_default_gw); rif=$(cs_default_if)
    record Route default "${rif:-none}"
    if [[ -n $gw ]]; then
        rtt=$(ping1 "$gw")
        if [[ -n $rtt ]]; then record Gateway "$gw" reachable "$rtt ms"; else record Gateway "$gw" "no reply"; fi
    fi

    for m in "${MOUNTS[@]}"; do
        if awk -v m="$m" '{mp = $2; gsub(/\\040/, " ", mp)} mp == m {f = 1} END {exit !f}' /proc/mounts; then
            st=mounted
            if [[ -r /proc/fs/cifs/Stats ]] && grep -F -i -- "${MOUNT_INST[$m]}" /proc/fs/cifs/Stats | grep -q DISCONNECTED; then st=disconnected; fi
            record 'SMB mount' "${MOUNT_INST[$m]}" "$st"
        else
            record 'SMB mount' "${MOUNT_INST[$m]}" "not mounted"
        fi
    done
    for m in "${NFS_MOUNTS[@]}"; do
        if awk -v m="$m" '{mp = $2; gsub(/\\040/, " ", mp)} mp == m {f = 1} END {exit !f}' /proc/mounts; then
            record 'NFS mount' "${NFS_INST[$m]}" mounted
        else
            record 'NFS mount' "${NFS_INST[$m]}" "not mounted"
        fi
    done
    for sess in /sys/class/iscsi_session/session*; do
        [[ -d $sess ]] || continue
        record 'iSCSI session' "$(cat $sess/targetname 2>/dev/null)" "$(cat $sess/state 2>/dev/null)"
    done
    for h in /sys/class/fc_host/host*; do
        [[ -d $h ]] || continue
        record 'FC port' "${h##*/} $(cat $h/port_name 2>/dev/null)" "$(cat $h/port_state 2>/dev/null) $(cat $h/speed 2>/dev/null)"
    done
    for c in /sys/class/nvme/nvme*; do
        [[ -d $c && $(cat $c/transport 2>/dev/null) != pcie ]] || continue
        record 'NVMe-oF controller' "${c##*/} $(cat $c/address 2>/dev/null)" "$(cat $c/state 2>/dev/null)"
    done
    for dm in /sys/block/dm-*; do
        [[ $(cat $dm/dm/uuid 2>/dev/null) == mpath-* ]] || continue
        n=0; ok=0
        for sl in "$dm"/slaves/*; do [[ -e $sl ]] || continue; n=$((n + 1)); [[ $(cat /sys/block/${sl##*/}/device/state 2>/dev/null) == running ]] && ok=$((ok + 1)); done
        record 'Multipath' "$(cat $dm/dm/name 2>/dev/null)" "$ok of $n paths running"
    done

    # Safety: stop the packet capture if the capture volume is nearly full
    freemb=$(df -Pm "$CAP" 2>/dev/null | awk 'NR == 2 {print $4}')
    if [[ -n $freemb ]] && (( freemb < MIN_FREE_MB )) && [[ -z ${stopped[pc]:-} ]]; then
        stop_collectors PacketCapture "less than $MIN_FREE_MB MB free on the capture volume"; stopped[pc]=1
    fi

    while (( running )) && (( $(date +%s) - t0 < STEP )); do sleep 0.2; done
done
