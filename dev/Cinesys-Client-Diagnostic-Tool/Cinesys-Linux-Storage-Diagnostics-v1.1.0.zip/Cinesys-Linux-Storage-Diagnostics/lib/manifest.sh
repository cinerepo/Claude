# Capture-Manifest.json. Sourced after common.sh and Raw/config.sh.
#     cs_write_manifest <Status>

cs_write_manifest() {
    local cstatus=$1 f=$CAP/Capture-Manifest.json
    local -a items
    local s m i name pid started out match st note line at
    jarr() { local IFS=,; printf '[%s]' "$*"; }

    declare -A cstate=() cstop=() cnote=()
    if [[ -f $CAP/Raw/collector-status.tsv ]]; then
        while IFS=$'\t' read -r name st at; do cstate[$name]=$st; cstop[$name]=$at; done < "$CAP/Raw/collector-status.tsv"
    fi
    if [[ -f $CAP/Raw/collector-notes.tsv ]]; then
        while IFS=$'\t' read -r name at st note; do cnote[$name]="${cnote[$name]:+${cnote[$name]}; }$st${note:+: $note}"; done < "$CAP/Raw/collector-notes.tsv"
    fi
    items=()
    if [[ -f $CAP/Raw/collectors.tsv ]]; then
        while IFS=$'\t' read -r name pid started out match; do
            [[ $out == - ]] && out=""
            items+=("{\"Name\":$(cs_json "$name"),\"Pid\":$pid,\"Started\":$(cs_json "$started"),\"Output\":$(cs_json "$out"),\"Stopped\":$(cs_json "${cstop[$name]:-}"),\"State\":$(cs_json "${cstate[$name]:-$cstatus}"),\"Note\":$(cs_json "${cnote[$name]:-}")}")
        done < "$CAP/Raw/collectors.tsv"
    fi
    local collectors; collectors=$(jarr "${items[@]}")

    items=()
    for s in "${SERVER_IPS[@]}"; do items+=("{\"Ip\":$(cs_json "$s"),\"Name\":$(cs_json "${SERVER_NAME[$s]:-}"),\"Role\":$(cs_json "${TARGET_ROLE[$s]:-}")}"); done
    local targets; targets=$(jarr "${items[@]}")
    items=()
    for m in "${MOUNTS[@]}"; do items+=("{\"Protocol\":\"SMB\",\"Instance\":$(cs_json "${MOUNT_INST[$m]}"),\"MountPoint\":$(cs_json "$m"),\"Server\":$(cs_json "${MOUNT_SERVER[$m]}")}"); done
    for m in "${NFS_MOUNTS[@]}"; do items+=("{\"Protocol\":\"NFS\",\"Instance\":$(cs_json "${NFS_INST[$m]}"),\"MountPoint\":$(cs_json "$m"),\"Server\":$(cs_json "${NFS_SERVER[$m]}")}"); done
    local shares; shares=$(jarr "${items[@]}")
    items=()
    for i in "${WATCH_IFS[@]}"; do
        local c=false; cs_in "$i" "${STORAGE_IFS[@]}" && c=true
        items+=("{\"Device\":$(cs_json "$i"),\"Label\":$(cs_json "${IF_INST[$i]:-$i}"),\"CarriesStorage\":$c}")
    done
    local ifaces; ifaces=$(jarr "${items[@]}")

    items=()
    local sf=$CAP/Raw/storage-pre.txt; [[ -f $sf ]] || sf=$CAP/Raw/storage-info.txt
    if [[ -f $sf ]]; then
        local -a r
        while IFS= read -r line; do
            [[ -z $line ]] && continue
            IFS='|' read -r -a r <<< "$line"
            for k in 1 2 3 5; do [[ ${r[$k]} == - ]] && r[$k]=""; done
            items+=("{\"Protocol\":$(cs_json "${r[0]}"),\"Role\":$(cs_json "${r[4]}"),\"Address\":$(cs_json "${r[1]}"),\"Port\":$(cs_json "${r[2]}"),\"Where\":$(cs_json "${r[3]}"),\"Detail\":$(cs_json "${r[5]}")}")
        done < "$sf"
    fi
    local storage; storage=$(jarr "${items[@]}")

    local cov='{}'
    if [[ -s $CAP/Raw/sampler.csv ]]; then
        cov=$(awk -F, -v iv="$INTERVAL" '
            NR == 1 { next }
            { e = $1 + 0; if (n == 0) first = e; if (n > 0 && e - last > 2 * iv && ng < 20) gaps[++ng] = last " " (e - last); last = e; n++ }
            END {
                printf "{\"Samples\":%d,\"FirstEpoch\":%d,\"LastEpoch\":%d,\"Gaps\":[", n, first, last
                for (k = 1; k <= ng; k++) { split(gaps[k], g, " "); printf "%s{\"AfterEpoch\":%d,\"Seconds\":%d}", (k > 1 ? "," : ""), g[1], g[2] }
                printf "]}"
            }' "$CAP/Raw/sampler.csv")
    fi

    items=()
    local fw lv tx
    for fw in pre post info; do
        [[ -f $CAP/Raw/findings-$fw.txt ]] || continue
        while IFS='|' read -r lv tx; do items+=("{\"When\":$(cs_json "$fw"),\"Level\":$(cs_json "$lv"),\"Text\":$(cs_json "$tx")}"); done < "$CAP/Raw/findings-$fw.txt"
    done
    local findings; findings=$(jarr "${items[@]}")

    items=()
    if [[ -f $CAP/Raw/warnings.txt ]]; then
        while IFS= read -r line; do items+=("$(cs_json "$line")"); done < "$CAP/Raw/warnings.txt"
    fi
    local warnings; warnings=$(jarr "${items[@]}")

    local mode=root; cs_is_root || mode='test (no sudo)'
    {
        echo "{"
        echo "  \"Tool\": \"Cinesys Storage Diagnostics for Linux\","
        echo "  \"Version\": $(cs_json "$CINESYS_VERSION"),"
        echo "  \"Platform\": \"Linux\","
        echo "  \"Host\": $(cs_json "$HOSTTAG"),"
        echo "  \"OS\": $(cs_json "$(. /etc/os-release 2>/dev/null; echo "$PRETTY_NAME")"),"
        echo "  \"Kernel\": $(cs_json "$(uname -r)"),"
        echo "  \"Model\": $(cs_json "$(cs_dmi sys_vendor) $(cs_dmi product_name)"),"
        echo "  \"Virtualization\": $(cs_json "$(cs_virt)"),"
        echo "  \"Status\": $(cs_json "$cstatus"),"
        echo "  \"Label\": $(cs_json "$LABEL"),"
        echo "  \"Arguments\": $(cs_json "$ARGS_TEXT"),"
        echo "  \"Mode\": $(cs_json "$mode"),"
        echo "  \"Started\": $(cs_json "$STARTED"),"
        echo "  \"Stopped\": $(cs_json "${STOPPED:-}"),"
        echo "  \"IntervalSeconds\": $INTERVAL,"
        echo "  \"PacketCapture\": $(cs_json "$PACKET_MODE"),"
        echo "  \"Targets\": $targets,"
        echo "  \"Mounts\": $shares,"
        echo "  \"Storage\": $storage,"
        echo "  \"Interfaces\": $ifaces,"
        echo "  \"Collectors\": $collectors,"
        echo "  \"Coverage\": $cov,"
        echo "  \"Findings\": $findings,"
        echo "  \"Warnings\": $warnings"
        echo "}"
    } > "$f"
}
