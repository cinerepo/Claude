# Turns the sampler's counter blocks into one CSV row per tick.
# Input: blocks from lib/sampler.sh ("@T <epoch> <MM/dd/yyyy HH:mm:ss.fff>",
# then "@DEV", "@DISK", ... sections, then "@END").
# Output: header once, then "epoch,"time",value,..." per tick, in the
# PerfMon layout \\HOST\Object(Instance)\Counter the Windows analyzer reads.
# Plain POSIX awk (Debian's default awk is mawk).
#
#   -v host=  -v ifs="dev=label;..."  -v disks="name=label;..."
#   SMB share list in the environment (CS_SMB="\\srv\share;..."): awk -v would
#   turn its backslashes into escapes.  -v nfs="mountpoint=srv:/export;..."
#   -v targets="ip ip"  -v smbt=" ip ip "  -v phys=" dev dev " (physical adapters,
#   summed for the traffic no storage connection accounts for)

BEGIN {
    MB = 1048576
    nif = split(ifs, a, ";"); nI = 0
    for (i = 1; i <= nif; i++) if (a[i] != "") { k = index(a[i], "="); IFN[++nI] = substr(a[i], 1, k - 1); IFL[nI] = substr(a[i], k + 1) }
    n = split(disks, a, ";"); nD = 0
    for (i = 1; i <= n; i++) if (a[i] != "") { k = index(a[i], "="); DKN[++nD] = substr(a[i], 1, k - 1); DKL[nD] = substr(a[i], k + 1) }
    n = split(ENVIRON["CS_SMB"], a, ";"); nS = 0
    for (i = 1; i <= n; i++) if (a[i] != "") { SH[++nS] = a[i]; SHL[tolower(a[i])] = nS }
    n = split(nfs, a, ";"); nN = 0
    for (i = 1; i <= n; i++) if (a[i] != "") { k = index(a[i], "="); NMP[++nN] = substr(a[i], 1, k - 1); NFL[nN] = substr(a[i], k + 1); NIDX[NMP[nN]] = nN }
    nT = split(targets, TG, " ")
    for (i = 1; i <= nT; i++) { TIDX[TG[i]] = i; if (TG[i] ~ /^127\./) TIDX["127.0.0.1"] = i }
    pre = "\\\\" host "\\"
    sec = ""; have = 0
}

function q(s) { return "\"" s "\"" }
function rate(c, p) { return (c == "" || p == "" || c + 0 < p + 0 || dt <= 0) ? "" : (c - p) / dt }
function f0(x) { return (x == "") ? "" : sprintf("%.0f", x) }
function f2(x) { return (x == "") ? "" : sprintf("%.2f", x) }
function f6(x) { return (x == "") ? "" : sprintf("%.6f", x) }
function put(name, v) { M[name] = v }
function addh(name) { H[++nh] = name }

# --- section parsers (fill C[], the current counters) ----------------------
function p_dev(   line, k, name, n, f) {
    line = $0; k = index(line, ":"); if (!k) return
    name = substr(line, 1, k - 1); gsub(/ /, "", name)
    n = split(substr(line, k + 1), f, " ")
    C["if", name, "rb"] = f[1]; C["if", name, "rp"] = f[2]; C["if", name, "re"] = f[3]; C["if", name, "rd"] = f[4]
    C["if", name, "tb"] = f[9]; C["if", name, "tp"] = f[10]; C["if", name, "te"] = f[11]; C["if", name, "td"] = f[12]
}
function p_disk() {
    if (NF < 14) return
    C["dk", $3, "r"] = $4; C["dk", $3, "rs"] = $6; C["dk", $3, "rms"] = $7
    C["dk", $3, "w"] = $8; C["dk", $3, "ws"] = $10; C["dk", $3, "wms"] = $11
    C["dk", $3, "q"] = $12; C["dk", $3, "tk"] = $13
}
function p_stat(   c, tot, i) {
    if ($1 ~ /^cpu[0-9]*$/) {
        c = ($1 == "cpu") ? "T" : substr($1, 4)
        tot = 0; for (i = 2; i <= 9 && i <= NF; i++) tot += $i
        C["cpu", c, "tot"] = tot; C["cpu", c, "idle"] = $5 + $6
        C["cpu", c, "usr"] = $2 + $3; C["cpu", c, "sys"] = $4; C["cpu", c, "iow"] = $6
        C["cpu", c, "irq"] = $7 + $8; C["cpu", c, "stl"] = (NF >= 9) ? $9 : 0
        if (c != "T" && c + 1 > ncpu) ncpu = c + 1
    } else if ($1 == "procs_running") C["procs_running"] = $2
    else if ($1 == "procs_blocked") C["procs_blocked"] = $2
}
function p_kv(prefix,   k) { k = $1; sub(/:$/, "", k); C[prefix, k] = $2 }
function p_snmp(   i, n) {
    # "Tcp: Name Name ..." then "Tcp: value value ..."; same for TcpExt in
    # netstat. Udp and Ip names are stored as Udp.<name> / Ip.<name> (they
    # share names such as InErrors with other sections).
    if ($1 == "Tcp:" || $1 == "TcpExt:" || $1 == "Udp:" || $1 == "Ip:") {
        if (!(($1) in hdrseen)) { hdrseen[$1] = 1; for (i = 2; i <= NF; i++) SNAME[$1, i] = $i }
        else {
            pfx = ($1 == "Udp:" || $1 == "Ip:") ? substr($1, 1, length($1) - 1) "." : ""
            for (i = 2; i <= NF; i++) C["snmp", pfx SNAME[$1, i]] = $i
            delete hdrseen[$1]
        }
    }
}
function p_psi(   kind, i, v) {
    for (i = 3; i <= NF; i++) if ($i ~ /^total=/) { v = $i; sub(/^total=/, "", v); C["psi", $1, $2] = v + 0 }
}
function p_cifs(   line, nm, k) {
    line = $0
    if (line ~ /^[0-9]+\) /) {
        nm = line; sub(/^[0-9]+\) */, "", nm); sub(/[ \t].*$/, "", nm)
        cur_share = (tolower(nm) in SHL) ? SHL[tolower(nm)] : 0
        if (cur_share) { C["smb", cur_share, "disc"] = (line ~ /DISCONNECTED/) ? 1 : 0; C["smb", cur_share, "seen"] = 1 }
        return
    }
    if (!cur_share) return
    if (match(line, /Bytes read: *[0-9]+/)) { k = substr(line, RSTART, RLENGTH); sub(/[^0-9]*/, "", k); C["smb", cur_share, "rb"] += k }
    if (match(line, /Bytes written: *[0-9]+/)) { k = substr(line, RSTART, RLENGTH); sub(/[^0-9]*/, "", k); C["smb", cur_share, "wb"] += k }
    if (match(line, /(^|[^A-Za-z])Reads: *[0-9]+/)) { k = substr(line, RSTART, RLENGTH); sub(/[^0-9]*/, "", k); C["smb", cur_share, "ro"] += k }
    if (match(line, /(^|[^A-Za-z])Writes: *[0-9]+/)) { k = substr(line, RSTART, RLENGTH); sub(/[^0-9]*/, "", k); C["smb", cur_share, "wo"] += k }
}
function p_nfs(   mp, m) {
    if ($1 == "device") {
        mp = $5; gsub(/\\040/, " ", mp)
        cur_nfs = (mp in NIDX) ? NIDX[mp] : 0
        if (cur_nfs) C["nfs", cur_nfs, "seen"] = 1
        return
    }
    if (!cur_nfs) return
    m = cur_nfs
    if ($1 == "bytes:") { C["nfs", m, "rb"] = $2 + $4; C["nfs", m, "wb"] = $3 + $5 }
    else if ($1 == "xprt:" && $2 == "tcp") C["nfs", m, "conn"] = $5
    else if ($1 == "READ:") { C["nfs", m, "ro"] = $2; C["nfs", m, "rrtt"] = $8; C["nfs", m, "rexe"] = $9 }
    else if ($1 == "WRITE:") { C["nfs", m, "wo"] = $2; C["nfs", m, "wrtt"] = $8; C["nfs", m, "wexe"] = $9 }
    if ($1 ~ /^[A-Z_]+:$/ && $1 != "bytes:" && $1 != "xprt:" && $1 != "events:" && NF >= 4 && $2 ~ /^[0-9]+$/) {
        C["nfs", m, "retr"] += $3 - $2; C["nfs", m, "tmo"] += $4
    }
}
function p_ss(   i, t, v, peer, ip) {
    if ($1 ~ /^[0-9]+$/ && NF >= 4 && $0 !~ /^[ \t]/) {
        peer = $4; ip = peer; sub(/:[0-9]+$/, "", ip); gsub(/[\[\]]/, "", ip); sub(/^::ffff:/, "", ip)
        cur_sock = (ip in TIDX) ? $3 ">" $4 : ""
        if (cur_sock != "") { SOCKT[cur_sock] = TIDX[ip]; C["sock", cur_sock, "sq"] = $2; C["sock", cur_sock, "on"] = 1; C["sockcount", TIDX[ip]]++ }
        return
    }
    if (cur_sock == "") return
    for (i = 1; i <= NF; i++) {
        t = $i; v = t; sub(/^[^:]*:/, "", v); if (t !~ /^rtt:/) v = v + 0
        if (t ~ /^bytes_sent:/) C["sock", cur_sock, "tx"] = v
        else if (t ~ /^bytes_acked:/ && C["sock", cur_sock, "tx"] == "") C["sock", cur_sock, "txa"] = v
        else if (t ~ /^bytes_received:/) C["sock", cur_sock, "rx"] = v
        else if (t ~ /^bytes_retrans:/) C["sock", cur_sock, "rt"] = v
        else if (t ~ /^rtt:/) { sub(/\/.*/, "", v); C["sock", cur_sock, "rtt"] = v }
        else if (t ~ /^rcv_space:/) C["sock", cur_sock, "rw"] = v
        else if (t ~ /^snd_wnd:/) C["sock", cur_sock, "sw"] = v
    }
}

# --- header (once, at the first complete block) ---------------------------
function header(   i, c, o) {
    addh("epoch"); addh("(PDH-CSV 4.0) (Local Time)")
    for (i = 1; i <= nI; i++) {
        o = pre "Network Interface(" IFL[i] ")\\"
        addh(o "Bytes Received/sec"); addh(o "Bytes Sent/sec"); addh(o "Packets Received/sec"); addh(o "Packets Sent/sec")
        addh(o "Packets Received Errors/sec"); addh(o "Packets Outbound Errors/sec"); addh(o "Packets Received Discarded/sec"); addh(o "Packets Outbound Discarded/sec")
    }
    for (i = 1; i <= nS; i++) {
        o = pre "SMB Client Shares(" SH[i] ")\\"
        addh(o "Read Bytes/sec"); addh(o "Write Bytes/sec"); addh(o "Read Requests/sec"); addh(o "Write Requests/sec"); addh(o "Disconnected")
    }
    for (i = 1; i <= nN; i++) {
        o = pre "NFS Client Mounts(" NFL[i] ")\\"
        addh(o "Read Bytes/sec"); addh(o "Write Bytes/sec"); addh(o "Reads/sec"); addh(o "Writes/sec")
        addh(o "Avg. Read RTT ms"); addh(o "Avg. Read Execute ms"); addh(o "Avg. Write RTT ms"); addh(o "Avg. Write Execute ms")
        addh(o "Retransmissions/sec"); addh(o "Timeouts/sec"); addh(o "Connect Count")
    }
    for (i = 1; i <= nT; i++) {
        o = pre ((index(smbt, " " TG[i] " ")) ? "SMB Client Connection(" : "Storage Connection(") TG[i] ")\\"
        addh(o "Bytes Received/sec"); addh(o "Bytes Sent/sec"); addh(o "Retransmitted Bytes/sec"); addh(o "Round Trip Time ms")
        addh(o "Receive Window Bytes"); addh(o "Send Window Bytes"); addh(o "Send Queue Bytes"); addh(o "Connections")
    }
    o = pre "TCPv4\\"
    addh(o "Segments Sent/sec"); addh(o "Segments Received/sec"); addh(o "Segments Retransmitted/sec"); addh(o "Retransmit Timeouts/sec")
    addh(o "Out-of-Order Segments Received/sec"); addh(o "Segments Received Errors/sec")
    o = pre "UDPv4\\"
    addh(o "Datagrams Received/sec"); addh(o "Datagrams Sent/sec"); addh(o "Datagrams Received Errors/sec"); addh(o "Receive Buffer Errors/sec"); addh(o "Datagrams No Port/sec")
    o = pre "IPv4\\"
    addh(o "Fragments Received/sec"); addh(o "Fragment Re-assembly Failures/sec")
    o = pre "Network Unattributed(_Total)\\"
    addh(o "Bytes Received/sec"); addh(o "Bytes Sent/sec")
    o = pre "Memory\\"
    addh(o "Available MBytes"); addh(o "Free MBytes"); addh(o "Cached MBytes"); addh(o "Dirty MBytes"); addh(o "Writeback MBytes")
    addh(o "Swap Used MBytes"); addh(o "Swap In Pages/sec"); addh(o "Swap Out Pages/sec"); addh(o "Major Faults/sec")
    o = pre "Pressure\\"
    addh(o "CPU Some %"); addh(o "Memory Some %"); addh(o "Memory Full %"); addh(o "IO Some %"); addh(o "IO Full %")
    for (i = 1; i <= nD; i++) {
        o = pre "PhysicalDisk(" DKL[i] ")\\"
        addh(o "Disk Read Bytes/sec"); addh(o "Disk Write Bytes/sec"); addh(o "Disk Reads/sec"); addh(o "Disk Writes/sec")
        addh(o "Avg. Disk sec/Read"); addh(o "Avg. Disk sec/Write"); addh(o "Current Disk Queue Length"); addh(o "% Disk Time")
    }
    o = pre "Processor Information(_Total)\\"
    addh(o "% Processor Time"); addh(o "% User Time"); addh(o "% Privileged Time"); addh(o "% Interrupt Time"); addh(o "% IO Wait Time"); addh(o "% Steal Time")
    o = pre "System\\"
    addh(o "Load Average 1m"); addh(o "Processes Running"); addh(o "Processes Blocked")
    for (c = 0; c < ncpu; c++) addh(pre "Processor Information(0," c ")\\% Processor Time")
    addh(pre "Thermal\\Max Zone Temperature C")
    line = q(H[1])
    for (i = 2; i <= nh; i++) line = line "," q(H[i])
    print line
}

# --- values (current minus previous) --------------------------------------
function compute(   i, n, o, c, d, x, y, s, k, tot, rt, rtt, nm) {
    for (k in M) delete M[k]
    for (i = 1; i <= nI; i++) {
        n = IFN[i]; o = pre "Network Interface(" IFL[i] ")\\"
        put(o "Bytes Received/sec", f0(rate(C["if", n, "rb"], P["if", n, "rb"]))); put(o "Bytes Sent/sec", f0(rate(C["if", n, "tb"], P["if", n, "tb"])))
        put(o "Packets Received/sec", f0(rate(C["if", n, "rp"], P["if", n, "rp"]))); put(o "Packets Sent/sec", f0(rate(C["if", n, "tp"], P["if", n, "tp"])))
        put(o "Packets Received Errors/sec", f2(rate(C["if", n, "re"], P["if", n, "re"]))); put(o "Packets Outbound Errors/sec", f2(rate(C["if", n, "te"], P["if", n, "te"])))
        put(o "Packets Received Discarded/sec", f2(rate(C["if", n, "rd"], P["if", n, "rd"]))); put(o "Packets Outbound Discarded/sec", f2(rate(C["if", n, "td"], P["if", n, "td"])))
    }
    for (i = 1; i <= nS; i++) {
        o = pre "SMB Client Shares(" SH[i] ")\\"
        if (C["smb", i, "seen"] == "") continue
        put(o "Read Bytes/sec", f0(rate(C["smb", i, "rb"], P["smb", i, "rb"]))); put(o "Write Bytes/sec", f0(rate(C["smb", i, "wb"], P["smb", i, "wb"])))
        put(o "Read Requests/sec", f2(rate(C["smb", i, "ro"], P["smb", i, "ro"]))); put(o "Write Requests/sec", f2(rate(C["smb", i, "wo"], P["smb", i, "wo"])))
        put(o "Disconnected", C["smb", i, "disc"])
    }
    for (i = 1; i <= nN; i++) {
        o = pre "NFS Client Mounts(" NFL[i] ")\\"
        if (C["nfs", i, "seen"] == "") continue
        put(o "Read Bytes/sec", f0(rate(C["nfs", i, "rb"], P["nfs", i, "rb"]))); put(o "Write Bytes/sec", f0(rate(C["nfs", i, "wb"], P["nfs", i, "wb"])))
        put(o "Reads/sec", f2(rate(C["nfs", i, "ro"], P["nfs", i, "ro"]))); put(o "Writes/sec", f2(rate(C["nfs", i, "wo"], P["nfs", i, "wo"])))
        d = C["nfs", i, "ro"] - P["nfs", i, "ro"]
        if (d > 0) { put(o "Avg. Read RTT ms", f2((C["nfs", i, "rrtt"] - P["nfs", i, "rrtt"]) / d)); put(o "Avg. Read Execute ms", f2((C["nfs", i, "rexe"] - P["nfs", i, "rexe"]) / d)) }
        d = C["nfs", i, "wo"] - P["nfs", i, "wo"]
        if (d > 0) { put(o "Avg. Write RTT ms", f2((C["nfs", i, "wrtt"] - P["nfs", i, "wrtt"]) / d)); put(o "Avg. Write Execute ms", f2((C["nfs", i, "wexe"] - P["nfs", i, "wexe"]) / d)) }
        put(o "Retransmissions/sec", f2(rate(C["nfs", i, "retr"], P["nfs", i, "retr"]))); put(o "Timeouts/sec", f2(rate(C["nfs", i, "tmo"], P["nfs", i, "tmo"])))
        put(o "Connect Count", C["nfs", i, "conn"])
    }
    # connections: add up the sockets seen in both blocks, per target
    for (i = 1; i <= nT; i++) { CRX[i] = 0; CTX[i] = 0; CRT[i] = 0; CRTT[i] = ""; CRW[i] = ""; CSW[i] = ""; CSQ[i] = 0 }
    for (s in SOCKT) {
        if (C["sock", s, "on"] == "") continue
        i = SOCKT[s]
        x = C["sock", s, "tx"]; if (x == "") x = C["sock", s, "txa"]; y = P["sock", s, "tx"]; if (y == "") y = P["sock", s, "txa"]
        if (P["sock", s, "on"] != "") {
            if (x != "" && y != "" && x + 0 >= y + 0) CTX[i] += x - y
            if (C["sock", s, "rx"] + 0 >= P["sock", s, "rx"] + 0) CRX[i] += C["sock", s, "rx"] - P["sock", s, "rx"]
            if (C["sock", s, "rt"] + 0 >= P["sock", s, "rt"] + 0) CRT[i] += C["sock", s, "rt"] - P["sock", s, "rt"]
        }
        if (C["sock", s, "rtt"] != "" && (CRTT[i] == "" || C["sock", s, "rtt"] + 0 > CRTT[i])) CRTT[i] = C["sock", s, "rtt"] + 0
        if (C["sock", s, "rw"] != "" && (CRW[i] == "" || C["sock", s, "rw"] + 0 > CRW[i])) CRW[i] = C["sock", s, "rw"] + 0
        if (C["sock", s, "sw"] != "" && (CSW[i] == "" || C["sock", s, "sw"] + 0 > CSW[i])) CSW[i] = C["sock", s, "sw"] + 0
        CSQ[i] += C["sock", s, "sq"]
    }
    for (i = 1; i <= nT; i++) {
        o = pre ((index(smbt, " " TG[i] " ")) ? "SMB Client Connection(" : "Storage Connection(") TG[i] ")\\"
        n = C["sockcount", i] + 0
        put(o "Connections", n)
        if (!n) continue
        put(o "Bytes Received/sec", f0(CRX[i] / dt)); put(o "Bytes Sent/sec", f0(CTX[i] / dt)); put(o "Retransmitted Bytes/sec", f0(CRT[i] / dt))
        put(o "Round Trip Time ms", (CRTT[i] == "") ? "" : sprintf("%.3f", CRTT[i])); put(o "Receive Window Bytes", CRW[i]); put(o "Send Window Bytes", CSW[i]); put(o "Send Queue Bytes", CSQ[i])
    }
    o = pre "TCPv4\\"
    put(o "Segments Sent/sec", f0(rate(C["snmp", "OutSegs"], P["snmp", "OutSegs"]))); put(o "Segments Received/sec", f0(rate(C["snmp", "InSegs"], P["snmp", "InSegs"])))
    put(o "Segments Retransmitted/sec", f2(rate(C["snmp", "RetransSegs"], P["snmp", "RetransSegs"]))); put(o "Retransmit Timeouts/sec", f2(rate(C["snmp", "TCPTimeouts"], P["snmp", "TCPTimeouts"])))
    put(o "Out-of-Order Segments Received/sec", f2(rate(C["snmp", "TCPOFOQueue"], P["snmp", "TCPOFOQueue"]))); put(o "Segments Received Errors/sec", f2(rate(C["snmp", "InErrs"], P["snmp", "InErrs"])))
    o = pre "UDPv4\\"
    put(o "Datagrams Received/sec", f0(rate(C["snmp", "Udp.InDatagrams"], P["snmp", "Udp.InDatagrams"]))); put(o "Datagrams Sent/sec", f0(rate(C["snmp", "Udp.OutDatagrams"], P["snmp", "Udp.OutDatagrams"])))
    put(o "Datagrams Received Errors/sec", f2(rate(C["snmp", "Udp.InErrors"], P["snmp", "Udp.InErrors"]))); put(o "Receive Buffer Errors/sec", f2(rate(C["snmp", "Udp.RcvbufErrors"], P["snmp", "Udp.RcvbufErrors"])))
    put(o "Datagrams No Port/sec", f2(rate(C["snmp", "Udp.NoPorts"], P["snmp", "Udp.NoPorts"])))
    o = pre "IPv4\\"
    put(o "Fragments Received/sec", f2(rate(C["snmp", "Ip.ReasmReqds"], P["snmp", "Ip.ReasmReqds"]))); put(o "Fragment Re-assembly Failures/sec", f2(rate(C["snmp", "Ip.ReasmFails"], P["snmp", "Ip.ReasmFails"])))
    # Physical adapters minus every TCP connection to a storage target: what is
    # left is traffic no tracked protocol accounts for (Avid NEXIS UDP, ...).
    x = 0; y = 0; k = 0
    for (i = 1; i <= nI; i++) {
        n = IFN[i]
        if (index(phys, " " n " ") == 0) continue
        d = rate(C["if", n, "rb"], P["if", n, "rb"]); if (d != "") { x += d; k++ }
        d = rate(C["if", n, "tb"], P["if", n, "tb"]); if (d != "") y += d
    }
    if (k) {
        for (i = 1; i <= nT; i++) { x -= CRX[i] / dt; y -= CTX[i] / dt }
        o = pre "Network Unattributed(_Total)\\"
        put(o "Bytes Received/sec", f0(x > 0 ? x : 0)); put(o "Bytes Sent/sec", f0(y > 0 ? y : 0))
    }
    o = pre "Memory\\"
    put(o "Available MBytes", f0(C["mem", "MemAvailable"] / 1024)); put(o "Free MBytes", f0(C["mem", "MemFree"] / 1024)); put(o "Cached MBytes", f0(C["mem", "Cached"] / 1024))
    put(o "Dirty MBytes", f0(C["mem", "Dirty"] / 1024)); put(o "Writeback MBytes", f0(C["mem", "Writeback"] / 1024))
    put(o "Swap Used MBytes", f0((C["mem", "SwapTotal"] - C["mem", "SwapFree"]) / 1024))
    put(o "Swap In Pages/sec", f2(rate(C["vm", "pswpin"], P["vm", "pswpin"]))); put(o "Swap Out Pages/sec", f2(rate(C["vm", "pswpout"], P["vm", "pswpout"]))); put(o "Major Faults/sec", f2(rate(C["vm", "pgmajfault"], P["vm", "pgmajfault"])))
    # PSI "total" is microseconds stalled; per second of interval -> percent
    o = pre "Pressure\\"
    if (C["psi", "cpu", "some"] != "") {
        put(o "CPU Some %", f2(rate(C["psi", "cpu", "some"], P["psi", "cpu", "some"]) / 10000))
        put(o "Memory Some %", f2(rate(C["psi", "memory", "some"], P["psi", "memory", "some"]) / 10000)); put(o "Memory Full %", f2(rate(C["psi", "memory", "full"], P["psi", "memory", "full"]) / 10000))
        put(o "IO Some %", f2(rate(C["psi", "io", "some"], P["psi", "io", "some"]) / 10000)); put(o "IO Full %", f2(rate(C["psi", "io", "full"], P["psi", "io", "full"]) / 10000))
    }
    for (i = 1; i <= nD; i++) {
        n = DKN[i]; o = pre "PhysicalDisk(" DKL[i] ")\\"
        if (C["dk", n, "r"] == "") continue
        put(o "Disk Read Bytes/sec", f0(rate(C["dk", n, "rs"], P["dk", n, "rs"]) * 512)); put(o "Disk Write Bytes/sec", f0(rate(C["dk", n, "ws"], P["dk", n, "ws"]) * 512))
        put(o "Disk Reads/sec", f2(rate(C["dk", n, "r"], P["dk", n, "r"]))); put(o "Disk Writes/sec", f2(rate(C["dk", n, "w"], P["dk", n, "w"])))
        d = C["dk", n, "r"] - P["dk", n, "r"]; put(o "Avg. Disk sec/Read", (d > 0) ? f6((C["dk", n, "rms"] - P["dk", n, "rms"]) / d / 1000) : "0.000000")
        d = C["dk", n, "w"] - P["dk", n, "w"]; put(o "Avg. Disk sec/Write", (d > 0) ? f6((C["dk", n, "wms"] - P["dk", n, "wms"]) / d / 1000) : "0.000000")
        put(o "Current Disk Queue Length", C["dk", n, "q"])
        x = rate(C["dk", n, "tk"], P["dk", n, "tk"]); put(o "% Disk Time", (x == "") ? "" : f2(x / 10))
    }
    for (c = -1; c < ncpu; c++) {
        k = (c < 0) ? "T" : c
        tot = C["cpu", k, "tot"] - P["cpu", k, "tot"]
        if (tot <= 0) continue
        o = (c < 0) ? pre "Processor Information(_Total)\\" : pre "Processor Information(0," c ")\\"
        put(o "% Processor Time", f2(100 * (tot - (C["cpu", k, "idle"] - P["cpu", k, "idle"])) / tot))
        if (c < 0) {
            put(o "% User Time", f2(100 * (C["cpu", k, "usr"] - P["cpu", k, "usr"]) / tot)); put(o "% Privileged Time", f2(100 * (C["cpu", k, "sys"] - P["cpu", k, "sys"]) / tot))
            put(o "% Interrupt Time", f2(100 * (C["cpu", k, "irq"] - P["cpu", k, "irq"]) / tot)); put(o "% IO Wait Time", f2(100 * (C["cpu", k, "iow"] - P["cpu", k, "iow"]) / tot))
            put(o "% Steal Time", f2(100 * (C["cpu", k, "stl"] - P["cpu", k, "stl"]) / tot))
        }
    }
    o = pre "System\\"
    put(o "Load Average 1m", C["load"]); put(o "Processes Running", C["procs_running"]); put(o "Processes Blocked", C["procs_blocked"])
    if (C["therm"] != "") put(pre "Thermal\\Max Zone Temperature C", sprintf("%.1f", C["therm"] / 1000))
}

# --- block handling --------------------------------------------------------
/^@T / {
    for (k in C) delete C[k]
    for (k in SOCKT) delete SOCKT[k]
    t = $2; stamp = $3 " " $4; sec = ""; cur_share = 0; cur_nfs = 0; cur_sock = ""
    next
}
/^@END$/ {
    if (!have) { header(); have = 1 }
    else {
        dt = t - pt
        compute()
        line = sprintf("%d", t) "," q(stamp)
        for (i = 3; i <= nh; i++) line = line "," M[H[i]]
        print line; fflush()
    }
    for (k in P) delete P[k]
    for (k in C) P[k] = C[k]
    pt = t
    next
}
/^@[A-Z]+$/ { sec = substr($0, 2); next }
sec == "DEV"     { p_dev(); next }
sec == "DISK"    { p_disk(); next }
sec == "STAT"    { p_stat(); next }
sec == "MEM"     { p_kv("mem"); next }
sec == "VM"      { C["vm", $1] = $2; next }
sec == "SNMP" || sec == "NETSTAT" { p_snmp(); next }
sec == "PSI"     { p_psi(); next }
sec == "LOAD"    { C["load"] = $1; next }
sec == "CIFS"    { p_cifs(); next }
sec == "NFS"     { p_nfs(); next }
sec == "SS"      { p_ss(); next }
sec == "THERM"   { if ($1 ~ /^-?[0-9]+$/ && (C["therm"] == "" || $1 + 0 > C["therm"])) C["therm"] = $1 + 0; next }
