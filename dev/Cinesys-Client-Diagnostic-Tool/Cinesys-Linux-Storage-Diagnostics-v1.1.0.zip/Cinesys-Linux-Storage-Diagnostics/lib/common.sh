# Shared functions for the Cinesys Linux capture scripts. Sourced, not run.
# The caller sets CINESYS_ROOT (the toolkit folder) before sourcing.
# Written for bash 4.2+ (Debian 8 and later, Ubuntu 16.04 and later).

CINESYS_VERSION=$(cat "$CINESYS_ROOT/VERSION.txt")
CINESYS_STATE=/var/tmp/cinesys-linux-capture.state
CINESYS_DEFAULT_OUTPUT=/var/tmp/Cinesys-Storage-Diagnostics
export LC_ALL=C

cs_now()   { date '+%Y-%m-%d %H:%M:%S'; }
cs_epoch() { date '+%s'; }

# Messages go to the screen and, once a capture folder exists, to Capture-Log.txt.
cs_log() {
    printf '%s\n' "$*"
    if [[ -n ${CAP:-} && -d $CAP ]]; then printf '%s  %s\n' "$(cs_now)" "$*" >> "$CAP/Capture-Log.txt"; fi
}
cs_warn() {
    printf 'WARNING: %s\n' "$*" >&2
    if [[ -n ${CAP:-} && -d $CAP ]]; then
        printf '%s  WARNING: %s\n' "$(cs_now)" "$*" >> "$CAP/Capture-Log.txt"
        printf '%s\n' "$*" >> "$CAP/Raw/warnings.txt"
    fi
}
cs_die() { printf 'ERROR: %s\n' "$*" >&2; exit 1; }

cs_json() {
    # JSON string literal
    local s=$1
    s=${s//\\/\\\\}; s=${s//\"/\\\"}; s=${s//$'\t'/\\t}; s=${s//$'\r'/}; s=${s//$'\n'/\\n}
    printf '"%s"' "$s"
}

cs_is_root() { [[ $EUID -eq 0 ]]; }
cs_in()      { local x k=$1; shift; for x in "$@"; do [[ $x == "$k" ]] && return 0; done; return 1; }
cs_have()    { command -v "$1" >/dev/null 2>&1; }

# Runs a command with a time limit (coreutils timeout is always present).
cs_timeout() { local s=$1; shift; timeout -k 2 "$s" "$@"; }

cs_bytes_h() {
    local b=${1:-0}
    if (( b >= 1073741824 )); then awk -v b="$b" 'BEGIN{printf "%.1f GB", b/1073741824}'
    elif (( b >= 1048576 )); then awk -v b="$b" 'BEGIN{printf "%.1f MB", b/1048576}'
    else printf '%d KB' $(( b / 1024 )); fi
}
# systemd-detect-virt prints "none" and exits 1 on bare metal
cs_virt()      { local v; v=$(systemd-detect-virt 2>/dev/null); echo "${v:-unknown}"; }
cs_dmi()       { cat "/sys/class/dmi/id/$1" 2>/dev/null; }
cs_dir_bytes() { du -sb "$1" 2>/dev/null | awk '{print $1}'; }

# ---------------------------------------------------------------------------
# Interfaces
# ---------------------------------------------------------------------------
# "dev ip prefixlen" for every IPv4 address
cs_ipv4_table() {
    ip -o -4 addr show 2>/dev/null | awk '{split($4, a, "/"); print $2, a[1], a[2]}'
}

cs_if_kind() {
    # wifi, bond, bridge, vlan, team, tunnel, virtual, ethernet
    local i=$1 d=/sys/class/net/$1
    [[ -d $d/wireless || -d $d/phy80211 ]] && { echo wifi; return; }
    [[ -d $d/bonding ]] && { echo bond; return; }
    [[ -d $d/bridge ]] && { echo bridge; return; }
    [[ -f /proc/net/vlan/$i ]] && { echo vlan; return; }
    case $i in tun*|tap*|wg*|ppp*|ipsec*|vti*|gre*|zt*|tailscale*) echo tunnel; return ;; esac
    [[ -e $d/device ]] && { echo ethernet; return; }
    echo virtual
}
cs_is_wifi()   { [[ $(cs_if_kind "$1") == wifi ]]; }
cs_is_tunnel() { [[ $(cs_if_kind "$1") == tunnel ]]; }

cs_if_speed()  { local s; s=$(cat /sys/class/net/$1/speed 2>/dev/null); [[ $s =~ ^[0-9]+$ && $s -gt 0 ]] && echo "$s"; }
cs_if_duplex() { cat /sys/class/net/$1/duplex 2>/dev/null; }
cs_if_mtu()    { cat /sys/class/net/$1/mtu 2>/dev/null; }
cs_if_state()  { cat /sys/class/net/$1/operstate 2>/dev/null; }
cs_if_driver() { local l; l=$(readlink /sys/class/net/$1/device/driver 2>/dev/null) && echo "${l##*/}"; }

cs_if_label() {
    # "ens1f0 (ice, 25000 Mb/s)" / "wlp2s0 (Wi-Fi)" / "bond0 (bond)"
    local i=$1 k drv sp
    k=$(cs_if_kind "$i"); drv=$(cs_if_driver "$i"); sp=$(cs_if_speed "$i")
    case $k in
        wifi) echo "$i (Wi-Fi${drv:+, $drv})" ;;
        ethernet) echo "$i (${drv:-ethernet}${sp:+, $sp Mb/s})" ;;
        *) echo "$i ($k${sp:+, $sp Mb/s})" ;;
    esac
}

cs_ip2int() {
    local IFS=.; local -a o=($1)
    (( ${#o[@]} == 4 )) || { echo 0; return; }
    echo $(( (o[0] << 24) + (o[1] << 16) + (o[2] << 8) + o[3] ))
}
cs_is_ipv4() { [[ $1 =~ ^[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}$ ]]; }

cs_resolve() {
    # name or IP -> IPv4
    if cs_is_ipv4 "$1"; then echo "$1"; return; fi
    local ip
    ip=$(getent ahostsv4 "$1" 2>/dev/null | awk 'NR==1{print $1}')
    echo "${ip:-$1}"
}

cs_route_if() { ip -o route get "$1" 2>/dev/null | awk '{for(i=1;i<NF;i++) if($i=="dev"){print $(i+1); exit}}'; }
cs_route_gw() { ip -o route get "$1" 2>/dev/null | awk '{for(i=1;i<NF;i++) if($i=="via"){print $(i+1); exit}}'; }
cs_route_src(){ ip -o route get "$1" 2>/dev/null | awk '{for(i=1;i<NF;i++) if($i=="src"){print $(i+1); exit}}'; }
cs_default_gw() { ip -o -4 route show default 2>/dev/null | awk '{for(i=1;i<NF;i++) if($i=="via"){print $(i+1); exit}}'; }
cs_default_if() { ip -o -4 route show default 2>/dev/null | awk '{for(i=1;i<NF;i++) if($i=="dev"){print $(i+1); exit}}'; }

# "localip localport remoteip remoteport" for every established IPv4 TCP connection
cs_tcp_est() {
    ss -Htn4 state established 2>/dev/null | awk '{
        l = $3; r = $4; lp = l; sub(/.*:/, "", lp); sub(/:[^:]*$/, "", l); rp = r; sub(/.*:/, "", rp); sub(/:[^:]*$/, "", r)
        sub(/%.*/, "", l); print l, lp, r, rp }'
}

# Live TCP connections to an IP, by local address: "localip dev ports"
cs_conn_ifs() {
    local srv=$1 tbl
    tbl=$(cs_ipv4_table)
    cs_tcp_est | awk -v s="$srv" '$3 == s { if (!(($1, $4) in seen)) { seen[$1, $4] = 1; p[$1] = p[$1] (p[$1] == "" ? "" : ",") $4 } }
        END { for (l in p) print l, p[l] }' | while read -r ip ports; do
        local dev
        dev=$(awk -v ip="$ip" '$2 == ip {print $1; exit}' <<< "$tbl")
        [[ $ip == 127.* ]] && dev=lo
        echo "$ip ${dev:-unknown} $ports"
    done
}

# ---------------------------------------------------------------------------
# Network file system mounts
# ---------------------------------------------------------------------------
# "mountpoint|server|share|fstype|options" for cifs/smb3 mounts
cs_smb_mounts() {
    awk '$3 == "cifs" || $3 == "smb3" {
        src = $1; gsub(/\\040/, " ", src); mp = $2; gsub(/\\040/, " ", mp)
        sub(/^\/\//, "", src); srv = src; sub(/\/.*/, "", srv); sh = src; sub(/^[^\/]*\//, "", sh)
        print mp "|" srv "|" sh "|" $3 "|" $4 }' /proc/mounts
}
# "mountpoint|server|export|fstype|options" for nfs/nfs4 mounts
cs_nfs_mounts() {
    awk '$3 == "nfs" || $3 == "nfs4" {
        src = $1; mp = $2; gsub(/\\040/, " ", mp)
        srv = src; sub(/:.*/, "", srv); gsub(/[\[\]]/, "", srv); ex = src; sub(/^[^:]*:/, "", ex)
        print mp "|" srv "|" ex "|" $3 "|" $4 }' /proc/mounts
}
# lsblk -d -P (KEY="value" pairs, so empty columns stay in place) -> "v|v|v"
cs_lsblk_pairs() {
    lsblk -d -n -P -o "$1" 2>/dev/null | awk -v keys="$1" '{
        n = split(keys, K, ","); out = ""
        for (i = 1; i <= n; i++) {
            v = ""
            if (match($0, "(^| )" K[i] "=\"[^\"]*\"")) { v = substr($0, RSTART, RLENGTH); sub(/^ /, "", v); v = substr(v, length(K[i]) + 3); sub(/"$/, "", v) }
            out = out (i > 1 ? "|" : "") v
        }
        print out }'
}

cs_mount_opt() {
    # options-string name -> value ("" if absent, "yes" for a flag)
    awk -v o="$1" -v k="$2" 'BEGIN { n = split(o, a, ","); for (i = 1; i <= n; i++) {
        if (a[i] == k) { print "yes"; exit } if (index(a[i], k "=") == 1) { print substr(a[i], length(k) + 2); exit } } }'
}

# ---------------------------------------------------------------------------
# State and processes
# ---------------------------------------------------------------------------
cs_read_state() {
    [[ -f $CINESYS_STATE ]] || return 1
    CAP=$(cat "$CINESYS_STATE")
    [[ -d $CAP ]] || return 1
}

# Is PID still the process we started? (its command line contains the match text)
cs_pid_is() {
    local cmd
    [[ -r /proc/$1/cmdline ]] || return 1
    cmd=$(tr '\0' ' ' < /proc/$1/cmdline 2>/dev/null)
    [[ $cmd == *"$2"* ]]
}

# Stops a collector: its process group first (setsid makes each one a group).
cs_stop_pid() {
    local pid=$1 i
    kill -TERM -- -"$pid" 2>/dev/null || kill -TERM "$pid" 2>/dev/null
    for i in $(seq 1 25); do kill -0 "$pid" 2>/dev/null || return 0; sleep 0.2; done
    kill -KILL -- -"$pid" 2>/dev/null || kill -KILL "$pid" 2>/dev/null
}

# ---------------------------------------------------------------------------
# Path MTU: don't-fragment pings
# ---------------------------------------------------------------------------
# cs_pmtu_probe <ip> <payload> [count] -> ok | toobig (a router answered
# "fragmentation needed") | local (this machine refused: bigger than its MTU)
# | silent (no answer)
cs_pmtu_probe() {
    local out
    out=$(ping -n -M do -s "$2" -c "${3:-2}" -W 1 "$1" 2>&1)
    if grep -q 'bytes from' <<< "$out"; then echo ok
    elif grep -qiE 'frag needed|mtu = [0-9]' <<< "$out"; then echo toobig
    elif grep -qi 'message too long' <<< "$out"; then echo local
    else echo silent; fi
}

# cs_pmtu <ip> <interface mtu> -> "Result LargestPassing Probe1500 ProbeAtMtu"
#   Result: OK | SilentDrop (switch port, VLAN or target interface at a smaller
#   MTU) | RouterRefused (a routed hop answered "fragmentation needed") |
#   NoReply (ICMP blocked: not testable)
cs_pmtu() {
    local ip=$1 mtu=${2:-1500} base big="-" lo hi mid r fail bp
    (( mtu < 1500 )) && bp=$(( mtu - 28 )) || bp=1472
    base=$(cs_pmtu_probe "$ip" "$bp")
    if [[ $base != ok ]]; then
        [[ $(cs_pmtu_probe "$ip" 32) == ok ]] || { echo "NoReply - $base -"; return; }
        lo=32; hi=$bp; fail=$base
    elif (( mtu > 1500 )); then
        big=$(cs_pmtu_probe "$ip" $(( mtu - 28 )))
        [[ $big == ok ]] && { echo "OK $mtu $base $big"; return; }
        lo=$bp; hi=$(( mtu - 28 )); fail=$big
    else
        echo "OK $(( bp + 28 )) $base -"; return
    fi
    while (( hi - lo > 1 )); do
        mid=$(( (lo + hi) / 2 ))
        r=$(cs_pmtu_probe "$ip" "$mid" 1)
        if [[ $r == ok ]]; then lo=$mid; else hi=$mid; [[ $r == toobig ]] && fail=toobig; fi
    done
    if [[ $fail == toobig ]]; then echo "RouterRefused $(( lo + 28 )) $base $big"; else echo "SilentDrop $(( lo + 28 )) $base $big"; fi
}
