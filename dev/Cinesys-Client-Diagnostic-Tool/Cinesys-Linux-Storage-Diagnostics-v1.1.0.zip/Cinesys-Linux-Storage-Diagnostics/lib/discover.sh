# What to watch: storage targets, SMB and NFS mounts, disks, adapters.
# Sourced after common.sh and detect.sh by Start-CinesysCapture.sh and
# Get-CinesysStorageInfo.sh.
#
#   cs_discover <storage report file>
#
# In:  ARG_SERVERS (from --target; may be empty)
# Out: SERVER_IPS (every storage target), SERVER_NAME, TARGET_ROLE,
#      SMB_SERVERS, MOUNTS + MOUNT_INST/MOUNT_SERVER (SMB),
#      NFS_MOUNTS + NFS_INST/NFS_SERVER, DISKS + DISK_INST,
#      STORAGE_IFS (adapters with live connections to a target),
#      WATCH_IFS (those plus every adapter with an IPv4 address), IF_INST

SERVER_IPS=(); SMB_SERVERS=(); MOUNTS=(); NFS_MOUNTS=(); DISKS=(); STORAGE_IFS=(); WATCH_IFS=()
declare -A SERVER_NAME=() TARGET_ROLE=() MOUNT_INST=() MOUNT_SERVER=() NFS_INST=() NFS_SERVER=() DISK_INST=() IF_INST=()

cs_add_role() {
    local cur=${TARGET_ROLE[$1]:-}
    [[ ", $cur, " == *", $2, "* ]] && return
    TARGET_ROLE[$1]=${cur:+$cur, }$2
}

cs_add_target() {
    # ip: adds it unless --target limited the list
    if (( ${#ARG_SERVERS[@]} )); then cs_in "$1" "${SERVER_IPS[@]}"; return; fi
    cs_in "$1" "${SERVER_IPS[@]}" || SERVER_IPS+=("$1")
}

# Instance name for an adapter in the CSV: "ens1f0 ice", "wlp2s0 Wi-Fi", "bond0 bond"
cs_if_inst() {
    local k drv
    k=$(cs_if_kind "$1"); drv=$(cs_if_driver "$1")
    case $k in wifi) echo "$1 Wi-Fi" ;; ethernet) echo "$1 ${drv:-ethernet}" ;; *) echo "$1 $k" ;; esac
}

cs_discover() {
    local s ip mp srv share fst opts line c r i d
    for s in "${ARG_SERVERS[@]}"; do
        ip=$(cs_resolve "$s")
        cs_is_ipv4 "$ip" || cs_die "Cannot resolve '$s' to an IPv4 address."
        cs_in "$ip" "${SERVER_IPS[@]}" || SERVER_IPS+=("$ip")
        [[ $s != "$ip" ]] && SERVER_NAME[$ip]=$s
        cs_add_role "$ip" "named with --target"
    done

    # SMB mounts (per-share counters come from /proc/fs/cifs/Stats)
    while IFS='|' read -r mp srv share fst opts; do
        [[ -z $mp ]] && continue
        ip=$(cs_mount_opt "$opts" addr); cs_is_ipv4 "$ip" || ip=$(cs_resolve "$srv")
        cs_add_target "$ip" || continue
        [[ $srv != "$ip" ]] && SERVER_NAME[$ip]=$srv
        # /proc/fs/cifs/Stats names the tree connect: \\server\share, without any subfolder of the mount
        MOUNTS+=("$mp"); MOUNT_INST[$mp]="\\\\$srv\\${share%%/*}"; MOUNT_SERVER[$mp]=$ip
        cs_in "$ip" "${SMB_SERVERS[@]}" || SMB_SERVERS+=("$ip")
        cs_add_role "$ip" "SMB server"
    done < <(cs_smb_mounts)

    # NFS mounts (per-mount counters come from /proc/self/mountstats)
    while IFS='|' read -r mp srv share fst opts; do
        [[ -z $mp ]] && continue
        ip=$(cs_mount_opt "$opts" addr); cs_is_ipv4 "$ip" || ip=$(cs_resolve "$srv")
        cs_add_target "$ip" || continue
        [[ $srv != "$ip" ]] && SERVER_NAME[$ip]=$srv
        NFS_MOUNTS+=("$mp"); NFS_INST[$mp]="$srv:$share"; NFS_SERVER[$mp]=$ip
        cs_add_role "$ip" "NFS server"
    done < <(cs_nfs_mounts)

    # Everything else the detectors found
    cs_detect "$1"
    local -a f
    for line in "${CS_DET[@]}"; do
        IFS='|' read -r -a f <<< "$line"
        ip=${f[1]}
        cs_is_ipv4 "$ip" && [[ $ip != 127.* ]] || continue
        local role=""
        case "${f[0]} ${f[4]}" in
            "SMB "*) role="SMB server"; cs_in "$ip" "${SMB_SERVERS[@]}" || SMB_SERVERS+=("$ip") ;;
            "NFS "*) role="NFS server" ;;
            "STORNEXT mdc") role="StorNext metadata controller" ;;
            "STORNEXT gateway"|"STORNEXT flow") [[ ${f[5]} == *metadata* ]] && role="StorNext metadata controller" || role="StorNext DLC gateway" ;;
            "ISCSI "*) role="iSCSI portal" ;;
            "NEXIS "*) role="Avid NEXIS host" ;;
            "NVMEOF "*) role="NVMe-oF target" ;;
            *) continue ;;
        esac
        cs_add_target "$ip" || continue
        cs_add_role "$ip" "$role"
    done

    # Disks: whole devices, not partitions; multipath maps by name
    for d in /sys/block/*; do
        d=${d##*/}
        case $d in loop*|ram*|zram*|sr*|fd*|nbd*) continue ;; esac
        [[ $(cat /sys/block/$d/size 2>/dev/null) == 0 ]] && continue
        DISKS+=("$d")
        if [[ -f /sys/block/$d/dm/name ]]; then DISK_INST[$d]="$d $(cat /sys/block/$d/dm/name)"; else DISK_INST[$d]=$d; fi
    done

    # Adapters: the ones live connections to a target use, the route to
    # each target, then every other adapter with an IPv4 address.
    for s in "${SERVER_IPS[@]}"; do
        while read -r c r rest; do [[ -n $r && $r != unknown && $r != lo ]] && STORAGE_IFS+=("$r"); done < <(cs_conn_ifs "$s")
        r=$(cs_route_if "$s"); [[ -n $r && $r != lo ]] && ! cs_in "$r" "${WATCH_IFS[@]}" && WATCH_IFS+=("$r")
    done
    local -a u=()
    for i in "${STORAGE_IFS[@]}"; do cs_in "$i" "${u[@]}" || u+=("$i"); done
    STORAGE_IFS=("${u[@]}")
    u=("${STORAGE_IFS[@]}")
    for i in "${WATCH_IFS[@]}"; do cs_in "$i" "${u[@]}" || u+=("$i"); done
    while read -r i rest; do
        [[ -z $i || $i == lo ]] && continue
        cs_in "$i" "${u[@]}" || u+=("$i")
    done < <(cs_ipv4_table)
    # bond and team members carry the traffic too
    for i in "${u[@]}"; do
        [[ -f /sys/class/net/$i/bonding/slaves ]] || continue
        for s in $(cat /sys/class/net/$i/bonding/slaves); do cs_in "$s" "${u[@]}" || u+=("$s"); done
    done
    WATCH_IFS=("${u[@]}")
    for i in "${WATCH_IFS[@]}"; do IF_INST[$i]=$(cs_if_inst "$i"); done
}
