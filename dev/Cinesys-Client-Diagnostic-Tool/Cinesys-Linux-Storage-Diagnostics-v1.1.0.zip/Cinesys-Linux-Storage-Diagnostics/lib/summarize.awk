# Statistics and throughput drops from Cinesys-Performance.csv (Linux edition).
#   awk -v stalls=Stalls.csv -v mindrop=2 -v names="nas01=10.1.2.3" -f summarize.awk Cinesys-Performance.csv
# Prints the body of Capture-Summary.txt; writes one Stalls.csv row per drop.

BEGIN {
    FS = ","; MB = 1048576
    # server name -> IP, for shares mounted by name ("nas01=10.1.2.3;...")
    n = split(names, NP, ";"); for (i = 1; i <= n; i++) { split(NP[i], kv, "="); if (kv[1] != "") NAMEIP[kv[1]] = kv[2] }
    # target IP -> role ("10.1.2.3=StorNext DLC gateway;...")
    n = split(roles, NP, ";"); for (i = 1; i <= n; i++) { k = index(NP[i], "="); if (k) ROLE[substr(NP[i], 1, k - 1)] = substr(NP[i], k + 1) }
}

function unq(s) { gsub(/"/, "", s); return s }
function num(s) { return (s == "") ? "" : s + 0 }
# "10/15/2026 16:34:16.769" -> "2026-10-15 16:34:16"
function iso(t) { t = unq(t); return substr(t, 7, 4) "-" substr(t, 1, 2) "-" substr(t, 4, 2) " " substr(t, 12, 8) }

function qsort(A, lo, hi,   i, last, t) {
    if (lo >= hi) return
    t = A[lo]; A[lo] = A[int((lo + hi) / 2)]; A[int((lo + hi) / 2)] = t
    last = lo
    for (i = lo + 1; i <= hi; i++) if (A[i] < A[lo]) { last++; t = A[last]; A[last] = A[i]; A[i] = t }
    t = A[lo]; A[lo] = A[last]; A[last] = t
    qsort(A, lo, last - 1); qsort(A, last + 1, hi)
}
# percentile of column c over all rows (or only rows where column g >= gmin)
function pct(c, p, g, gmin,   n, i, A) {
    n = 0
    for (i = 1; i <= rows; i++) {
        if (V[i, c] == "") continue
        if (g && (V[i, g] == "" || V[i, g] < gmin)) continue
        A[++n] = V[i, c]
    }
    if (n == 0) return ""
    qsort(A, 1, n)
    return A[int((n - 1) * p) + 1]
}
function mx(c,   i, m) { m = ""; for (i = 1; i <= rows; i++) if (V[i, c] != "" && (m == "" || V[i, c] > m)) m = V[i, c]; return m }
function mn(c,   i, m) { m = ""; for (i = 1; i <= rows; i++) if (V[i, c] != "" && (m == "" || V[i, c] < m)) m = V[i, c]; return m }
function sum(c,   i, s) { s = 0; for (i = 1; i <= rows; i++) if (V[i, c] != "") s += V[i, c]; return s }
function avgwhere(c, g, gmin,   i, s, n) { s = 0; n = 0; for (i = 1; i <= rows; i++) if (V[i, c] != "" && V[i, g] != "" && V[i, g] >= gmin) { s += V[i, c]; n++ } return n ? s / n : "" }
function f1(x) { return (x == "") ? "n/a" : sprintf("%.1f", x) }
function f0(x) { return (x == "") ? "n/a" : sprintf("%.0f", x) }
function mbs(x) { return (x == "") ? "n/a" : sprintf("%.1f MB/s", x / MB) }
function rmax(c, a, b,   i, m) { m = ""; for (i = a; i <= b; i++) if (i >= 1 && i <= rows && V[i, c] != "" && (m == "" || V[i, c] > m)) m = V[i, c]; return m }
function rsum(c, a, b,   i, s) { s = 0; for (i = a; i <= b; i++) if (i >= 1 && i <= rows && V[i, c] != "") s += V[i, c]; return s }
function ravg(c, a, b,   i, s, n) { s = 0; n = 0; for (i = a; i <= b; i++) if (i >= 1 && i <= rows && V[i, c] != "") { s += V[i, c]; n++ } return n ? s / n : "" }

# Header names are quoted and can contain commas ("Processor Information(0,3)");
# data rows are plain numbers.
function splithdr(line, H,   n, q, i, ch, f) {
    n = 0; q = 0; f = ""
    for (i = 1; i <= length(line); i++) {
        ch = substr(line, i, 1)
        if (ch == "\"") q = !q
        else if (ch == "," && !q) { H[++n] = f; f = "" }
        else f = f ch
    }
    H[++n] = f
    return n
}

NR == 1 {
    nh = splithdr($0, HDR)
    for (i = 2; i <= nh; i++) {
        h = HDR[i]; sub(/^\\\\[^\\]+\\/, "", h)
        obj = h; sub(/[(\\].*/, "", obj)
        inst = ""; if (h ~ /\(/) { inst = h; sub(/^[^(]*\(/, "", inst); sub(/\)\\[^\\]*$/, "", inst) }
        ctr = h; sub(/.*\\/, "", ctr)
        O[i] = obj; I[i] = inst; C[i] = ctr; ncol = nh
        if (obj == "Processor Information" && inst ~ /^0,[0-9]+$/) corecols[++ncores] = i
    }
    next
}
{
    rows++; T[rows] = $1
    for (i = 2; i <= NF; i++) V[rows, i] = num($i)
}

function col(o, inst, c,   i) { for (i = 2; i <= ncol; i++) if (O[i] == o && I[i] == inst && C[i] == c) return i; return 0 }

END {
    if (rows == 0) { print "No samples were recorded."; exit }
    printf "Samples: %d, from %s to %s\n\n", rows, iso(T[1]), iso(T[rows])

    # busiest core per row
    if (ncores) for (r = 1; r <= rows; r++) { m = ""; for (k = 1; k <= ncores; k++) { v = V[r, corecols[k]]; if (v != "" && (m == "" || v > m)) m = v } BUSY[r] = m }

    # --- SMB shares --------------------------------------------------------
    print "SMB SHARES (bytes the SMB session sent and received, including protocol overhead)"
    print "------------------------------------------------------------------------------------"
    ns = 0
    for (i = 2; i <= ncol; i++) if (O[i] == "SMB Client Shares" && C[i] == "Read Bytes/sec") {
        ns++; inst = I[i]; rc = i; wc = col("SMB Client Shares", inst, "Write Bytes/sec"); dcc = col("SMB Client Shares", inst, "Disconnected")
        printf "%s\n", inst
        for (d = 1; d <= 2; d++) {
            c = (d == 1) ? rc : wc; dir = (d == 1) ? "read " : "write"
            p95 = pct(c, 0.95, c, MB); pk = mx(c); tot = sum(c)
            thr = (p95 == "") ? 0 : p95 * 0.25; if (thr < 5 * MB) thr = 5 * MB
            printf "    %s  peak %s, typical while active %s, p95 while active %s, total %.2f GB\n", dir, mbs(pk), mbs(avgwhere(c, c, thr)), mbs(p95), tot / 1073741824
        }
        if (dcc && mx(dcc) > 0) printf "    DISCONNECTED during the capture (%d second(s))\n", sum(dcc)
        SHARE[ns] = inst; SR[ns] = rc; SW[ns] = wc
        split(inst, parts, "\\"); srv = parts[3]; sub(/:[0-9]+$/, "", srv); if (srv in NAMEIP) srv = NAMEIP[srv]; SRV[ns] = srv
    }
    if (!ns) print "(no SMB share was mounted at Start)"
    print ""

    # --- NFS mounts ----------------------------------------------------------
    nn = 0
    for (i = 2; i <= ncol; i++) if (O[i] == "NFS Client Mounts" && C[i] == "Read Bytes/sec") {
        if (!nn++) { print "NFS MOUNTS (from /proc/self/mountstats)"; print "---------------------------------------" }
        inst = I[i]; rc = i; wc = col(O[i], inst, "Write Bytes/sec")
        printf "%s\n", inst
        for (d = 1; d <= 2; d++) {
            c = (d == 1) ? rc : wc; dir = (d == 1) ? "read " : "write"
            p95 = pct(c, 0.95, c, MB); pk = mx(c); tot = sum(c)
            thr = (p95 == "") ? 0 : p95 * 0.25; if (thr < 5 * MB) thr = 5 * MB
            printf "    %s  peak %s, typical while active %s, p95 while active %s, total %.2f GB\n", dir, mbs(pk), mbs(avgwhere(c, c, thr)), mbs(p95), tot / 1073741824
        }
        rr = col(O[i], inst, "Avg. Read RTT ms"); re = col(O[i], inst, "Avg. Read Execute ms"); wr = col(O[i], inst, "Avg. Write RTT ms"); we = col(O[i], inst, "Avg. Write Execute ms")
        printf "    per-request time, p95 / max: read RTT %s / %s ms, read total %s / %s ms; write RTT %s / %s ms, write total %s / %s ms\n", f1(pct(rr, 0.95)), f1(mx(rr)), f1(pct(re, 0.95)), f1(mx(re)), f1(pct(wr, 0.95)), f1(mx(wr)), f1(pct(we, 0.95)), f1(mx(we))
        cc = col(O[i], inst, "Connect Count"); a = mn(cc); b = mx(cc)
        printf "    RPC retransmissions %d, timeouts %d%s\n", sum(col(O[i], inst, "Retransmissions/sec")), sum(col(O[i], inst, "Timeouts/sec")), (a != "" && b > a) ? sprintf(", RECONNECTED %d time(s)", b - a) : ""
        ns++; SHARE[ns] = inst; SR[ns] = rc; SW[ns] = wc
        srv = inst; sub(/:.*/, "", srv); if (srv in NAMEIP) srv = NAMEIP[srv]; SRV[ns] = srv; NFSIP[srv] = 1
    }
    if (nn) print ""

    # --- Connections to the targets ----------------------------------------
    nc = 0
    for (i = 2; i <= ncol; i++) if ((O[i] == "SMB Client Connection" || O[i] == "Storage Connection") && C[i] == "Bytes Sent/sec") {
        if (!nc++) { print "STORAGE CONNECTIONS (TCP to each target, all ports, from ss)"; print "------------------------------------------------------------" }
        ip = I[i]; txc = i; rxc = col(O[i], ip, "Bytes Received/sec"); rtc = col(O[i], ip, "Retransmitted Bytes/sec")
        sqc = col(O[i], ip, "Send Queue Bytes"); rttc = col(O[i], ip, "Round Trip Time ms"); rwc = col(O[i], ip, "Receive Window Bytes")
        tx = sum(txc); rt = sum(rtc)
        printf "%s%s\n", ip, (ip in ROLE) ? " - " ROLE[ip] : ""
        printf "    received peak %s, sent peak %s\n", mbs(mx(rxc)), mbs(mx(txc))
        printf "    retransmitted %.1f MB of %.1f MB sent (%.2f%%), peak %s\n", rt / MB, tx / MB, tx ? 100 * rt / tx : 0, mbs(mx(rtc))
        printf "    largest send queue %s KB (data waiting for the server to acknowledge)\n", f0(mx(sqc) / 1024)
        printf "    round trip (smoothed) median %s ms, p95 %s ms, max %s ms; largest receive window %s KB\n", f1(pct(rttc, 0.5)), f1(pct(rttc, 0.95)), f1(mx(rttc)), f0(mx(rwc) / 1024)
        CONN_RT[ip] = rtc; CONN_RTT[ip] = rttc; CONN_TX[ip] = txc
        # Non-SMB targets have no share counters: their connection bytes are
        # what the drop search looks at.
        if (O[i] == "Storage Connection" && !(ip in NFSIP)) { ns++; SHARE[ns] = ip; SR[ns] = rxc; SW[ns] = txc; SRV[ns] = ip }
    }
    if (nc) print ""

    # --- Traffic no tracked protocol accounts for (Avid NEXIS is UDP) --------
    ur = col("Network Unattributed", "_Total", "Bytes Received/sec"); ut = col("Network Unattributed", "_Total", "Bytes Sent/sec")
    if (ur && (mx(ur) >= 5 * MB || mx(ut) >= 5 * MB)) {
        print "OTHER NETWORK TRAFFIC (physical adapters minus the storage connections above)"
        print "-------------------------------------------------------------------------------"
        if (nexis) print "The Avid NEXIS client is installed: its data is UDP, so it is counted here."
        for (d = 1; d <= 2; d++) {
            c = (d == 1) ? ur : ut; dir = (d == 1) ? "received" : "sent    "
            p95 = pct(c, 0.95, c, MB); thr = (p95 == "") ? 0 : p95 * 0.25; if (thr < 5 * MB) thr = 5 * MB
            printf "    %s peak %s, typical while active %s, total %.2f GB\n", dir, mbs(mx(c)), mbs(avgwhere(c, c, thr)), sum(c) / 1073741824
        }
        ns++; SHARE[ns] = (nexis ? "Avid NEXIS (other network traffic)" : "other network traffic"); SR[ns] = ur; SW[ns] = ut; SRV[ns] = ""
        print ""
    }

    # --- Adapters ----------------------------------------------------------
    print "ADAPTERS"
    print "--------"
    for (i = 2; i <= ncol; i++) if (O[i] == "Network Interface" && C[i] == "Bytes Received/sec") {
        inst = I[i]; tc = col(O[i], inst, "Bytes Sent/sec"); e1 = col(O[i], inst, "Packets Received Errors/sec"); e2 = col(O[i], inst, "Packets Outbound Errors/sec")
        d1 = col(O[i], inst, "Packets Received Discarded/sec"); d2 = col(O[i], inst, "Packets Outbound Discarded/sec")
        pr = mx(i); pt = mx(tc)
        if (pr < MB && pt < MB) { printf "%-28s idle (under 1 MB/s)%s\n", inst, (sum(d1) + sum(e1) > 0) ? sprintf(", discarded in %d, errors in %d", sum(d1), sum(e1)) : ""; continue }
        printf "%-28s receive peak %s, send peak %s, errors in %d / out %d, discarded in %d / out %d\n", inst, mbs(pr), mbs(pt), sum(e1), sum(e2), sum(d1), sum(d2)
    }
    print ""

    # --- TCP, memory, CPU, disks -------------------------------------------
    c = col("TCPv4", "", "Segments Retransmitted/sec")
    if (c) {
        printf "TCP (whole machine): %d segments retransmitted (peak %s/s), %d retransmit timeouts, %d out-of-order segments received, %d receive errors\n", sum(c), f0(mx(c)), sum(col("TCPv4", "", "Retransmit Timeouts/sec")), sum(col("TCPv4", "", "Out-of-Order Segments Received/sec")), sum(col("TCPv4", "", "Segments Received Errors/sec"))
    }
    c = col("UDPv4", "", "Datagrams Received/sec")
    if (c) printf "UDP (whole machine): peak %s datagrams/s received, %d receive errors, %d dropped because a socket buffer was full; IP fragments received %d, reassembly failures %d\n", f0(mx(c)), sum(col("UDPv4", "", "Datagrams Received Errors/sec")), sum(col("UDPv4", "", "Receive Buffer Errors/sec")), sum(col("IPv4", "", "Fragments Received/sec")), sum(col("IPv4", "", "Fragment Re-assembly Failures/sec"))
    print ""

    am = col("Memory", "", "Available MBytes"); dy = col("Memory", "", "Dirty MBytes"); wb = col("Memory", "", "Writeback MBytes"); so = col("Memory", "", "Swap Out Pages/sec")
    printf "MEMORY: available min %s MB / max %s MB, dirty (not yet written) max %s MB, under write-back max %s MB, swapped out %d pages\n", f0(mn(am)), f0(mx(am)), f0(mx(dy)), f0(mx(wb)), sum(so)
    pc = col("Pressure", "", "CPU Some %")
    if (pc) printf "PRESSURE (share of each second something waited): CPU max %s%%, memory max %s%% (all tasks %s%%), I/O max %s%% (all tasks %s%%)\n", f0(mx(pc)), f0(mx(col("Pressure", "", "Memory Some %"))), f0(mx(col("Pressure", "", "Memory Full %"))), f0(mx(col("Pressure", "", "IO Some %"))), f0(mx(col("Pressure", "", "IO Full %")))
    else print "PRESSURE: not available (kernel without PSI, or booted with psi=0)"
    tc = col("Processor Information", "_Total", "% Processor Time")
    printf "CPU: total peak %s%%", f0(mx(tc))
    if (ncores) {
        hot = 0; m = ""; for (r = 1; r <= rows; r++) { if (BUSY[r] != "" && BUSY[r] >= 95) hot++; if (BUSY[r] != "" && (m == "" || BUSY[r] > m)) m = BUSY[r] }
        printf ", busiest core peak %s%%, %d second(s) with a core at 95%% or more", f0(m), hot
    }
    printf ", I/O wait max %s%%, interrupts max %s%%, steal max %s%%", f0(mx(col("Processor Information", "_Total", "% IO Wait Time"))), f0(mx(col("Processor Information", "_Total", "% Interrupt Time"))), f0(mx(col("Processor Information", "_Total", "% Steal Time")))
    bp = col("System", "", "Processes Blocked"); if (bp && mx(bp) > 0) printf ", up to %d process(es) blocked on I/O", mx(bp)
    th = col("Thermal", "", "Max Zone Temperature C")
    if (th) printf ", hottest sensor max %s C", f0(mx(th))
    printf "\n\n"

    print "LOCAL DISKS"
    print "-----------"
    for (i = 2; i <= ncol; i++) if (O[i] == "PhysicalDisk" && C[i] == "Disk Read Bytes/sec") {
        inst = I[i]; wc = col(O[i], inst, "Disk Write Bytes/sec"); lr = col(O[i], inst, "Avg. Disk sec/Read"); lw = col(O[i], inst, "Avg. Disk sec/Write")
        if (mx(i) < 0.1 * MB && mx(wc) < 0.1 * MB) continue
        printf "%-12s read peak %s (p95 latency %s ms while reading), write peak %s (p95 latency %s ms while writing), queue max %s, busy max %s%%\n", inst, mbs(mx(i)), f1(pct(lr, 0.95, i, MB) * 1000), mbs(mx(wc)), f1(pct(lw, 0.95, wc, MB) * 1000), f0(mx(col(O[i], inst, "Current Disk Queue Length"))), f0(mx(col(O[i], inst, "% Disk Time")))
    }
    print ""

    # --- Throughput drops --------------------------------------------------
    print "THROUGHPUT DROPS"
    print "----------------"
    print "A drop: throughput on an SMB share, an NFS mount, or the connection to another storage"
    print "target (DLC gateway, iSCSI portal, NVMe/TCP), falls below 10% of its usual rate for"
    print mindrop " seconds or more and then recovers, inside an active transfer. The client"
    print "cannot see whether the application stopped asking or the server stopped"
    print "answering; compare with the server capture (Invoke-CinesysAnalysis.ps1)."
    print ""
    print "Share,Direction,Start,Seconds,BeforeMBps,DuringMBps,AfterMBps,RetransmittedKB,MaxRttMs,BusiestCorePct,MemoryStallPct,IoStallPct" > stalls
    nd = 0
    for (k = 1; k <= ns; k++) for (d = 1; d <= 2; d++) {
        c = (d == 1) ? SR[k] : SW[k]; dir = (d == 1) ? "read" : "write"
        p95 = pct(c, 0.95, c, MB); if (p95 == "" || p95 < 5 * MB) continue
        hi = p95 * 0.25; if (hi < 5 * MB) hi = 5 * MB; lo = p95 * 0.10
        srv = SRV[k]
        r = 1
        while (r <= rows) {
            if (V[r, c] == "" || V[r, c] < hi) { r++; continue }
            # r is active; find the next non-active run
            s = r + 1; while (s <= rows && V[s, c] != "" && V[s, c] >= hi) s++
            if (s > rows) break
            e = s; nlow = 0
            while (e <= rows && (V[e, c] == "" || V[e, c] < hi)) { if (V[e, c] != "" && V[e, c] < lo) nlow++; e++ }
            if (e <= rows && nlow >= mindrop && e - s <= 120) {
                nd++
                before = ravg(c, s - 3, s - 1); during = ravg(c, s, e - 1); after = ravg(c, e, e + 2)
                rtk = ""; rtm = ""
                if (srv in CONN_RT) { rtk = rsum(CONN_RT[srv], s, e - 1) / 1024; rtm = rmax(CONN_RTT[srv], s, e - 1) }
                bc = ""; if (ncores) { for (q = s; q <= e - 1; q++) if (BUSY[q] != "" && (bc == "" || BUSY[q] > bc)) bc = BUSY[q] }
                mp = rmax(col("Pressure", "", "Memory Some %"), s, e - 1); iop = rmax(col("Pressure", "", "IO Some %"), s, e - 1); iow = rmax(col("Processor Information", "_Total", "% IO Wait Time"), s, e - 1)
                printf "%s  %-5s %-28s %3d s  before %s, during %s, after %s", iso(T[s]), dir, SHARE[k], e - s, mbs(before), mbs(during), mbs(after)
                if (rtk != "" && rtk > 0) printf ", retransmitted %.0f KB", rtk
                if (rtm != "") printf ", RTT max %.1f ms", rtm
                if (bc != "" && bc >= 95) printf ", a CPU core at %.0f%%", bc
                if (mp != "" && mp >= 10) printf ", memory stalled %.0f%%", mp
                if (iop != "" && iop >= 10) printf ", I/O stalled %.0f%%", iop
                if (iow != "" && iow >= 20) printf ", I/O wait %.0f%%", iow
                printf "\n"
                printf "%s,%s,%s,%d,%.1f,%.1f,%.1f,%s,%s,%s,%s,%s\n", SHARE[k], dir, iso(T[s]), e - s, before / MB, during / MB, after / MB, (rtk == "" ? "" : sprintf("%.0f", rtk)), (rtm == "" ? "" : sprintf("%.1f", rtm)), (bc == "" ? "" : sprintf("%.0f", bc)), mp, iop > stalls
            }
            r = e
        }
    }
    if (!nd) print "(none found)"
    print ""
}
