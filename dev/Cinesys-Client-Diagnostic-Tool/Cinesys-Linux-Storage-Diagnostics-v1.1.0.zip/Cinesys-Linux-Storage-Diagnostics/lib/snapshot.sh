# Snapshots, hardware inventory and topology. Sourced by Start, Stop and
# Get-CinesysStorageInfo.sh after common.sh and the capture's Raw/config.sh.
#
#   cs_snapshot Pre|Post|Info   -> Snapshot-<when>.txt
#   cs_inventory                -> System-Inventory.txt / System-Inventory.json
#   cs_topology Pre|Post|Info   -> Topology-<when>.txt and Raw/findings-<when>.txt
#
# Every command here only reads or displays.

# Kernel log lines that matter for storage (used for counts and findings)
CS_KLOG_RE='CIFS|cifs|smb3|nfs:|NFS:|nfs4|server .* not responding|iscsi|iSCSI|connection[0-9]+:[0-9]+|scsi|sd [0-9]+:|blk_update_request|I/O error|Buffer I/O|nvme|multipath|device-mapper|qla2xxx|lpfc|rport|Link is Down|Link is Up|NIC Link|link down|link up|carrier|hung_task|blocked for more than|watchdog|cvfs|StorNext|reset|timed out|timeout|soft lockup'

# One section: title, then a command line run by bash with a time limit.
cs_sec() {
    printf '\n===== %s =====\n$ %s\n' "$1" "$2"
    cs_timeout "${3:-60}" bash -c "$2" 2>&1
}

cs_snapshot() {
    local when=$1 f=$CAP/Snapshot-$1.txt s i m mtu
    cs_log "Writing Snapshot-$when.txt ..."
    {
        echo "Cinesys Storage Diagnostics for Linux $CINESYS_VERSION - $when snapshot"
        echo "Host: $HOSTTAG   Written: $(cs_now)"

        cs_sec 'CLOCK' 'date; date -u; timedatectl 2>/dev/null; uptime'
        cs_sec 'TIME SYNC' 'chronyc tracking 2>/dev/null || timedatectl timesync-status 2>/dev/null || ntpq -pn 2>/dev/null || echo "(no chrony, timesyncd status or ntpq)"' 15
        cs_sec 'OPERATING SYSTEM' 'cat /etc/os-release; uname -a; hostnamectl 2>/dev/null; echo "virtualization: $(systemd-detect-virt 2>/dev/null)"'

        cs_sec 'NETWORK FILE SYSTEM MOUNTS' 'findmnt -n -o TARGET,SOURCE,FSTYPE,OPTIONS -t cifs,smb3,nfs,nfs4,cvfs,fuse.sshfs,ceph,glusterfs 2>/dev/null || grep -E " (cifs|smb3|nfs|nfs4|cvfs) " /proc/mounts'
        cs_sec 'FSTAB (network mounts)' 'grep -vE "^[[:space:]]*#" /etc/fstab | grep -E "cifs|smb3|nfs|cvfs|_netdev|x-systemd.automount"'
        cs_sec 'SMB CLIENT (cifs) STATISTICS' '[ -r /proc/fs/cifs/Stats ] && cat /proc/fs/cifs/Stats || echo "(cifs module not loaded)"'
        cs_sec 'SMB CLIENT (cifs) SESSIONS' '[ -r /proc/fs/cifs/DebugData ] && cat /proc/fs/cifs/DebugData || echo "(not available)"'
        cs_sec 'SMB CLIENT (cifs) MODULE' 'modinfo -F version cifs 2>/dev/null; cat /sys/module/cifs/parameters/* 2>/dev/null | head -20'
        if (( ${#NFS_MOUNTS[@]} )) || grep -qE ' nfs4? ' /proc/mounts; then
            cs_sec 'NFS MOUNT OPTIONS' 'nfsstat -m 2>/dev/null || grep -E " nfs4? " /proc/mounts'
            cs_sec 'NFS CLIENT RPC STATISTICS' 'nfsstat -c 2>/dev/null || cat /proc/net/rpc/nfs'
            cs_sec 'NFS MOUNT STATISTICS (/proc/self/mountstats)' 'awk "/^device /{on = (\$0 ~ / fstype nfs/)} on" /proc/self/mountstats'
            cs_sec 'NFS CLIENT SETTINGS' 'grep -vE "^[[:space:]]*(#|$)" /etc/nfsmount.conf 2>/dev/null; cat /sys/module/nfs/parameters/* 2>/dev/null | head -20; sysctl sunrpc 2>/dev/null'
        fi
        for s in "${SERVER_IPS[@]}"; do
            cs_sec "TCP CONNECTIONS TO $s (${TARGET_ROLE[$s]:-})" "ss -tinm state established '( dst $s )'"
        done

        cs_sec 'ADDRESSES' 'ip -d addr show'
        cs_sec 'LINK STATISTICS' 'ip -s -s link show'
        cs_sec 'ROUTING TABLE (all tables)' 'ip route show table all'
        cs_sec 'ROUTING RULES' 'ip rule show'
        cs_sec 'DEFAULT ROUTE' 'ip route get 1.1.1.1 2>/dev/null; ip -4 route show default'
        cs_sec 'NEIGHBORS (ARP)' 'ip neigh show'
        cs_sec 'DNS' 'resolvectl status 2>/dev/null || cat /etc/resolv.conf'
        cs_sec 'NETWORK MANAGER' 'command -v nmcli >/dev/null && nmcli -f GENERAL,IP4,WIRED-PROPERTIES device show 2>/dev/null || networkctl status 2>/dev/null || echo "(no NetworkManager or networkd)"'
        cs_sec 'NETWORK CONFIGURATION FILES (secrets removed)' 'ls -la /etc/netplan /etc/network 2>/dev/null; for f in /etc/network/interfaces /etc/network/interfaces.d/* /etc/netplan/*.yaml; do [ -f "$f" ] || continue; echo "--- $f"; grep -viE "psk|password|secret|key" "$f"; done'
        cs_sec 'BONDS' 'for b in /proc/net/bonding/*; do [ -f "$b" ] && { echo "--- $b"; cat "$b"; }; done; true'
        cs_sec 'BRIDGES AND VLANS' 'bridge link 2>/dev/null; cat /proc/net/vlan/config 2>/dev/null; true'
        cs_sec 'QUEUEING (tc qdisc)' 'tc -s qdisc show'
        for i in "${WATCH_IFS[@]}"; do
            if cs_have ethtool; then
                cs_sec "ADAPTER $i" "ethtool $i; ethtool -i $i; ethtool -a $i; ethtool -g $i; ethtool -l $i; ethtool -c $i" 20
                cs_sec "ADAPTER $i OFFLOADS" "ethtool -k $i | grep -E 'segmentation|receive-offload|scatter|checksum|rx-vlan|large-receive'" 15
                cs_sec "ADAPTER $i STATISTICS (non-zero)" "ethtool -S $i | awk -F: '\$2+0 != 0'" 15
            fi
            local pci; pci=$(readlink -f /sys/class/net/$i/device 2>/dev/null)
            [[ -e $pci/current_link_speed ]] && cs_sec "ADAPTER $i PCIe LINK" "for a in current_link_speed current_link_width max_link_speed max_link_width numa_node; do printf '%-20s %s\n' \$a \"\$(cat $pci/\$a 2>/dev/null)\"; done" 10
            cs_is_wifi "$i" && cs_sec "WI-FI $i" "iw dev $i link 2>/dev/null; iw dev $i info 2>/dev/null" 10
        done

        cs_sec 'TCP SUMMARY' 'ss -s'
        cs_sec 'TCP CONNECTION STATES' 'ss -Htan | awk "{s[\$1]++} END {for (k in s) print k, s[k]}"'
        cs_sec 'TCP CONNECTIONS PER APPLICATION' 'ss -Htnp 2>/dev/null | grep -o "users:((\"[^\"]*" | cut -d\" -f2 | sort | uniq -c | sort -rn'
        cs_sec 'ACTIVE SOCKETS' 'ss -tanp; ss -uanp' 30
        cs_sec 'PROTOCOL STATISTICS' 'nstat -asz 2>/dev/null || { cat /proc/net/snmp; cat /proc/net/netstat; }' 30
        cs_sec 'NETWORK SETTINGS (sysctl net.core, net.ipv4)' 'sysctl -a 2>/dev/null | grep -E "^net\.(core|ipv4)\."' 30
        cs_sec 'MEMORY AND WRITE-BACK SETTINGS (sysctl vm)' 'sysctl vm 2>/dev/null'
        if cs_is_root; then
            cs_sec 'FIREWALL (nftables)' 'nft list ruleset 2>/dev/null || echo "(nft not available)"' 20
            cs_sec 'FIREWALL (iptables)' 'iptables-save 2>/dev/null || echo "(iptables not available)"' 20
        fi
        cs_sec 'INTERRUPTS (adapter queues and CPUs)' 'cat /proc/interrupts' 15
        cs_sec 'SOFT INTERRUPTS' 'cat /proc/softirqs' 15
        cs_sec 'CPU FREQUENCY GOVERNOR' 'cat /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor 2>/dev/null | sort | uniq -c; cat /sys/devices/system/cpu/intel_pstate/status 2>/dev/null; tuned-adm active 2>/dev/null; systemctl is-active irqbalance 2>/dev/null; true'

        for s in "${SERVER_IPS[@]}"; do
            cs_sec "ROUTE TO $s" "ip route get $s"
            cs_sec "PING $s" "ping -n -c 5 -W 2 $s" 20
            cs_sec "PING $s 1500-BYTE PACKETS, DON'T FRAGMENT" "ping -n -M do -s 1472 -c 3 -W 2 $s" 15
            for i in "${WATCH_IFS[@]}"; do
                mtu=$(cs_if_mtu "$i")
                if (( ${mtu:-0} > 1500 )); then
                    cs_sec "PING $s 9000-BYTE PACKETS, DON'T FRAGMENT" "ping -n -M do -s 8972 -c 3 -W 2 $s" 15
                    break
                fi
            done
            [[ -n $(cs_route_gw "$s") ]] && cs_have tracepath && cs_sec "PATH TO $s" "tracepath -n -m 12 $s" 25
        done

        cs_sec 'POWER AND THERMAL' 'for z in /sys/class/thermal/thermal_zone*; do [ -d "$z" ] && echo "$(cat $z/type 2>/dev/null): $(( $(cat $z/temp 2>/dev/null || echo 0) / 1000 )) C"; done; for p in /sys/class/power_supply/*; do [ -d "$p" ] && echo "$(basename $p): $(cat $p/type 2>/dev/null) $(cat $p/status 2>/dev/null) $(cat $p/online 2>/dev/null)"; done; command -v sensors >/dev/null && sensors; true'
        cs_sec 'SERVICES (storage and network)' 'for u in iscsid open-iscsi multipathd nfs-client.target rpc-statd rpcbind autofs cvfs NetworkManager systemd-networkd systemd-resolved chrony systemd-timesyncd irqbalance; do printf "%-24s %s\n" $u "$(systemctl is-active $u 2>/dev/null)"; done'
        cs_sec 'FAILED SERVICES' 'systemctl --failed --no-pager 2>/dev/null'
        cs_sec 'RUNNING SERVICES' 'systemctl list-units --type=service --state=running --no-pager --no-legend 2>/dev/null' 20
        cs_sec 'SECURITY MODULES' 'aa-status --enabled 2>/dev/null && echo "AppArmor enabled"; getenforce 2>/dev/null; true'
        cs_sec 'PACKAGES (storage and network)' 'dpkg-query -W -f="\${Package} \${Version}\n" cifs-utils nfs-common open-iscsi multipath-tools nvme-cli ethtool tcpdump iproute2 linux-image-$(uname -r) 2>/dev/null'
        cs_sec 'KERNEL MODULES (storage and network)' 'lsmod | grep -iE "^(cifs|nfs|nfsv4|sunrpc|iscsi|libiscsi|scsi_transport|nvme|qla|lpfc|bfa|mlx|ixgbe|i40e|ice|igb|e1000|bnxt|tg3|r8169|atlantic|sfc|be2net|qede|cvfs|dm_multipath)"'

        cs_sec 'TOP PROCESSES' 'top -b -n 1 -w 200 | head -45' 15
        cs_sec 'PROCESSES (name only, no arguments)' 'ps -eo pid,ppid,user,stat,%cpu,%mem,rss,etime,comm --sort=-%cpu'
        cs_sec 'PROCESSES WAITING ON I/O (state D)' 'ps -eo pid,stat,wchan:32,etime,comm | awk "NR == 1 || \$2 ~ /D/"'
        cs_sec 'MEMORY' 'free -m; cat /proc/meminfo; swapon --show 2>/dev/null; for p in cpu memory io; do [ -r /proc/pressure/$p ] && { echo "--- pressure $p"; cat /proc/pressure/$p; }; done; true'
        cs_sec 'VOLUMES' 'df -hT -x tmpfs -x devtmpfs -x squashfs -x overlay'
        cs_sec 'BLOCK DEVICES' 'lsblk -o NAME,TYPE,TRAN,SIZE,ROTA,SCHED,MODEL,MOUNTPOINT 2>/dev/null || lsblk'

        if [[ $when != Post ]]; then
            # The hour before: every line in Raw/kernel-log-pre.txt; storage lines shown here.
            { journalctl -k --since "-1h" -o short-iso-precise --no-pager 2>/dev/null || dmesg -T 2>/dev/null; } > "$CAP/Raw/kernel-log-pre.txt"
            printf '\n===== KERNEL LOG, LAST HOUR (storage and network lines) =====\n'
            echo "$(wc -l < "$CAP/Raw/kernel-log-pre.txt") lines in all (Raw/kernel-log-pre.txt); storage and network lines, newest 200:"
            grep -E "$CS_KLOG_RE" "$CAP/Raw/kernel-log-pre.txt" | tail -200
        fi
    } > "$f" 2>&1
}

# ---------------------------------------------------------------------------
# Hardware inventory
# ---------------------------------------------------------------------------
cs_inventory() {
    cs_log "Writing System-Inventory.txt ..."
    local i k drv fw bus sp
    {
        echo "Cinesys Storage Diagnostics for Linux $CINESYS_VERSION - system inventory"
        echo "Written: $(cs_now)"
        echo ""
        echo "SUMMARY"
        echo "-------"
        printf '%-24s %s\n' 'Host name' "$(hostname -f 2>/dev/null || hostname)"
        printf '%-24s %s\n' 'Manufacturer / model' "$(cs_dmi sys_vendor) $(cs_dmi product_name) $(cs_dmi product_version)"
        printf '%-24s %s\n' 'Serial number' "$(cs_dmi product_serial || echo '(needs sudo)')"
        printf '%-24s %s\n' 'Board' "$(cs_dmi board_vendor) $(cs_dmi board_name)"
        printf '%-24s %s\n' 'BIOS' "$(cs_dmi bios_vendor) $(cs_dmi bios_version) ($(cs_dmi bios_date))"
        printf '%-24s %s\n' 'CPU' "$(lscpu | awk -F: '/^Model name/{gsub(/^ +/, "", $2); print $2; exit}')"
        printf '%-24s %s\n' 'Sockets / cores / threads' "$(lscpu | awk -F: '/^Socket\(s\)/{s=$2} /^Core\(s\) per socket/{c=$2} /^CPU\(s\)/{t=$2} END{gsub(/ /,"",s); gsub(/ /,"",c); gsub(/ /,"",t); print s " / " s*c " / " t}')"
        printf '%-24s %s\n' 'NUMA nodes' "$(lscpu | awk -F: '/^NUMA node\(s\)/{gsub(/ /, "", $2); print $2}')"
        printf '%-24s %s\n' 'Memory' "$(awk '/^MemTotal/{printf "%.1f GB", $2/1048576}' /proc/meminfo)"
        printf '%-24s %s\n' 'Operating system' "$(. /etc/os-release 2>/dev/null; echo "$PRETTY_NAME")"
        printf '%-24s %s\n' 'Kernel' "$(uname -r)"
        printf '%-24s %s\n' 'Virtualization' "$(cs_virt)"
        printf '%-24s %s\n' 'Up since' "$(uptime -s 2>/dev/null)"
        echo ""
        echo "NETWORK ADAPTERS"
        echo "----------------"
        printf '%-14s %-9s %-10s %-22s %-14s %-8s %-10s %-6s %s\n' Device Kind Driver Firmware Bus State Speed MTU 'PCIe link (now / max)'
        for i in /sys/class/net/*; do
            i=${i##*/}; [[ $i == lo ]] && continue
            k=$(cs_if_kind "$i"); [[ $k == virtual && $i == veth* ]] && continue
            drv=$(cs_if_driver "$i"); fw=""; bus=""
            if cs_have ethtool; then
                fw=$(ethtool -i "$i" 2>/dev/null | awk -F': ' '/^firmware-version/{print $2}')
                bus=$(ethtool -i "$i" 2>/dev/null | awk -F': ' '/^bus-info/{print $2}')
            fi
            local pci link=""; pci=$(readlink -f /sys/class/net/$i/device 2>/dev/null)
            [[ -e $pci/current_link_speed ]] && link="$(cat $pci/current_link_speed) x$(cat $pci/current_link_width) / $(cat $pci/max_link_speed) x$(cat $pci/max_link_width)"
            sp=$(cs_if_speed "$i")
            printf '%-14s %-9s %-10s %-22s %-14s %-8s %-10s %-6s %s\n' "$i" "$k" "${drv:--}" "${fw:--}" "${bus:-${pci##*/}}" "$(cs_if_state "$i")" "${sp:+${sp}Mb/s}" "$(cs_if_mtu "$i")" "${link:--}"
        done
        echo ""
        echo "STORAGE AND NETWORK CONTROLLERS (PCI)"
        echo "-------------------------------------"
        if cs_have lspci; then
            lspci -nnk 2>/dev/null | awk '/^[0-9a-f]/{dev=$0; show = (dev ~ /SCSI|SATA|SAS|RAID|Fibre|Non-Volatile|NVMe|Ethernet|Network|InfiniBand|Serial Attached/)} show'
        else
            echo "(lspci not installed: install pciutils for controller names)"
        fi
        echo ""
        echo "DISKS"
        echo "-----"
        lsblk -d -o NAME,TRAN,TYPE,SIZE,ROTA,MODEL,VENDOR,SERIAL,HCTL 2>/dev/null
        cs_have nvme && { echo ""; nvme list 2>/dev/null; }
        echo ""
        echo "FULL DETAIL"
        echo "-----------"
        cs_sec 'lscpu' 'lscpu'
        cs_is_root && cs_have dmidecode && cs_sec 'dmidecode (system, board, BIOS, processor, memory, slots)' 'dmidecode -t system -t baseboard -t bios -t processor -t memory -t slot' 30
        cs_have lspci && cs_sec 'PCI devices with drivers' 'lspci -nnk' 20
        cs_have lspci && cs_is_root && cs_sec 'PCIe link capability and status' 'lspci -vv 2>/dev/null | grep -E "^[0-9a-f]|LnkCap:|LnkSta:"' 30
        cs_have lsusb && cs_sec 'USB devices' 'lsusb' 10
        cs_have lshw && cs_sec 'lshw -short' 'lshw -short 2>/dev/null' 60
        cs_sec 'Fibre Channel hosts' 'for h in /sys/class/fc_host/host*; do [ -d "$h" ] || continue; echo "--- $h"; for a in port_name node_name port_state speed supported_speeds symbolic_name; do printf "%-18s %s\n" $a "$(cat $h/$a 2>/dev/null)"; done; done; true'
    } > "$CAP/System-Inventory.txt" 2>&1

    # JSON: the tools' own JSON where they have it, null where they do not
    local lc lb ipj
    lc=$(lscpu -J 2>/dev/null); [[ $lc == \{* ]] || lc=null
    lb=$(lsblk -J -o NAME,TYPE,TRAN,SIZE,ROTA,MODEL,VENDOR,SERIAL,HCTL,MOUNTPOINT 2>/dev/null); [[ $lb == \{* ]] || lb=null
    ipj=$(ip -j addr show 2>/dev/null); [[ $ipj == \[* ]] || ipj=null
    {
        echo "{"
        echo "  \"Host\": $(cs_json "$HOSTTAG"),"
        echo "  \"Dmi\": {\"Vendor\": $(cs_json "$(cs_dmi sys_vendor)"), \"Product\": $(cs_json "$(cs_dmi product_name)"), \"Serial\": $(cs_json "$(cs_dmi product_serial)"), \"BiosVersion\": $(cs_json "$(cs_dmi bios_version)"), \"BiosDate\": $(cs_json "$(cs_dmi bios_date)")},"
        echo "  \"Os\": $(cs_json "$(. /etc/os-release 2>/dev/null; echo "$PRETTY_NAME")"),"
        echo "  \"Kernel\": $(cs_json "$(uname -r)"),"
        echo "  \"Lscpu\": $lc,"
        echo "  \"Lsblk\": $lb,"
        echo "  \"IpAddr\": $ipj"
        echo "}"
    } > "$CAP/System-Inventory.json"
}

# ---------------------------------------------------------------------------
# Topology and findings
# ---------------------------------------------------------------------------
cs_topology() {
    local when=$1 f=$CAP/Topology-$1.txt ff
    ff=$CAP/Raw/findings-$(tr '[:upper:]' '[:lower:]' <<< "$1").txt
    : > "$ff"
    finding() { printf '%s|%s\n' "$1" "$2" >> "$ff"; }
    local tbl s i ip pfx rif gw conn line m u md sp opts v
    tbl=$(cs_ipv4_table)
    {
        echo "Cinesys Storage Diagnostics for Linux $CINESYS_VERSION - topology ($when)"
        echo "Host: $HOSTTAG   Written: $(cs_now)"
        echo ""
        echo "INTERFACES WITH AN IPv4 ADDRESS"
        echo "-------------------------------"
        printf '%-14s %-9s %-10s %-18s %-8s %-10s %-7s %s\n' Device Kind Driver Address State Speed Duplex MTU
        while read -r i ip pfx; do
            [[ $i == lo ]] && continue
            sp=$(cs_if_speed "$i")
            printf '%-14s %-9s %-10s %-18s %-8s %-10s %-7s %s\n' "$i" "$(cs_if_kind "$i")" "$(cs_if_driver "$i")" "$ip/$pfx" "$(cs_if_state "$i")" "${sp:+${sp}Mb/s}" "$(cs_if_duplex "$i")" "$(cs_if_mtu "$i")"
        done <<< "$tbl"

        for s in "${SERVER_IPS[@]}"; do
            echo ""
            echo "SERVER $s ${SERVER_NAME[$s]:+(${SERVER_NAME[$s]}) }- ${TARGET_ROLE[$s]:-}"
            echo "------------------------------------------------------------"
            rif=$(cs_route_if "$s"); gw=$(cs_route_gw "$s")
            sp=$(cs_if_speed "$rif")
            if [[ -n $gw ]]; then line="via gateway $gw"; else line="same subnet (no gateway)"; fi
            echo "Route:            $rif $line, source $(cs_route_src "$s")"
            echo "Link:             $(cs_if_state "$rif") ${sp:+${sp}Mb/s} $(cs_if_duplex "$rif"), MTU $(cs_if_mtu "$rif")"
            local -a used=()
            while read -r ip u ports; do
                [[ -z $ip ]] && continue
                echo "Connection:       from $ip on $u to port(s) $ports"
                cs_in "$u" "${used[@]}" || used+=("$u")
            done < <(cs_conn_ifs "$s")
            (( ${#used[@]} )) || echo "Connection:       none open right now"

            for u in "${used[@]}"; do
                [[ $u == lo ]] && continue
                cs_is_wifi "$u" && finding WARN "Storage traffic to $s (${TARGET_ROLE[$s]:-}) is going over Wi-Fi ($u). Wired performance cannot be judged from this capture."
                [[ -n $rif && $u != "$rif" ]] && finding WARN "The connection to $s uses $u but the route now points to $rif."
                sp=$(cs_if_speed "$u")
                if [[ -n $sp ]]; then
                    (( sp <= 100 )) && finding WARN "$u links at $sp Mb/s. Expect at most 1-12 MB/s."
                    (( sp == 1000 )) && finding INFO "$u links at 1 Gb/s: the ceiling is about 110 MB/s."
                fi
                [[ $(cs_if_duplex "$u") == half ]] && finding WARN "$u is running half duplex."
                # PCIe link narrower or slower than the card supports
                local pci; pci=$(readlink -f /sys/class/net/$u/device 2>/dev/null)
                if [[ -e $pci/current_link_width ]]; then
                    local cw mw cs ms
                    cw=$(cat $pci/current_link_width); mw=$(cat $pci/max_link_width); cs=$(cat $pci/current_link_speed); ms=$(cat $pci/max_link_speed)
                    local slow=0
                    [[ $cw =~ ^[0-9]+$ && $mw =~ ^[0-9]+$ ]] && (( cw < mw )) && slow=1
                    [[ -n $cs && ${cs%% *} != "${ms%% *}" ]] && slow=1
                    if (( slow )); then
                        finding WARN "$u's PCIe link runs at $cs x$cw; the card supports $ms x$mw. Check the slot it is in."
                    fi
                fi
            done
            (( ${#used[@]} > 1 )) && finding INFO "Traffic to $s uses ${#used[@]} adapters at once: ${used[*]}."
            [[ -n $rif ]] && cs_is_wifi "$rif" && (( ${#used[@]} == 0 )) && finding WARN "The route to $s goes over Wi-Fi ($rif)."
            [[ -n $rif ]] && cs_is_tunnel "$rif" && finding WARN "The route to $s goes through a VPN or tunnel ($rif)."
            [[ $s == 127.* ]] && finding WARN "Storage goes through a local port forward or tunnel ($s). Adapter and connection numbers describe the tunnel, not the path to the real server."

            # Several adapters on the target's subnet: Linux answers ARP on any of them
            local sip mi ii; sip=$(cs_ip2int "$s")
            local -a same=()
            while read -r i ip pfx; do
                [[ $i == lo || -z $pfx ]] && continue
                mi=$(( pfx == 0 ? 0 : (0xFFFFFFFF << (32 - pfx)) & 0xFFFFFFFF )); ii=$(cs_ip2int "$ip")
                (( (ii & mi) == (sip & mi) )) && same+=("$i")
            done <<< "$tbl"
            if (( ${#same[@]} > 1 )); then
                finding WARN "${#same[@]} adapters have an address on the same subnet as $s (${same[*]}). Linux can answer ARP and send replies from either one (arp_ignore=$(sysctl -n net.ipv4.conf.all.arp_ignore 2>/dev/null), arp_filter=$(sysctl -n net.ipv4.conf.all.arp_filter 2>/dev/null), rp_filter=$(sysctl -n net.ipv4.conf.all.rp_filter 2>/dev/null)), so traffic may not use the adapter you expect."
            fi
            [[ -n $gw ]] && finding INFO "$s is reached through a router ($gw), not on the local subnet."
        done

        # Path MTU: don't-fragment pings at 1500 and at the adapter's MTU, and
        # the largest size that passes when the large one fails.
        if (( ${#SERVER_IPS[@]} )); then
            echo ""
            echo "PATH MTU (don't-fragment pings)"
            echo "-------------------------------"
            local pm res big mtu n=0
            for s in "${SERVER_IPS[@]}"; do
                [[ $s == 127.* ]] && continue
                (( ++n > 12 )) && { echo "(only the first 12 targets tested)"; break; }
                rif=$(cs_route_if "$s"); mtu=$(cs_if_mtu "$rif"); mtu=${mtu:-1500}
                read -r res big pm line <<< "$(cs_pmtu "$s" "$mtu")"
                printf '%-15s %-34s via %s, MTU %s: 1500 %s, at MTU %s, largest that passes %s -> %s\n' "$s" "${TARGET_ROLE[$s]:-}" "$rif" "$mtu" "$pm" "$line" "$big" "$res"
                case $res in
                    SilentDrop) finding WARN "$rif has MTU $mtu, but larger packets to $s (${TARGET_ROLE[$s]:-}) get no answer while $big-byte packets do. A switch port or VLAN on the path, or $s's own interface, is set to a smaller MTU." ;;
                    RouterRefused) finding WARN "$rif has MTU $mtu, but a router on the path to $s (${TARGET_ROLE[$s]:-}) refuses packets above $big bytes ('fragmentation needed'). A routed hop or firewall uses a smaller MTU." ;;
                    NoReply) finding INFO "No reply to pings from $s (${TARGET_ROLE[$s]:-}); ICMP may be blocked, so the path MTU could not be tested." ;;
                esac
            done
        fi

        echo ""
        echo "SMB MOUNTS"
        echo "----------"
        for m in "${MOUNTS[@]}"; do
            opts=$(awk -v m="$m" '{mp = $2; gsub(/\\040/, " ", mp)} mp == m {print $4; exit}' /proc/mounts)
            echo "${MOUNT_INST[$m]} on $m"
            echo "    $opts"
            v=$(cs_mount_opt "$opts" vers)
            [[ -n $v && $v != 3* ]] && finding WARN "${MOUNT_INST[$m]} uses SMB $v (not SMB 3)."
            [[ $(cs_mount_opt "$opts" cache) == none ]] && finding INFO "${MOUNT_INST[$m]} is mounted with cache=none: every read and write goes to the server."
            [[ -n $(cs_mount_opt "$opts" seal) ]] && finding INFO "${MOUNT_INST[$m]} is encrypted (seal)."
            [[ -n $(cs_mount_opt "$opts" sign) ]] && finding INFO "${MOUNT_INST[$m]} is signed (sign). Signing costs CPU on both ends."
            v=$(cs_mount_opt "$opts" rsize); [[ -n $v ]] && (( v < 1048576 )) && finding INFO "${MOUNT_INST[$m]} reads in $(( v / 1024 )) KB requests (rsize=$v)."
            v=$(cs_mount_opt "$opts" wsize); [[ -n $v ]] && (( v < 1048576 )) && finding INFO "${MOUNT_INST[$m]} writes in $(( v / 1024 )) KB requests (wsize=$v)."
            [[ -n $(cs_mount_opt "$opts" soft) ]] && finding INFO "${MOUNT_INST[$m]} is a soft mount: I/O fails with an error when the server is slow to answer."
            if [[ -r /proc/fs/cifs/Stats ]] && grep -F -i -- "${MOUNT_INST[$m]}" /proc/fs/cifs/Stats | grep -q DISCONNECTED; then
                finding WARN "${MOUNT_INST[$m]} is disconnected right now."
            fi
        done
        (( ${#MOUNTS[@]} )) || echo "(no SMB mounts)"

        echo ""
        echo "NFS MOUNTS"
        echo "----------"
        for m in "${NFS_MOUNTS[@]}"; do
            opts=$(awk -v m="$m" '{mp = $2; gsub(/\\040/, " ", mp)} mp == m {print $4; exit}' /proc/mounts)
            echo "${NFS_INST[$m]} on $m"
            echo "    $opts"
            [[ $(cs_mount_opt "$opts" proto) == udp* ]] && finding WARN "${NFS_INST[$m]} is mounted over UDP. Use TCP."
            [[ $(cs_mount_opt "$opts" vers) == 3* ]] && finding INFO "${NFS_INST[$m]} uses NFS v3."
            v=$(cs_mount_opt "$opts" rsize); [[ -n $v ]] && (( v < 1048576 )) && finding INFO "${NFS_INST[$m]} reads in $(( v / 1024 )) KB requests (rsize=$v)."
            v=$(cs_mount_opt "$opts" wsize); [[ -n $v ]] && (( v < 1048576 )) && finding INFO "${NFS_INST[$m]} writes in $(( v / 1024 )) KB requests (wsize=$v)."
            [[ -n $(cs_mount_opt "$opts" sync) ]] && finding WARN "${NFS_INST[$m]} is mounted sync: every write waits for the server."
            [[ -n $(cs_mount_opt "$opts" soft) ]] && finding INFO "${NFS_INST[$m]} is a soft mount: I/O fails with an error when the server is slow to answer."
            { [[ -n $(cs_mount_opt "$opts" noac) ]] || [[ $(cs_mount_opt "$opts" actimeo) == 0 ]]; } && finding INFO "${NFS_INST[$m]} has attribute caching off (noac/actimeo=0): many extra metadata calls."
            v=$(cs_mount_opt "$opts" nconnect); [[ -n $v ]] && finding INFO "${NFS_INST[$m]} uses $v TCP connections (nconnect)."
            # RPCs retransmitted since the mount (per-op "trans" minus "ops")
            v=$(awk -v m="$m" '$1 == "device" {mp = $5; gsub(/\\040/, " ", mp); on = (mp == m)} on && $1 ~ /^[A-Z_]+:$/ && $2 ~ /^[0-9]+$/ && NF >= 4 {r += $3 - $2; t += $4} END {print r + 0, t + 0}' /proc/self/mountstats)
            [[ ${v%% *} != 0 ]] && finding WARN "${NFS_INST[$m]} has retransmitted ${v%% *} RPC(s) since it was mounted (${v##* } timeouts)."
        done
        (( ${#NFS_MOUNTS[@]} )) || echo "(no NFS mounts)"

        # Storage found by the detectors
        echo ""
        echo "STORAGE FOUND"
        echo "-------------"
        local sf=$CAP/Raw/storage-$(tr '[:upper:]' '[:lower:]' <<< "$when").txt
        [[ -s $sf ]] || sf=$CAP/Raw/storage-pre.txt
        local -a r det=()
        [[ -s $sf ]] && mapfile -t det < "$sf"
        for line in "${det[@]}"; do
            IFS='|' read -r -a r <<< "$line"
            printf '%-9s %-10s %-16s %-6s %-28s %s\n' "${r[0]}" "${r[4]}" "${r[1]}" "${r[2]}" "${r[3]}" "${r[5]}"
        done
        (( ${#det[@]} )) || echo "(no network or SAN storage found: whole-machine capture)"
        local dj; dj=$(printf '%s\n' "${det[@]}")
        if grep -q '^STORNEXT|' <<< "$dj"; then
            if grep -q '^STORNEXT|.*|gateway|' <<< "$dj" && ! grep -q '^STORNEXT|.*|flow|DLC' <<< "$dj"; then
                finding WARN "StorNext DLC gateways are listed by cvadmin but no connection to any of them is open."
            fi
            grep -q '^STORNEXT|.*|mdc|' <<< "$dj" || finding INFO "A StorNext client is installed but no metadata controller was found (cvadmin needs sudo; see Storage-$when.txt)."
        fi
        while IFS='|' read -r -a r; do
            [[ ${r[0]} == ISCSI && ${r[4]} == portal && ${r[5]} == *,* && ${r[5]} != *LOGGED_IN* ]] && finding WARN "iSCSI session to ${r[1]} (${r[5]%%,*}) is not logged in: ${r[5]##*, }."
            [[ ${r[0]} == NVMEOF && ${r[5]} == *,*,* && ${r[5]##*, } != live ]] && finding WARN "NVMe-oF controller to ${r[1]} is ${r[5]##*, }."
            [[ ${r[0]} == FC && ${r[4]} == hba && ${r[5]} != Online* ]] && finding WARN "Fibre Channel ${r[3]} is ${r[5]%%,*}."
            [[ ${r[0]} == MPATH && ${r[5]} != *", 0 not running" ]] && finding WARN "Multipath device ${r[5]%%,*} has paths that are not running (${r[5]#*, })."
            [[ ${r[0]} == RDMA && ${r[5]} != ACTIVE* ]] && finding INFO "RDMA port ${r[3]} is ${r[5]%%,*}."
        done <<< "$dj"

        # Machine-wide findings
        local virt; virt=$(systemd-detect-virt 2>/dev/null)
        [[ -n $virt && $virt != none ]] && finding INFO "This is a virtual machine ($virt): adapter speeds are what the hypervisor reports, and CPU steal time shows host contention."
        [[ $(timedatectl show -p NTPSynchronized --value 2>/dev/null) == no ]] && finding WARN "The clock is not synchronized (NTP). Captures from this machine and the server will not line up."
        local gov; gov=$(cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor 2>/dev/null)
        [[ $gov == powersave && $(cat /sys/devices/system/cpu/intel_pstate/status 2>/dev/null) != active ]] && finding INFO "The CPU frequency governor is powersave."
        for v in /sys/class/power_supply/*; do
            [[ $(cat $v/type 2>/dev/null) == Mains && $(cat $v/online 2>/dev/null) == 0 ]] && finding WARN "The machine is running on battery."
        done
        local dn; dn=$(ps -eo stat= 2>/dev/null | grep -c '^D')
        (( dn > 0 )) && finding INFO "$dn process(es) are waiting on I/O (state D) right now (Snapshot, PROCESSES WAITING ON I/O)."
        local fu; fu=$(systemctl --failed --no-legend --plain 2>/dev/null | awk '{print $1}' | paste -sd' ' -)
        [[ -n $fu ]] && finding INFO "Failed services: $fu."
        if cs_have systemctl && ls /sys/class/iscsi_session/session* >/dev/null 2>&1 && [[ $(systemctl is-active multipathd 2>/dev/null) != active ]]; then
            local ns; ns=$(ls -d /sys/class/iscsi_session/session* | wc -l)
            (( ns > 1 )) && finding INFO "$ns iSCSI sessions but multipathd is not running: each path is a separate disk."
        fi
        if [[ $when != Post && -s $CAP/Raw/kernel-log-pre.txt ]]; then
            local kc; kc=$(grep -E "$CS_KLOG_RE" "$CAP/Raw/kernel-log-pre.txt" | grep -ciE 'error|fail|timed out|timeout|not responding|reset|link is down|blocked for more than|abort')
            (( kc > 0 )) && finding WARN "The kernel logged $kc storage or network error line(s) in the last hour (Raw/kernel-log-pre.txt)."
        fi
        # Adapter loss during the capture (Pre vs Post). Real loss is missed,
        # FIFO and overrun errors (the adapter had no room for the packet) and
        # receive errors. rx_dropped also counts packets for protocols nothing
        # on the machine uses (LLDP, unknown multicast), so it is only INFO.
        for i in "${WATCH_IFS[@]}"; do
            local st=/sys/class/net/$i/statistics a rd re lost
            a() { local v; v=$(cat "$st/$1" 2>/dev/null); echo "${v:-0}"; }
            rd=$(a rx_dropped); re=$(a rx_errors); lost=$(( $(a rx_missed_errors) + $(a rx_fifo_errors) + $(a rx_over_errors) ))
            echo "$i $rd $re $lost" >> "$CAP/Raw/ifstats-$(tr '[:upper:]' '[:lower:]' <<< "$when").txt"
            if [[ $when == Post && -f $CAP/Raw/ifstats-pre.txt ]]; then
                local -a p0; read -r -a p0 <<< "$(awk -v i="$i" '$1 == i {print $2, $3, $4; exit}' "$CAP/Raw/ifstats-pre.txt")"
                if (( ${#p0[@]} == 3 )); then
                    (( lost > p0[2] )) && finding WARN "$i lost $(( lost - p0[2] )) received packet(s) during the capture (missed / FIFO / overrun: the adapter or driver ran out of buffers)."
                    (( re > p0[1] )) && finding WARN "$i had $(( re - p0[1] )) receive error(s) during the capture (bad frames: cable, optic or switch port)."
                    (( rd > p0[0] )) && finding INFO "$i discarded $(( rd - p0[0] )) received packet(s) during the capture (rx_dropped: usually packets for protocols this machine does not use, not loss)."
                fi
            fi
        done
        (( ${#SERVER_IPS[@]} )) || finding INFO "No network storage was found or named; this is a whole-machine capture. Use --target to watch a server."

        # Avid NEXIS: its data is UDP, so UDP drops and IP fragments matter
        if grep -q '^NEXIS|' <<< "$dj"; then
            local nxm; nxm=$(grep '^NEXIS|.*|mount|' <<< "$dj" | cut -d'|' -f4 | paste -sd' ' -)
            finding INFO "The Avid NEXIS client is installed${nxm:+ (workspaces: $nxm)}. Its data is UDP: the summary shows it under OTHER NETWORK TRAFFIC. Name the NEXIS engines with --target to test the path to them."
        fi
        local us; us=$(awk '$1 == "Udp:" { if (h) { for (i = 2; i <= NF; i++) if (n[i] == "RcvbufErrors") r = $i; print r + 0; exit } for (i = 2; i <= NF; i++) n[i] = $i; h = 1 }' /proc/net/snmp)
        local rf; rf=$(awk '$1 == "Ip:" { if (h) { for (i = 2; i <= NF; i++) if (n[i] == "ReasmFails") r = $i; print r + 0; exit } for (i = 2; i <= NF; i++) n[i] = $i; h = 1 }' /proc/net/snmp)
        echo "${us:-0} ${rf:-0}" > "$CAP/Raw/udpstats-$(tr '[:upper:]' '[:lower:]' <<< "$when").txt"
        if [[ $when == Post && -f $CAP/Raw/udpstats-pre.txt ]]; then
            local u0 r0; read -r u0 r0 < "$CAP/Raw/udpstats-pre.txt"
            (( ${us:-0} > u0 )) && finding WARN "$(( us - u0 )) UDP datagram(s) were dropped during the capture because a socket receive buffer was full (UDP storage traffic such as Avid NEXIS loses data and has to retry)."
            (( ${rf:-0} > r0 )) && finding WARN "$(( rf - r0 )) fragmented IP datagram(s) could not be reassembled during the capture (large UDP datagrams are being split and lost; check the MTU end to end)."
        fi

        echo ""
        echo "FINDINGS"
        echo "--------"
        if [[ -s $ff ]]; then awk -F'|' '{printf "%-5s %s\n", $1, $2}' "$ff"; else echo "(none)"; fi
    } > "$f" 2>&1
}
