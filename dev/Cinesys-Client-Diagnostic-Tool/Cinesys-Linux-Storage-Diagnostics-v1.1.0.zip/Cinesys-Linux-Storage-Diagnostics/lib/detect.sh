# Finds the network and SAN storage this machine uses. Sourced after common.sh.
#
#   cs_detect <report file>   fills CS_DET and writes the report (Storage-*.txt)
#
# Read-only: /proc/mounts, /sys (iSCSI sessions, NVMe controllers, FC hosts,
# RDMA ports, block devices), ss, lsblk, and listing commands (iscsiadm -m
# session, nvme list-subsys, multipath -ll) plus a fixed list of cvadmin
# queries. Nothing is mounted, logged in or out, rescanned or changed.
#
# CS_DET records, one per line: "protocol|ip|port|where|role|detail"
#   protocol  SMB NFS STORNEXT NEXIS ISCSI NVMEOF FC RDMA MPATH DISK
#   role      share mount mdc gateway portal target hba port disk flow fs

CS_DET=()

declare -A CS_PORT_PROTO=( [445]=SMB [2049]=NFS [3260]=ISCSI [4420]=NVMEOF [8009]=NVMEOF )

# The only cvadmin commands this toolkit ever runs. All of them only display.
CS_CVADMIN_OK=(select stat proxy 'proxy long' paths)
CS_CVADMIN=/usr/cvfs/bin/cvadmin

cs_det_add() {
    # protocol ip port where role detail
    local d=${6:--}; d=${d//|//}; d=${d//$'\n'/ }
    CS_DET+=("$1|${2:--}|${3:--}|${4:--}|$5|$d")
}

cs_is_private() {
    [[ $1 == 10.* || $1 == 192.168.* || $1 == 169.254.* ]] && return 0
    if [[ $1 == 172.* ]]; then local o=${1#172.}; o=${o%%.*}; (( o >= 16 && o <= 31 )) && return 0; fi
    return 1
}

# cs_cvadmin <file system | -> <query>
# Refuses anything not on CS_CVADMIN_OK; stdin closed; 20-second limit.
cs_cvadmin() {
    local fs=$1 q=$2 ok=0 x
    for x in "${CS_CVADMIN_OK[@]}"; do [[ $x == "$q" ]] && ok=1; done
    (( ok )) || { echo "(not run: '$q' is not on the read-only list)"; return 1; }
    [[ -x $CS_CVADMIN ]] || { echo "(cvadmin not found)"; return 1; }
    if [[ $fs == - ]]; then
        cs_timeout 20 "$CS_CVADMIN" -e "$q" </dev/null 2>&1
    else
        [[ $fs =~ ^[A-Za-z0-9_.-]+$ ]] || { echo "(not run: unexpected file system name '$fs')"; return 1; }
        cs_timeout 20 "$CS_CVADMIN" -e "select $fs" -e "$q" </dev/null 2>&1
    fi
}

# "ip port" lines for host:port pairs and bare IPv4 addresses in some text
cs_hostports() {
    local hp h p ip
    while read -r hp; do
        [[ -z $hp ]] && continue
        h=${hp%:*}; p=${hp##*:}
        [[ $h =~ ^[0-9]+$ ]] && continue
        ip=$(cs_resolve "$h")
        cs_is_ipv4 "$ip" && [[ $ip != 127.* ]] && echo "$ip $p"
    done < <(grep -oE '[A-Za-z0-9][A-Za-z0-9.-]*:[0-9]{2,5}' <<< "$1" | sort -u)
    while read -r ip; do
        [[ -z $ip ]] && continue
        cs_is_ipv4 "$ip" && [[ $ip != 127.* && $ip != 0.* ]] && echo "$ip -"
    done < <(grep -oE '\b([0-9]{1,3}\.){3}[0-9]{1,3}\b' <<< "$1" | sort -u)
}

cs_rsec() {
    printf '\n===== %s =====\n$ %s\n' "$1" "$2"
    cs_timeout "${3:-30}" bash -c "$2" 2>&1
}

cs_detect() {
    local rpt=$1
    CS_DET=()
    local est line ip port mp srv share fst opts l lp rip rp pp f h d s v
    est=$(cs_tcp_est)

    # --- SMB (cifs) --------------------------------------------------------
    while IFS='|' read -r mp srv share fst opts; do
        [[ -z $mp ]] && continue
        ip=$(cs_resolve "$srv"); port=$(cs_mount_opt "$opts" port); port=${port:-445}
        cs_det_add SMB "$ip" "$port" "$mp" share "//$srv/$share vers=$(cs_mount_opt "$opts" vers)"
    done < <(cs_smb_mounts)

    # --- NFS -----------------------------------------------------------------
    while IFS='|' read -r mp srv share fst opts; do
        [[ -z $mp ]] && continue
        ip=$(cs_mount_opt "$opts" addr); cs_is_ipv4 "$ip" || ip=$(cs_resolve "$srv")
        port=$(cs_mount_opt "$opts" port); [[ -z $port || $port == 0 ]] && port=2049
        cs_det_add NFS "$ip" "$port" "$mp" mount "$srv:$share $fst vers=$(cs_mount_opt "$opts" vers) proto=$(cs_mount_opt "$opts" proto)"
    done < <(cs_nfs_mounts)

    # --- StorNext ------------------------------------------------------------
    local -a sn_mounts=() sn_fs=() mdc=() gw=()
    local sn_text="" cvsel="" havesn=0
    while read -r f mp fst rest; do
        [[ $fst == cvfs ]] || continue
        mp=${mp//\\040/ }; sn_mounts+=("$mp")
        [[ $f =~ ^[A-Za-z0-9_.-]+$ ]] && sn_fs+=("$f")
        cs_det_add STORNEXT - - "$mp" fs "mounted from $f"
    done < /proc/mounts
    (( ${#sn_mounts[@]} )) || [[ -d /usr/cvfs ]] && havesn=1
    if (( havesn )); then
        if [[ -f /usr/cvfs/config/fsnameservers ]]; then
            while read -r h; do
                ip=$(cs_resolve "$h")
                cs_is_ipv4 "$ip" && { mdc+=("$ip"); cs_det_add STORNEXT "$ip" - /usr/cvfs/config/fsnameservers mdc "name server $h"; }
            done < <(grep -v '^[[:space:]]*#' /usr/cvfs/config/fsnameservers | awk 'NF{print $1}')
        fi
        if [[ -x $CS_CVADMIN ]]; then
            cvsel=$(cs_cvadmin - select)
            while read -r line; do
                local fsn=${line#*>}; fsn=${fsn#\*}; fsn=${fsn#"${fsn%%[! ]*}"}; fsn=${fsn%%\[*}
                [[ $fsn =~ ^[A-Za-z0-9_.-]+$ ]] && sn_fs+=("$fsn")
                local hp=${line##*located on }; hp=${hp%% *}
                if [[ $hp =~ :[0-9]+$ ]]; then
                    ip=$(cs_resolve "${hp%:*}")
                    cs_is_ipv4 "$ip" && { mdc+=("$ip"); cs_det_add STORNEXT "$ip" "${hp##*:}" "$fsn" mdc "file system service"; }
                fi
            done < <(grep -E '^[[:space:]]*[0-9]+>' <<< "$cvsel")
            local -A seenfs=()
            for f in "${sn_fs[@]}"; do
                [[ -n ${seenfs[$f]:-} ]] && continue; seenfs[$f]=1
                for v in stat proxy 'proxy long'; do
                    sn_text+=$'\n'"===== cvadmin: select $f; $v ====="$'\n'"$(cs_cvadmin "$f" "$v")"$'\n'
                done
            done
            sn_text+=$'\n'"===== cvadmin: paths ====="$'\n'"$(cs_cvadmin - paths)"$'\n'
            local pr
            pr=$(awk '/^===== cvadmin: select .*; proxy/{on=1; next} /^===== /{on=0} on' <<< "$sn_text")
            while read -r ip port; do
                [[ -z $ip ]] && continue
                [[ " ${mdc[*]} " == *" $ip "* ]] && continue
                gw+=("$ip"); cs_det_add STORNEXT "$ip" "$port" - gateway "named in cvadmin proxy output"
            done < <(cs_hostports "$pr")
        fi
        while read -r l lp rip rp; do
            if [[ " ${gw[*]} " == *" $rip "* ]]; then cs_det_add STORNEXT "$rip" "$rp" "$l" flow "DLC gateway connection"
            elif [[ " ${mdc[*]} " == *" $rip "* ]]; then cs_det_add STORNEXT "$rip" "$rp" "$l" flow "metadata controller connection"
            fi
        done <<< "$est"
    fi

    # --- Avid NEXIS client -------------------------------------------------------
    # Its file data travels over UDP through Avid's own client, so no SMB/NFS
    # counter sees it. Found by name: mounts, kernel modules, processes,
    # packages and install folders; hosts from the client's TCP/UDP sockets.
    local nx_sw nx_peers=""
    while read -r f mp fst rest; do
        [[ ${fst,,} =~ avid|nexis|fos ]] || continue
        mp=${mp//\\040/ }; cs_det_add NEXIS - - "$mp" mount "workspace $f ($fst)"
    done < /proc/mounts
    nx_sw=$( { awk '{print "module " $1}' /proc/modules 2>/dev/null
               ps -eo comm= 2>/dev/null | sed 's/^/process /'
               dpkg-query -W -f='package ${Package} ${Version}\n' 2>/dev/null
               rpm -qa 2>/dev/null | sed 's/^/package /'
               ls -1d /opt/[Aa]vid* /usr/local/[Aa]vid* /etc/[Aa]vid* 2>/dev/null | sed 's/^/folder /'
             } | grep -iE 'avid|nexis' | sort -u )
    while read -r line; do [[ -n $line ]] && cs_det_add NEXIS - - - client "$line"; done <<< "$nx_sw"
    if [[ -n $nx_sw ]]; then
        # sockets owned by Avid processes (process names need sudo)
        nx_peers=$(ss -Htunp 2>/dev/null | grep -iE 'avid|nexis|fos' | awk '{print $1, $6}')
        while read -r proto peer; do
            [[ -z $peer ]] && continue
            ip=${peer%:*}; port=${peer##*:}
            cs_is_ipv4 "$ip" && [[ $ip != 127.* && $ip != 0.0.0.0 ]] && cs_det_add NEXIS "$ip" "$port" - flow "$proto socket of the NEXIS client"
        done <<< "$nx_peers"
    fi

    # --- iSCSI sessions (open-iscsi, from /sys) --------------------------------
    local sess conn tgt state disks
    for sess in /sys/class/iscsi_session/session*; do
        [[ -d $sess ]] || continue
        s=${sess##*/}; tgt=$(cat "$sess/targetname" 2>/dev/null); state=$(cat "$sess/state" 2>/dev/null)
        disks=$(ls -d "$sess"/device/target*/*/block/* 2>/dev/null | awk -F/ '{print $NF}' | paste -sd, -)
        ip=""; port=""
        for conn in /sys/class/iscsi_connection/connection${s#session}:*; do
            [[ -d $conn ]] || continue
            ip=$(cat "$conn/persistent_address" 2>/dev/null); port=$(cat "$conn/persistent_port" 2>/dev/null)
        done
        cs_det_add ISCSI "$ip" "${port:-3260}" "${disks:-$s}" portal "$tgt, $state"
    done
    [[ -r /etc/iscsi/initiatorname.iscsi ]] && cs_det_add ISCSI - - - initiator "$(grep -v '^#' /etc/iscsi/initiatorname.iscsi | head -1)"

    # --- NVMe over Fabrics (and local NVMe for the disk list) -------------------
    local c tr addr nqn ns
    for c in /sys/class/nvme/nvme*; do
        [[ -d $c ]] || continue
        tr=$(cat "$c/transport" 2>/dev/null)
        [[ $tr == pcie ]] && continue
        addr=$(cat "$c/address" 2>/dev/null); nqn=$(cat "$c/subsysnqn" 2>/dev/null); state=$(cat "$c/state" 2>/dev/null)
        ip=$(sed -n 's/.*traddr=\([^,]*\).*/\1/p' <<< "$addr"); port=$(sed -n 's/.*trsvcid=\([^,]*\).*/\1/p' <<< "$addr")
        ns=$(ls -d "$c"/nvme*n* 2>/dev/null | awk -F/ '{print $NF}' | paste -sd, -)
        cs_is_ipv4 "$ip" || ip=""
        cs_det_add NVMEOF "$ip" "$port" "${ns:-${c##*/}}" target "$tr, $nqn, $state"
    done

    # --- Fibre Channel HBAs -------------------------------------------------------
    local hst model
    for hst in /sys/class/fc_host/host*; do
        [[ -d $hst ]] || continue
        model=$(cat "/sys/class/scsi_host/${hst##*/}/model_name" 2>/dev/null)
        cs_det_add FC - - "${hst##*/}" hba "$(cat $hst/port_state 2>/dev/null), $(cat $hst/speed 2>/dev/null) (supports $(cat $hst/supported_speeds 2>/dev/null)), WWPN $(cat $hst/port_name 2>/dev/null)${model:+, $model}"
    done

    # --- RDMA ports (RoCE / InfiniBand: NVMe over RDMA, iSER) ----------------------
    local p
    for p in /sys/class/infiniband/*/ports/*; do
        [[ -d $p ]] || continue
        d=${p#/sys/class/infiniband/}; d=${d%%/*}
        cs_det_add RDMA - - "$d/${p##*/}" port "$(cat $p/state 2>/dev/null | awk '{print $2}'), $(cat $p/rate 2>/dev/null), $(cat $p/link_layer 2>/dev/null)"
    done

    # --- Multipath devices ------------------------------------------------------
    local dm name nslave nfail sl
    for dm in /sys/block/dm-*; do
        [[ -d $dm ]] || continue
        [[ $(cat "$dm/dm/uuid" 2>/dev/null) == mpath-* ]] || continue
        name=$(cat "$dm/dm/name" 2>/dev/null); nslave=0; nfail=0
        for sl in "$dm"/slaves/*; do
            [[ -e $sl ]] || continue
            nslave=$(( nslave + 1 ))
            [[ $(cat "/sys/block/${sl##*/}/device/state" 2>/dev/null) == running ]] || nfail=$(( nfail + 1 ))
        done
        cs_det_add MPATH - - "${dm##*/}" disk "$name, $nslave path(s), $nfail not running"
    done

    # --- Connections on well-known storage ports --------------------------------
    while read -r l lp rip rp; do
        [[ -z $rip ]] && continue
        pp=${CS_PORT_PROTO[$rp]:-}
        [[ -z $pp ]] && continue
        case $pp in
            ISCSI) printf '%s\n' "${CS_DET[@]}" | grep -q "^ISCSI|$rip|" || cs_det_add ISCSI "$rip" "$rp" "$l" portal "TCP connection" ;;
            NVMEOF) printf '%s\n' "${CS_DET[@]}" | grep -q "^NVMEOF|$rip|" || cs_det_add NVMEOF "$rip" "$rp" "$l" target "TCP connection" ;;
            *) cs_det_add "$pp" "$rip" "$rp" "$l" flow connection ;;
        esac
    done <<< "$est"

    # --- Block devices: how each disk is attached --------------------------------
    while IFS='|' read -r name tran type size model; do
        [[ -z $name || $type != disk ]] && continue
        case $name in loop*|ram*|zram*|sr*|fd*) continue ;; esac
        local pr=DISK
        case $tran in fc) pr=FC ;; iscsi) pr=ISCSI ;; esac
        [[ $name == nvme* && -n $(printf '%s\n' "${CS_DET[@]}" | grep "^NVMEOF|.*|[^|]*$name") ]] && pr=NVMEOF
        cs_det_add "$pr" - - "$name" disk "${tran:-?}, $size, ${model:-?}"
    done < <(cs_lsblk_pairs NAME,TRAN,TYPE,SIZE,MODEL)

    # --- Report ------------------------------------------------------------------
    {
        echo "Cinesys Storage Diagnostics for Linux $CINESYS_VERSION - storage on this machine"
        echo "Host: ${HOSTTAG:-$(hostname -s)}   Written: $(cs_now)"
        echo "Only read-only commands are used (cvadmin: ${CS_CVADMIN_OK[*]})."
        echo ""
        echo "FOUND"
        echo "-----"
        printf '%-9s %-10s %-16s %-6s %-28s %s\n' Protocol Role Address Port Where Detail
        local -a r
        for line in "${CS_DET[@]}"; do
            IFS='|' read -r -a r <<< "$line"
            printf '%-9s %-10s %-16s %-6s %-28s %s\n' "${r[0]}" "${r[4]}" "${r[1]}" "${r[2]}" "${r[3]}" "${r[5]}"
        done
        (( ${#CS_DET[@]} )) || echo "(no network or SAN storage found)"
        if (( havesn )); then
            echo ""
            echo "STORNEXT CLIENT MODE"
            echo "--------------------"
            if (( ${#gw[@]} )) && printf '%s\n' "${CS_DET[@]}" | grep -q '^STORNEXT|.*|flow|DLC'; then
                echo "LAN client (DLC): data goes through gateway(s) ${gw[*]}"
            elif (( ${#gw[@]} )); then
                echo "Gateways are listed by cvadmin (${gw[*]}) but no connection to them is open right now"
            elif printf '%s\n' "${CS_DET[@]}" | grep -qE '^(FC|ISCSI|MPATH)\|'; then
                echo "SAN client (no DLC gateway found; FC, iSCSI or multipath disks are present)"
            else
                echo "Not determined (no gateway in cvadmin output and no SAN disks found)"
            fi
        fi
        echo ""
        echo "OTHER CONNECTIONS TO PRIVATE ADDRESSES (configurable storage ports show up here)"
        echo "--------------------------------------------------------------------------------"
        while read -r l lp rip rp; do
            [[ -n $rip ]] && cs_is_private "$rip" && echo "$rip:$rp"
        done <<< "$est" | sort | uniq -c | sort -rn | head -40

        cs_rsec 'MOUNTS (network and cluster file systems)' "awk '\$3 !~ /^(proc|sysfs|devtmpfs|devpts|tmpfs|securityfs|cgroup2?|pstore|bpf|debugfs|tracefs|mqueue|hugetlbfs|configfs|fusectl|binfmt_misc|autofs|efivarfs|squashfs|overlay|nsfs|rpc_pipefs|ramfs)\$/' /proc/mounts"
        [[ -r /proc/fs/cifs/DebugData ]] && cs_rsec 'SMB CLIENT SESSIONS (/proc/fs/cifs/DebugData)' 'cat /proc/fs/cifs/DebugData'
        cs_have nfsstat && grep -qE ' nfs4? ' /proc/mounts && cs_rsec 'NFS MOUNT OPTIONS' 'nfsstat -m'
        if (( havesn )); then
            printf '\n===== cvadmin: select =====\n%s\n%s\n' "${cvsel:-(cvadmin not found)}" "$sn_text"
            cs_rsec 'STORNEXT CONFIGURATION FILES (names only, except name servers)' \
                'ls -la /usr/cvfs/config 2>/dev/null; [ -f /usr/cvfs/config/fsnameservers ] && { echo "--- fsnameservers"; cat /usr/cvfs/config/fsnameservers; }'
            cs_rsec 'STORNEXT CLIENT LOGS (newest 150 lines each)' \
                'for f in /usr/cvfs/debug/*.out; do [ -f "$f" ] || continue; echo "--- $f"; tail -150 "$f"; done'
        fi
        if [[ -n $nx_sw ]]; then
            printf '\n===== AVID NEXIS CLIENT (found by name) =====\n%s\n' "$nx_sw"
            cs_rsec 'AVID NEXIS CLIENT SOCKETS' "ss -tunp 2>/dev/null | grep -iE 'avid|nexis|fos'"
        fi
        cs_have iscsiadm && cs_rsec 'iSCSI SESSIONS (iscsiadm -m session -P 3)' 'iscsiadm -m session -P 3'
        cs_have nvme && cs_rsec 'NVMe SUBSYSTEMS' 'nvme list-subsys'
        cs_rsec 'FIBRE CHANNEL HOSTS' 'for h in /sys/class/fc_host/host*; do [ -d "$h" ] || continue; echo "--- $h"; for a in port_name node_name port_state port_type speed supported_speeds fabric_name symbolic_name; do printf "%-18s %s\n" $a "$(cat $h/$a 2>/dev/null)"; done; done'
        cs_rsec 'RDMA PORTS' 'for p in /sys/class/infiniband/*/ports/*; do [ -d "$p" ] || continue; echo "$p: $(cat $p/state 2>/dev/null) $(cat $p/phys_state 2>/dev/null) $(cat $p/rate 2>/dev/null) $(cat $p/link_layer 2>/dev/null)"; done'
        cs_is_root && cs_have multipath && cs_rsec 'MULTIPATH' 'multipath -ll'
        cs_rsec 'BLOCK DEVICES' 'lsblk -o NAME,KNAME,TYPE,TRAN,SIZE,ROTA,MODEL,VENDOR,SERIAL,HCTL,MOUNTPOINT,FSTYPE'
    } > "$rpt" 2>&1
}
