#!/bin/bash
# Starts a Cinesys storage capture on a Linux client (Debian / Ubuntu).
#
#     sudo bash Start-CinesysCapture.sh                       all storage found
#     sudo bash Start-CinesysCapture.sh --target 10.1.2.3     one server, gateway or portal
#     sudo bash Start-CinesysCapture.sh --target 10.1.2.3 --duration 30 --packet-capture headers
#
# With no storage found it still runs: a whole-machine capture (adapters,
# disks, CPU, memory, path to the default gateway).

CINESYS_ROOT=$(cd "$(dirname "$0")" && pwd)
source "$CINESYS_ROOT/lib/common.sh"

usage() {
    cat <<EOF
Cinesys Storage Diagnostics for Linux $CINESYS_VERSION

Usage: sudo bash Start-CinesysCapture.sh [options]

  --target NAME|IP       Server to watch: SMB or NFS server, StorNext MDC or DLC
                         gateway, iSCSI portal, NVMe/TCP target (repeat or
                         comma-separate). Default: everything found.
  --server NAME|IP       Same as --target.
  --output FOLDER        Where capture folders go. Default: $CINESYS_DEFAULT_OUTPUT
  --duration MINUTES     Stop automatically after this many minutes.
  --max-hours HOURS      Safety stop if nobody runs Stop. Default: 12
  --interval SECONDS     Sample interval. Default: 1
  --label TEXT           A note stored with the capture and added to the folder name.
  --packet-capture MODE  none (default) or headers: first bytes of each packet to
                         and from the targets (needs tcpdump installed).
  --packet-size BYTES    Bytes kept per packet with headers. Default: 128
  --packet-file-mb MB    Size of each packet file. Default: 512
  --packet-files N       Packet files kept per adapter (oldest overwritten). Default: 4
  --allow-nonroot        Engineer test mode without sudo: packet capture,
                         firewall rules and some details are skipped.
  -h, --help             This text.
EOF
}

# ---------------------------------------------------------------------------
# Options
# ---------------------------------------------------------------------------
ARG_SERVERS=()
OUTPUT=$CINESYS_DEFAULT_OUTPUT
DURATION=0
MAX_HOURS=12
INTERVAL=1
LABEL=""
PACKET_MODE=none
PACKET_SIZE=128
PACKET_FILE_MB=512
PACKET_FILES=4
ALLOW_NONROOT=no
MIN_FREE_MB=2048
ARGS_TEXT="$*"

while (( $# )); do
    case $1 in
        --server|--target) IFS=, read -r -a _t <<< "$2"; ARG_SERVERS+=("${_t[@]}"); shift 2 ;;
        --output) OUTPUT=$2; shift 2 ;;
        --duration) DURATION=$2; shift 2 ;;
        --max-hours) MAX_HOURS=$2; shift 2 ;;
        --interval) INTERVAL=$2; shift 2 ;;
        --label) LABEL=$2; shift 2 ;;
        --packet-capture) PACKET_MODE=$2; shift 2 ;;
        --packet-size) PACKET_SIZE=$2; shift 2 ;;
        --packet-file-mb) PACKET_FILE_MB=$2; shift 2 ;;
        --packet-files) PACKET_FILES=$2; shift 2 ;;
        --allow-nonroot) ALLOW_NONROOT=yes; shift ;;
        -h|--help) usage; exit 0 ;;
        *) usage; cs_die "Unknown option: $1" ;;
    esac
done

[[ $PACKET_MODE == none || $PACKET_MODE == headers ]] || cs_die "--packet-capture must be none or headers."
[[ $INTERVAL =~ ^[0-9]+$ ]] && (( INTERVAL >= 1 && INTERVAL <= 60 )) || cs_die "--interval must be 1 to 60 seconds."
[[ $DURATION =~ ^[0-9]+$ && $MAX_HOURS =~ ^[0-9]+$ ]] && (( MAX_HOURS >= 1 )) || cs_die "--duration and --max-hours must be whole numbers."
[[ $PACKET_SIZE =~ ^[0-9]+$ && $PACKET_FILE_MB =~ ^[0-9]+$ && $PACKET_FILES =~ ^[0-9]+$ ]] || cs_die "Packet options must be whole numbers."

if ! cs_is_root; then
    if [[ $ALLOW_NONROOT == yes ]]; then
        echo "Test mode without sudo: packet capture, firewall rules and some details are skipped."
        PACKET_MODE=none
    else
        cs_die "Run with sudo:  sudo bash $0 ${ARGS_TEXT}"
    fi
fi
if [[ $PACKET_MODE == headers ]] && ! cs_have tcpdump; then
    echo "Note: tcpdump is not installed, so packet headers will not be recorded (the rest runs). It can be added with: sudo apt install tcpdump"
    PACKET_MODE=none; PACKET_SKIPPED="tcpdump not installed"
fi

# ---------------------------------------------------------------------------
# One capture at a time
# ---------------------------------------------------------------------------
if [[ -f $CINESYS_STATE ]]; then
    old=$(cat "$CINESYS_STATE")
    alive=0
    if [[ -f $old/Raw/collectors.tsv ]]; then
        while IFS=$'\t' read -r name pid started out match; do
            cs_pid_is "$pid" "$match" && alive=1
        done < "$old/Raw/collectors.tsv"
    fi
    if (( alive )); then
        cs_die "A capture is already running: $old
Stop it first:  sudo bash $CINESYS_ROOT/Stop-CinesysCapture.sh"
    fi
    echo "Note: removing the record of an earlier capture that is no longer running ($old)."
    rm -f "$CINESYS_STATE"
fi

# ---------------------------------------------------------------------------
# What to watch
# ---------------------------------------------------------------------------
RUN_USER=${SUDO_USER:-$USER}
HOSTTAG=$(hostname -s)
source "$CINESYS_ROOT/lib/detect.sh"
source "$CINESYS_ROOT/lib/discover.sh"
echo "Looking for network and SAN storage ..."
DETECT_TMP=$(mktemp -d /tmp/cinesys-detect.XXXXXX)
cs_discover "$DETECT_TMP/Storage-Pre.txt"

# ---------------------------------------------------------------------------
# Capture folder and configuration
# ---------------------------------------------------------------------------
START_EPOCH=$(cs_epoch)
STARTED=$(cs_now)
CAP=$OUTPUT/${HOSTTAG}_$(date -d "@$START_EPOCH" '+%Y%m%d-%H%M%S')
labeltag=$(printf '%s' "$LABEL" | tr -c 'A-Za-z0-9._-' '-' | cut -c1-40)
[[ -n $labeltag ]] && CAP=${CAP}_$labeltag
mkdir -p "$CAP/Raw" || cs_die "Cannot create $CAP"
chmod 755 "$OUTPUT" "$CAP" 2>/dev/null
echo "$CAP" > "$CINESYS_STATE"
: > "$CAP/Raw/collectors.tsv"

{
    declare -p HOSTTAG INTERVAL RUN_USER START_EPOCH STARTED LABEL ARGS_TEXT
    declare -p PACKET_MODE PACKET_SIZE PACKET_FILE_MB PACKET_FILES MIN_FREE_MB DURATION MAX_HOURS ALLOW_NONROOT
    declare -p SERVER_IPS SERVER_NAME TARGET_ROLE SMB_SERVERS MOUNTS MOUNT_INST MOUNT_SERVER NFS_MOUNTS NFS_INST NFS_SERVER
    declare -p DISKS DISK_INST STORAGE_IFS WATCH_IFS IF_INST
} | sed 's/^declare -\([aAx-]*\)/declare -g\1/; s/^declare -g-/declare -g/' > "$CAP/Raw/config.sh"
mv "$DETECT_TMP/Storage-Pre.txt" "$CAP/Storage-Pre.txt" 2>/dev/null
printf '%s\n' "${CS_DET[@]}" > "$CAP/Raw/storage-pre.txt"
rm -rf "$DETECT_TMP"

cs_log "Cinesys Storage Diagnostics for Linux $CINESYS_VERSION"
cs_log "Capture folder: $CAP"
[[ -n $LABEL ]] && cs_log "Label: $LABEL"
for s in "${SERVER_IPS[@]}"; do cs_log "Target: $s ${SERVER_NAME[$s]:+(${SERVER_NAME[$s]}) }- ${TARGET_ROLE[$s]}"; done
for m in "${MOUNTS[@]}"; do cs_log "SMB:    ${MOUNT_INST[$m]} on $m"; done
for m in "${NFS_MOUNTS[@]}"; do cs_log "NFS:    ${NFS_INST[$m]} on $m"; done
for i in "${WATCH_IFS[@]}"; do cs_log "Adapter: ${IF_INST[$i]}$(cs_in "$i" "${STORAGE_IFS[@]}" && echo ' (carries storage traffic)')"; done
(( ${#SERVER_IPS[@]} )) || cs_log "No network storage found: whole-machine capture (adapters, disks, CPU, memory). Use --target to name a server."
[[ $ALLOW_NONROOT == yes ]] && ! cs_is_root && cs_warn "Test mode without sudo: packet capture, firewall rules and some details are not collected."
[[ -n ${PACKET_SKIPPED:-} ]] && cs_warn "Packet capture skipped: $PACKET_SKIPPED."

# ---------------------------------------------------------------------------
# Collectors (background, in their own session so they survive logout)
# ---------------------------------------------------------------------------
start_bg() {
    # name, match text for the pid check, output file, command...
    local name=$1 match=$2 out=$3; shift 3
    setsid nohup "$@" >> "$CAP/Raw/$name.log" 2>&1 < /dev/null &
    local pid=$!
    printf '%s\t%s\t%s\t%s\t%s\n' "$name" "$pid" "$(cs_now)" "${out:--}" "$match" >> "$CAP/Raw/collectors.tsv"
    LAST_PID=$pid
}
start_bg Sampler 'lib/sampler.sh' Raw/sampler.csv bash "$CINESYS_ROOT/lib/sampler.sh" "$CAP"
start_bg PathHealth 'lib/pathhealth.sh' Path-Health-Samples.csv bash "$CINESYS_ROOT/lib/pathhealth.sh" "$CAP"

# Kernel and storage-service log, streamed
if cs_have journalctl; then
    start_bg KernelLog 'journalctl -f' Raw/kernel-log-stream.txt bash -c 'exec journalctl -f -n 0 -o short-iso-precise --no-pager _TRANSPORT=kernel + _SYSTEMD_UNIT=iscsid.service + _SYSTEMD_UNIT=multipathd.service + _SYSTEMD_UNIT=NetworkManager.service + _SYSTEMD_UNIT=systemd-networkd.service > "$0"' "$CAP/Raw/kernel-log-stream.txt"
else
    start_bg KernelLog 'dmesg -w' Raw/kernel-log-stream.txt bash -c 'exec dmesg -w --time-format iso > "$0"' "$CAP/Raw/kernel-log-stream.txt"
fi

if [[ $PACKET_MODE == headers ]]; then
    if (( ${#SERVER_IPS[@]} )); then
        filt="tcp and ("; first=1
        for s in "${SERVER_IPS[@]}"; do filt+="$( (( first )) || echo ' or ')host $s"; first=0; done; filt+=")"
        pifs=("${STORAGE_IFS[@]}")
        if (( ! ${#pifs[@]} )); then
            for s in "${SERVER_IPS[@]}"; do r=$(cs_route_if "$s"); [[ -n $r ]] && ! cs_in "$r" "${pifs[@]}" && pifs+=("$r"); done
        fi
        (( ${#pifs[@]} )) || pifs=("${WATCH_IFS[0]}")
        for i in "${pifs[@]}"; do
            start_bg "PacketCapture-$i" "tcpdump -i $i " "Raw/Packets-$i.pcap0" \
                tcpdump -i "$i" -n -s "$PACKET_SIZE" -C "$PACKET_FILE_MB" -W "$PACKET_FILES" -Z root -w "$CAP/Raw/Packets-$i.pcap" "$filt"
        done
    else
        cs_warn "Packet capture skipped: no storage target. Name one with --target."
    fi
fi

# Keep a laptop from sleeping while the sampler runs (servers have no effect)
if cs_is_root && cs_have systemd-inhibit; then
    start_bg KeepAwake 'systemd-inhibit' '' systemd-inhibit --what=sleep:idle --who=Cinesys --why="storage capture" --mode=block sleep infinity
fi
# Automatic stop: --duration, or the safety limit
limit=$(( MAX_HOURS * 3600 ))
(( DURATION > 0 && DURATION * 60 < limit )) && limit=$(( DURATION * 60 ))
# Arguments passed separately (no quoting inside the command line), so the
# pid check can match "Stop-CinesysCapture.sh <capture folder>".
start_bg AutoStop "Stop-CinesysCapture.sh $CAP" '' bash -c 'sleep "$0"; exec bash "$1" --auto "$2"' "$limit" "$CINESYS_ROOT/Stop-CinesysCapture.sh" "$CAP"

# Collectors that die straight away (missing permission, missing tool)
sleep 3
while IFS=$'\t' read -r name pid started out match; do
    if ! kill -0 "$pid" 2>/dev/null; then
        err=$(tail -3 "$CAP/Raw/$name.log" 2>/dev/null | grep -v '^$' | tail -2 | tr '\n' ' ')
        cs_warn "$name did not start or stopped immediately. $err"
        printf '%s\t%s\t%s\t%s\n' "$name" "$(cs_now)" "Failed at start" "$err" >> "$CAP/Raw/collector-notes.tsv"
    elif [[ $name == PacketCapture-* ]] && grep -q 'snaplen raised' "$CAP/Raw/$name.log" 2>/dev/null; then
        # Never keep whole packets: stop it rather than record file contents.
        cs_stop_pid "$pid"
        cs_warn "$name stopped: tcpdump would not limit packets to $PACKET_SIZE bytes on this adapter."
        printf '%s\t%s\t%s\t%s\n' "$name" "$(cs_now)" "Stopped early" "would not limit packets to $PACKET_SIZE bytes" >> "$CAP/Raw/collector-notes.tsv"
    fi
done < "$CAP/Raw/collectors.tsv"

# ---------------------------------------------------------------------------
# Snapshot, inventory, topology (after the collectors, so data starts at once)
# ---------------------------------------------------------------------------
source "$CINESYS_ROOT/lib/snapshot.sh"
source "$CINESYS_ROOT/lib/manifest.sh"
cs_snapshot Pre
cs_inventory
cs_topology Pre
cs_write_manifest Running

echo ""
if [[ -s $CAP/Raw/findings-pre.txt ]]; then
    echo "Found before the capture (details in Topology-Pre.txt):"
    awk -F'|' '{printf "  %-5s %s\n", $1, $2}' "$CAP/Raw/findings-pre.txt"
    echo ""
fi
cs_log "Capture running. Reproduce the problem now (copy, playback, render)."
if (( DURATION > 0 )); then cs_log "It stops by itself after $DURATION minutes. To stop earlier:"; else cs_log "When done, stop it with:"; fi
cs_log "    sudo bash $CINESYS_ROOT/Stop-CinesysCapture.sh"
cs_log "Check on it with:  bash $CINESYS_ROOT/Get-CinesysCaptureStatus.sh"
