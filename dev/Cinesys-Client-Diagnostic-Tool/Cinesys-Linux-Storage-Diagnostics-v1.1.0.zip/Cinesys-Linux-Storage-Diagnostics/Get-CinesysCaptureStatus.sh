#!/bin/bash
# Shows the running capture: elapsed time, folder size, collectors, newest
# sample, warnings and path changes. No sudo needed.
#
#     bash Get-CinesysCaptureStatus.sh

CINESYS_ROOT=$(cd "$(dirname "$0")" && pwd)
source "$CINESYS_ROOT/lib/common.sh"

cs_read_state || { echo "No capture is running."; exit 0; }
source "$CAP/Raw/config.sh"
now=$(cs_epoch)
el=$(( now - START_EPOCH ))
echo "Capture running since $STARTED ($(( el / 3600 ))h $(( el % 3600 / 60 ))m)${LABEL:+   Label: $LABEL}"
echo "Folder: $CAP ($(cs_bytes_h "$(cs_dir_bytes "$CAP")"))"
(( DURATION > 0 )) && echo "Stops by itself after $DURATION minutes."
echo ""
printf '%-26s %-12s %s\n' Collector State Output
while IFS=$'\t' read -r name pid started out match; do
    if cs_pid_is "$pid" "$match"; then st=running; else st="NOT RUNNING"; fi
    sz=""; [[ $out != - && -f $CAP/$out ]] && sz=$(cs_bytes_h "$(stat -c %s "$CAP/$out")")
    printf '%-26s %-12s %s\n' "$name" "$st" "${out#-} ${sz:+($sz)}"
done < "$CAP/Raw/collectors.tsv"
if [[ -s $CAP/Raw/sampler.csv ]]; then
    n=$(( $(wc -l < "$CAP/Raw/sampler.csv") - 1 ))
    last=$(tail -1 "$CAP/Raw/sampler.csv" | cut -d, -f1)
    echo ""
    echo "Samples: $n, newest $(( now - ${last%.*} )) s ago"
fi
[[ -s $CAP/Raw/warnings.txt ]] && { echo ""; echo "Warnings:"; sed 's/^/  /' "$CAP/Raw/warnings.txt"; }
nchg=$(awk -F, 'NR > 1 && $4 != "\"(baseline)\""' "$CAP/Path-Health-Changes.csv" 2>/dev/null | wc -l)
(( nchg > 0 )) && { echo ""; echo "Path changes so far: $nchg (latest below)"; awk -F, 'NR > 1 && $4 != "\"(baseline)\""' "$CAP/Path-Health-Changes.csv" | tail -5 | sed 's/^/  /'; }
exit 0
