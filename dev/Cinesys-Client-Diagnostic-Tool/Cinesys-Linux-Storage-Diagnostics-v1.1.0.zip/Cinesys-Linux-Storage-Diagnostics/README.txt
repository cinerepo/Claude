CINESYS STORAGE DIAGNOSTICS FOR LINUX
=====================================

This folder contains scripts that Cinesys uses to troubleshoot slow file
transfers and playback on a Linux machine (Debian, Ubuntu and their
derivatives): network shares (SMB, NFS), StorNext volumes (SAN or LAN
client), iSCSI, Fibre Channel and NVMe-oF storage, or a machine that is
simply slow. You run it while the problem is happening, then send us the
result.

It only records. It does not change your network, mounts or settings, does
not install anything, and does not read or copy the contents of your files.
It does record names that describe your setup, such as server names, IP
addresses, share and export names, adapter names and the machine's model and
serial number. The data stays on the machine until you send it.
Docs/MANUAL.txt lists exactly what is collected, and Docs/COMMANDS.txt
lists every command it runs.


WHAT IT RECORDS
---------------

- Which storage the machine uses and how it is connected (shares and
  exports, StorNext, iSCSI sessions, Fibre Channel ports, multipath, and
  which network adapter carries each one).
- Every second: how fast each share, export or storage connection is
  reading and writing, NFS request times, the traffic, errors and drops on
  each network adapter, the connections' round trip time and
  retransmissions, memory, CPU and disk activity.
- Kernel messages while the capture runs (disconnects, timeouts, link
  changes, disk errors).
- A snapshot of the setup before and after: adapters, link speed, routing,
  DNS, mount options, services, and a hardware inventory.
- Every 5 seconds: whether each adapter, route, server, mount and storage
  session is still up.
- Only if Cinesys asks for it: packet headers (never the data inside the
  packets).


BEFORE YOU START
----------------

- An account that can use sudo (you will be asked for its password).
- Debian 10 or later, Ubuntu 18.04 or later, or a derivative. Nothing needs
  to be installed.
- At least 5 GB free in /var/tmp.
- Mount the share or volume you are having trouble with first. The scripts
  find everything that is mounted or connected when you start.


HOW TO RUN IT
-------------

1. Copy this whole folder to the machine (for example with scp, or unpack
   the zip in your home folder) and open a terminal in it:

       cd Cinesys-Linux-Storage-Diagnostics

2. Start the capture:

       sudo bash Start-CinesysCapture.sh

   Wait until it says "Capture running". This takes about half a minute.

3. Reproduce the problem. For example, start the copy that slows down or
   play the file that stutters. Write down the time you saw the problem.

   Ten to thirty minutes is usually enough. You can close the terminal or
   log out; the capture keeps running. It stops by itself after 12 hours.

4. Stop the capture:

       sudo bash Stop-CinesysCapture.sh

   Wait until it says "Capture saved in ...". This takes about 15 seconds.


WHAT TO SEND US
---------------

Stop prints a line like:

    Package: /var/tmp/Cinesys-Storage-Diagnostics/<HOST>_<DATE>-<TIME>.summary.zip

(.summary.tar.gz if zip is not installed.) Send that file using the upload
link your Cinesys engineer gave you. It is usually under 10 MB.

Please also tell us:
- the time(s) you saw the problem,
- what you were doing (for example "copied a 50 GB folder from the local
  disk to /mnt/projects"),
- which other machines you ran the Cinesys scripts on, if any.

You can look at the results yourself: Capture-Summary.txt in the capture
folder lists what was found.


QUICK CHECK (NO RECORDING)
--------------------------

If Cinesys only asks for a check of the machine, run this instead of steps
2-4. It takes under a minute; send the file it names.

    sudo bash Get-CinesysStorageInfo.sh


IF CINESYS ASKS FOR A SPECIFIC OPTION
-------------------------------------

Add the option to the Start command. Do not use these unless asked.
(Cinesys engineers: the option guide is Docs/Engineer-Guide.txt.)

    --target 10.0.0.25              Only watch this server.
    --duration 30                   Stop by itself after 30 minutes.
    --packet-capture headers        Also record packet headers (needs tcpdump).
    --label "test 2"                A note stored with the capture.

Example:

    sudo bash Start-CinesysCapture.sh --target 10.0.0.25 --duration 30


OTHER COMMANDS
--------------

Check whether a capture is running (no sudo needed):

    bash Get-CinesysCaptureStatus.sh

Abandon a capture without finishing it (whatever was recorded is kept):

    sudo bash Cancel-CinesysCapture.sh

Pack a capture again, using the capture folder that Stop printed:

    bash New-CinesysPackage.sh --capture "<the capture folder>"

Pack everything, including packet headers (only if Cinesys asks):

    bash New-CinesysPackage.sh --capture "<the capture folder>" --kind full


IF SOMETHING GOES WRONG
-----------------------

It says "No network storage found"
    It still records the machine itself. If the problem is with a share or
    volume, mount it first, stop, and start again.

"A capture is already running"
    A previous capture was never stopped. Run Stop (or Cancel), then Start
    again.

"Run with sudo"
    Type sudo in front of the command, as shown above.

A line starting with WARNING
    Part of the recording could not start. The rest still runs and is still
    useful. Send the capture anyway.

The machine restarted during the capture
    Run Stop when it is back. Send us the folder anyway.


REMOVING IT
-----------

Nothing is installed. Delete this folder, and delete
/var/tmp/Cinesys-Storage-Diagnostics when you no longer need the captures.
