﻿#requires -RunAsAdministrator
[CmdletBinding()]
param(
    [string]$DcsName = "Cinesys Storage Diagnostic",
    [int]$WaitSeconds = 0
)

$ErrorActionPreference = "Stop"

$dcs = New-Object -ComObject Pla.DataCollectorSet
$dcs.Query("Service\$DcsName", $null)

$location = [string]$dcs.LatestOutputLocation
if (!$location) {
    Write-Host "PLA does not yet report a LatestOutputLocation for '$DcsName'."
    return
}

Write-Host "Latest native PLA run:" -ForegroundColor Cyan
Write-Host "  $location"

$deadline = (Get-Date).AddSeconds($WaitSeconds)
do {
    $reportXml = Join-Path $location "report.xml"
    $reportHtml = Join-Path $location "report.html"
    $rulesLog = Join-Path $location "rules.log"

    if ((Test-Path $reportXml) -or (Test-Path $reportHtml)) { break }
    if ($WaitSeconds -le 0 -or (Get-Date) -ge $deadline) { break }
    Start-Sleep -Seconds 1
} while ($true)

Write-Host ""
Write-Host "Native report artifacts:" -ForegroundColor Cyan
foreach ($p in @($reportXml,$reportHtml,$rulesLog)) {
    if (Test-Path $p) {
        $f = Get-Item $p
        Write-Host ("  FOUND  {0}  ({1:N0} bytes)" -f $f.Name,$f.Length) -ForegroundColor Green
    } else {
        Write-Host ("  MISSING {0}" -f (Split-Path $p -Leaf)) -ForegroundColor Yellow
    }
}
