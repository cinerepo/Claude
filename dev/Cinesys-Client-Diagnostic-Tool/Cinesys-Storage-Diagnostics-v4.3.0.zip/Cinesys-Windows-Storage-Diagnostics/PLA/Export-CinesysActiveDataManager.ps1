﻿#requires -RunAsAdministrator
[CmdletBinding()]
param(
    [string]$DcsName = "Cinesys Storage Diagnostic",
    [string]$OutputDirectory = (Join-Path $env:USERPROFILE "Desktop\Cinesys-PLA-Active-DataManager")
)
$ErrorActionPreference = "Stop"
New-Item -ItemType Directory -Force -Path $OutputDirectory | Out-Null
$dcs = New-Object -ComObject Pla.DataCollectorSet
$dcs.Query("Service\$DcsName", $null)
$dcs.Xml | Set-Content -Encoding UTF8 (Join-Path $OutputDirectory "Cinesys-DCS.xml")
([string]$dcs.DataManager.ReportSchema) | Set-Content -Encoding UTF8 (Join-Path $OutputDirectory "Cinesys-ReportSchema-expanded.xml")
([string]$dcs.DataManager.Rules) | Set-Content -Encoding UTF8 (Join-Path $OutputDirectory "Cinesys-Rules-expanded.xml")
Write-Host "Exported active Cinesys PLA DataManager configuration:" -ForegroundColor Green
Write-Host "  $OutputDirectory"
