﻿[CmdletBinding()]
param([string]$DcsName = "Cinesys Storage Diagnostic")

$ErrorActionPreference = "Stop"
$dcs = New-Object -ComObject Pla.DataCollectorSet
$dcs.Query("Service\$DcsName", $null)
$location = [string]$dcs.LatestOutputLocation
if (!$location) { throw "No LatestOutputLocation is registered for '$DcsName'." }

$report = Join-Path $location "report.html"
if (!(Test-Path $report)) { throw "Native report not found: $report" }

Start-Process $report
Write-Host "Opened: $report"
