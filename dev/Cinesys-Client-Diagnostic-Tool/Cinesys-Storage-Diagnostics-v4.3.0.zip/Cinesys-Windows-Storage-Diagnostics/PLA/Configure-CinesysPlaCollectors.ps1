﻿#requires -RunAsAdministrator
[CmdletBinding()]
param(
    [string]$DcsName = "Cinesys Storage Diagnostic",
    [string]$DefinitionPath = (Join-Path $PSScriptRoot "Cinesys-ConfigurationCollectors.xml")
)

$ErrorActionPreference = "Stop"

if (!(Test-Path $DefinitionPath)) {
    throw "PLA configuration definition not found: $DefinitionPath"
}

[xml]$definition = Get-Content $DefinitionPath -Raw

# Service namespace is where normal user-created persistent DCS objects live.
$qualifiedName = "Service\$DcsName"
$dcs = New-Object -ComObject Pla.DataCollectorSet
$dcs.Query($qualifiedName, $null)

$collectors = $dcs.DataCollectors
$wantedNames = @($definition.CinesysPlaConfiguration.Collector | ForEach-Object { [string]$_.Name })

# Replace only the Cinesys configuration collectors defined by this file.
# Leave the Performance Counter collector and any future unrelated collectors untouched.
for ($i = [int]$collectors.Count - 1; $i -ge 0; $i--) {
    $existing = $collectors.Item($i)
    if ([int]$existing.DataCollectorType -eq 2 -and $wantedNames -contains [string]$existing.Name) {
        $collectors.Remove([int]$i)
    }
}

foreach ($spec in @($definition.CinesysPlaConfiguration.Collector)) {
    $collector = $collectors.CreateDataCollector(2) # plaConfiguration
    $collector.Name = [string]$spec.Name
    $collector.FileName = [string]$spec.FileName
    $collector.QueryNetworkAdapters = ([string]$spec.QueryNetworkAdapters -eq "true")

    $queries = @($spec.ManagementQuery | ForEach-Object {
        if ($_ -ne $null) { [string]$_.'#text' } else { $null }
    } | Where-Object { $_ })

    # PowerShell's XML adapter sometimes exposes simple element content as the
    # element itself instead of #text. Normalize that here.
    if ($queries.Count -eq 0) {
        $queries = @($spec.ManagementQuery | ForEach-Object { [string]$_ } | Where-Object { $_ })
    }

    $registry = @($spec.RegistryKey | ForEach-Object {
        if ($_ -ne $null) { [string]$_.'#text' } else { $null }
    } | Where-Object { $_ })
    if ($registry.Count -eq 0) {
        $registry = @($spec.RegistryKey | ForEach-Object { [string]$_ } | Where-Object { $_ })
    }

    if ($queries.Count -gt 0) {
        $collector.ManagementQueries = [string[]]$queries
    }
    if ($registry.Count -gt 0) {
        $collector.RegistryKeys = [string[]]$registry
        $collector.RegistryMaxRecursiveDepth = 3
    }

    $collectors.Add($collector)
}

# plaModify = 0x2. Commit returns an IValueMap containing validation
# warnings/errors. A successful COM call can still return validation entries.
$validation = $dcs.Commit($qualifiedName, $null, 0x2)

$validationMessages = @()
if ($validation -and [int]$validation.Count -gt 0) {
    for ($i=0; $i -lt [int]$validation.Count; $i++) {
        $item = $validation.Item($i)
        $validationMessages += ("{0}: {1} (0x{2:X8})" -f $item.Key, $item.Description, ([uint32]$item.Value))
    }
}

Write-Host "Native PLA configuration collectors installed:" -ForegroundColor Green
foreach ($name in $wantedNames) {
    Write-Host "  $name"
}

if ($validationMessages.Count -gt 0) {
    $ignored = @($validationMessages | Where-Object { $_ -match '\(0x00300100\)$' })
    $other = @($validationMessages | Where-Object { $_ -notmatch '\(0x00300100\)$' })
    if ($ignored.Count -gt 0) {
        Write-Host "PLA informational validation: $($ignored.Count) property value(s) ignored by this collector type." -ForegroundColor DarkGray
    }
    if ($other.Count -gt 0) {
        Write-Warning ("PLA returned validation messages:`n  " + ($other -join "`n  "))
    }
}
