﻿#requires -RunAsAdministrator
[CmdletBinding()]
param(
    [string]$OutputDirectory = (Join-Path $env:USERPROFILE "Desktop\Cinesys-SystemDiagnostics-PLA-Reference")
)

$ErrorActionPreference = "Stop"
New-Item -ItemType Directory -Force -Path $OutputDirectory | Out-Null

$dcs = New-Object -ComObject Pla.DataCollectorSet
$dcs.Query("System\System Diagnostics", $null)

$dcs.Xml | Set-Content -Encoding UTF8 (Join-Path $OutputDirectory "System-Diagnostics-DCS.xml")

$dm = $dcs.DataManager
[pscustomobject]@{
    Enabled = $dm.Enabled
    CheckBeforeRunning = $dm.CheckBeforeRunning
    ReportFileName = $dm.ReportFileName
    RuleTargetFileName = $dm.RuleTargetFileName
    EventsFileName = $dm.EventsFileName
    ReportSchemaLength = ([string]$dm.ReportSchema).Length
    RulesLength = ([string]$dm.Rules).Length
} | Format-List | Out-String | Set-Content (Join-Path $OutputDirectory "DataManager-Summary.txt")

([string]$dm.ReportSchema) | Set-Content -Encoding UTF8 (Join-Path $OutputDirectory "ReportSchema.xml")
([string]$dm.Rules) | Set-Content -Encoding UTF8 (Join-Path $OutputDirectory "Rules.xml")

Write-Host "Exported the built-in System Diagnostics PLA definition for reference:" -ForegroundColor Green
Write-Host "  $OutputDirectory"
Write-Host ""
Write-Host "This does not modify System Diagnostics."
