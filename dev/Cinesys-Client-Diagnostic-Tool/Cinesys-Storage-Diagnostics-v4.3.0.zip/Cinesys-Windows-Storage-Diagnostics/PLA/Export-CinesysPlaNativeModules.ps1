﻿#requires -RunAsAdministrator
[CmdletBinding()]
param(
    [string]$OutputDirectory = (Join-Path $env:USERPROFILE "Desktop\Cinesys-PLA-Native-Modules")
)

$ErrorActionPreference = "Stop"
New-Item -ItemType Directory -Force -Path $OutputDirectory | Out-Null

$reportOut = Join-Path $OutputDirectory "Reports"
$rulesOut = Join-Path $OutputDirectory "Rules"
New-Item -ItemType Directory -Force -Path $reportOut,$rulesOut | Out-Null

$reportNames = @(
    "Report.System.Common.xml",
    "Report.System.Summary.xml",
    "Report.System.Performance.xml",
    "Report.System.Disk.xml",
    "Report.System.Network.xml",
    "Report.System.CPU.xml",
    "Report.System.Memory.xml",
    "Report.System.Configuration.xml"
)

$ruleNames = @(
    "Rules.System.Common.xml",
    "Rules.System.Summary.xml",
    "Rules.System.Performance.xml",
    "Rules.System.Disk.xml",
    "Rules.System.Network.xml",
    "Rules.System.CPU.xml",
    "Rules.System.Memory.xml",
    "Rules.System.Configuration.xml",
    "Rules.System.Finale.xml"
)

foreach ($name in $reportNames) {
    $src = Join-Path $env:SystemRoot "PLA\Reports\$name"
    if (Test-Path $src) { Copy-Item $src $reportOut -Force }
}
foreach ($name in $ruleNames) {
    $src = Join-Path $env:SystemRoot "PLA\Rules\$name"
    if (Test-Path $src) { Copy-Item $src $rulesOut -Force }
}

$manifest = @()
Get-ChildItem $OutputDirectory -Recurse -File | ForEach-Object {
    $manifest += [pscustomobject]@{
        RelativePath = $_.FullName.Substring($OutputDirectory.Length).TrimStart('\')
        Length = $_.Length
        SHA256 = (Get-FileHash $_.FullName -Algorithm SHA256).Hash
    }
}
$manifest | Export-Csv (Join-Path $OutputDirectory "manifest.csv") -NoTypeInformation

Write-Host "Exported native PLA report/rule modules:" -ForegroundColor Green
Write-Host "  $OutputDirectory"
Write-Host ""
Write-Host "These are copies only. Nothing under %SystemRoot%\PLA was modified."
