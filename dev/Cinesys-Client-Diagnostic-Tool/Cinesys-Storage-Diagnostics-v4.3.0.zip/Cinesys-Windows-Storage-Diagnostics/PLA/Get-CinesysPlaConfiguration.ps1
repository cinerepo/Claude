﻿#requires -RunAsAdministrator
[CmdletBinding()]
param([string]$DcsName = "Cinesys Storage Diagnostic")

$ErrorActionPreference = "Stop"
$dcs = New-Object -ComObject Pla.DataCollectorSet
$dcs.Query("Service\$DcsName", $null)

Write-Host "Data Collector Set: $DcsName" -ForegroundColor Cyan
Write-Host "Status: $($dcs.Status)"
Write-Host "RootPath: $($dcs.RootPath)"
Write-Host "LatestOutputLocation: $($dcs.LatestOutputLocation)"
Write-Host ""
Write-Host "Collectors:" -ForegroundColor Cyan

for ($i=0; $i -lt [int]$dcs.DataCollectors.Count; $i++) {
    $dc = $dcs.DataCollectors.Item($i)
    $type = switch ([int]$dc.DataCollectorType) {
        0 { "Performance Counter" }
        1 { "Trace" }
        2 { "Configuration" }
        3 { "Alert" }
        4 { "API Trace" }
        default { "Type $($dc.DataCollectorType)" }
    }
    Write-Host ("  [{0}] {1} | {2} | File={3}" -f $i,$dc.Name,$type,$dc.FileName)
}

$dm = $dcs.DataManager
Write-Host ""
Write-Host "Data Manager:" -ForegroundColor Cyan
Write-Host "  Enabled: $($dm.Enabled)"
Write-Host "  ReportFileName: $($dm.ReportFileName)"
Write-Host "  RuleTargetFileName: $($dm.RuleTargetFileName)"
Write-Host "  EventsFileName: $($dm.EventsFileName)"
Write-Host "  ReportSchema length: $(([string]$dm.ReportSchema).Length)"
Write-Host "  Rules length: $(([string]$dm.Rules).Length)"
Write-Host "  MinFreeDisk: $($dm.MinFreeDisk)"
Write-Host "  MaxSize: $($dm.MaxSize)"
Write-Host "  MaxFolderCount: $($dm.MaxFolderCount)"
Write-Host "  ResourcePolicy: $($dm.ResourcePolicy)"
