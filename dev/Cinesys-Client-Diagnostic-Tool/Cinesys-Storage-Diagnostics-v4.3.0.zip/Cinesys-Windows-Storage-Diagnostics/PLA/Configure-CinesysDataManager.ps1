﻿#requires -RunAsAdministrator
[CmdletBinding()]
param(
    [string]$DcsName = "Cinesys Storage Diagnostic",
    [string]$ReportSchemaPath = (Join-Path $PSScriptRoot "Cinesys-Native-ReportSchema.xml"),
    [string]$RulesPath = (Join-Path $PSScriptRoot "Cinesys-Native-Rules.xml")
)

$ErrorActionPreference = "Stop"

foreach ($p in @($ReportSchemaPath,$RulesPath)) {
    if (!(Test-Path $p)) { throw "Required native PLA report configuration file not found: $p" }
}

$dcs = New-Object -ComObject Pla.DataCollectorSet
$qualifiedName = "Service\$DcsName"
$dcs.Query($qualifiedName, $null)

$dm = $dcs.DataManager

# Baseline is intentionally modeled on Microsoft's built-in System Diagnostics
# DataManager. The schema/rules wrapper files import Microsoft's existing PLA
# report/rule modules from %SystemRoot%\PLA.
$dm.Enabled = $true
$dm.CheckBeforeRunning = $true
$dm.MinFreeDisk = 200
# Retention limits are effectively disabled. v3.8 used MaxSize=1024 MB with
# ResourcePolicy 0 (delete largest), and a single Hyper-V host capture with ETW
# is ~5 GB, so PLA could delete earlier capture folders. Explicit large values
# are used rather than 0 so nothing depends on how PLA interprets 0.
# Captures are removed by hand.
$dm.MaxSize = 4000000        # MB (~4 TB)
$dm.MaxFolderCount = 10000
$dm.ResourcePolicy = 0
$dm.ReportFileName = "report.html"
$dm.RuleTargetFileName = "report.xml"
$dm.EventsFileName = ""
$schemaText = Get-Content $ReportSchemaPath -Raw
$rulesText = Get-Content $RulesPath -Raw

$reportModule = Join-Path $PSScriptRoot "Reports\Report.Cinesys.Storage.xml"
$ruleModule = Join-Path $PSScriptRoot "Rules\Rules.Cinesys.Storage.xml"
if (!(Test-Path $reportModule)) { throw "Cinesys native report module missing: $reportModule" }
if (!(Test-Path $ruleModule)) { throw "Cinesys native rules module missing: $ruleModule" }

$reportModuleXml = [System.Security.SecurityElement]::Escape((Resolve-Path $reportModule).Path)
$ruleModuleXml = [System.Security.SecurityElement]::Escape((Resolve-Path $ruleModule).Path)

$schemaText = $schemaText.Replace("__CINESYS_REPORT_MODULE__", $reportModuleXml)
$rulesText = $rulesText.Replace("__CINESYS_RULE_MODULE__", $ruleModuleXml)

$dm.ReportSchema = $schemaText
$dm.Rules = $rulesText

$validation = $dcs.Commit($qualifiedName, $null, 0x2)

$messages = @()
if ($validation -and [int]$validation.Count -gt 0) {
    for ($i=0; $i -lt [int]$validation.Count; $i++) {
        $item = $validation.Item($i)
        $messages += [pscustomobject]@{
            Key = [string]$item.Key
            Description = [string]$item.Description
            Code = ("0x{0:X8}" -f ([uint32]$item.Value))
        }
    }
}

Write-Host "Native PLA DataManager enabled." -ForegroundColor Green
Write-Host "  ReportFileName: report.html"
Write-Host "  RuleTargetFileName: report.xml"
Write-Host "  ReportSchema: $ReportSchemaPath"
Write-Host "  Rules: $RulesPath"

if ($messages.Count -gt 0) {
    $ignored = @($messages | Where-Object { $_.Code -eq "0x00300100" })
    $other = @($messages | Where-Object { $_.Code -ne "0x00300100" })

    if ($ignored.Count -gt 0) {
        Write-Host "PLA informational validation: $($ignored.Count) property value(s) ignored by this collector type." -ForegroundColor DarkGray
    }
    if ($other.Count -gt 0) {
        Write-Warning ("PLA returned validation messages:`n  " + (($other | ForEach-Object {
            "$($_.Key): $($_.Description) ($($_.Code))"
        }) -join "`n  "))
    }
}
