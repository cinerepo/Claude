CINESYS STORAGE DIAGNOSTICS
===========================

This folder contains a set of PowerShell scripts that Cinesys uses to
troubleshoot slow file transfers, storage stalls, and similar performance
problems on Windows servers. You run it while the problem is happening, then
send us the output folder.

It only records. It does not change your storage, network, shares, or VMs,
and it does not read or copy the contents of your files. It does record
names that describe your environment, such as server names, IP addresses,
share and file names, and the user accounts connected to shares. The data
stays on the server until you send it. Docs\MANUAL.txt lists exactly what
is collected and what the scripts change.


WHAT IT RECORDS
---------------

- Performance counters every second: disk, file system cache, CPU, memory,
  network adapters, TCP, SMB, and on Hyper-V hosts the virtual disks,
  virtual switches and Cluster Shared Volumes.
- A Windows performance trace (ETW) showing how long disk and file requests
  take and where the CPU time goes.
- A snapshot of the configuration before and after: disks, volumes, network
  adapters, iSCSI and MPIO, SMB settings, cluster state, and recent storage
  and network warnings from the System event log.
- A map of how the storage is connected, for example:
  share -> volume -> virtual disk -> cluster volume -> SAN paths -> network ports.
- Every few seconds, the state of the iSCSI connections, storage paths,
  cluster volumes and network links, so we can see if anything dropped or
  failed over during the problem.
- Only if Cinesys asks for it: network packet counters, or packet headers
  for SMB and iSCSI traffic (never the data inside the packets).


BEFORE YOU START
----------------

- Run it on the machine Cinesys asked for. That is often more than one,
  for example the file server VM and the Hyper-V host it runs on. Start them
  at about the same time.
- You need a local administrator account.
- Free space on C: of at least 10 GB. A 20-minute capture on a busy
  Hyper-V host can produce several GB.
- Windows Server 2016 or later, or Windows 10/11. Nothing needs to be
  installed.
- Expect a small amount of extra CPU load while it runs. It is safe to run
  during production hours.


HOW TO RUN IT
-------------

1. Copy this whole folder to the server, for example to C:\Cinesys.

2. Open PowerShell as Administrator (right-click PowerShell, then
   "Run as administrator").

3. Allow the scripts to run in this window only, and go to the folder:

       Set-ExecutionPolicy -Scope Process Bypass
       cd C:\Cinesys\Cinesys-Windows-Storage-Diagnostics

4. Start the capture:

       .\Start-CinesysStorageDiagnostic.ps1

   Wait until it says "Ready". This takes about a minute.

5. Reproduce the problem. For example, start the file copy that slows
   down. Write down the time you saw the problem; it helps us find it in
   the data.

   Ten to thirty minutes of capture is usually enough. Try to keep it
   under an hour.

6. Stop the capture:

       .\Stop-CinesysStorageDiagnostic.ps1

   Stopping can take a few minutes while Windows finishes writing the
   trace and the scripts analyze and pack the results. Leave the window
   open until it says "Send to Cinesys: ...".


WHAT TO SEND US
---------------

When Stop finishes, it prints a line like:

    Send to Cinesys: C:\PerfLogs\Admin\Cinesys Storage Diagnostic\<SERVER>_<DATE>-<NUMBER>.summary.zip

Send that file using the upload link your Cinesys engineer gave you. It is
usually small enough for any upload service.

The full capture folder next to it (same name, without .summary.zip) also
contains the detailed performance trace, which can be several GB. Keep it
until we confirm we do not need it. If we ask for it, run:

    .\New-CinesysPackage.ps1 -CapturePath "<the capture folder>" -Kind Full

and send the .full.zip it creates.

Please also tell us:
- the time(s) you saw the problem,
- what you were doing (for example "copied a 50 GB file from workstation X
  to \\server\share"),
- which servers you ran it on.

You can also look at the results yourself: Findings.txt in the capture
folder lists any slowdowns the scripts found, and Performance Monitor shows
the counters under Reports > User Defined > Cinesys Storage Diagnostic.


IF CINESYS ASKS FOR A SPECIFIC OPTION
-------------------------------------

Add the option to the Start command. Do not use these unless asked.
(Cinesys engineers: the full option guide is Docs\Engineer-Guide.txt.)

    -TraceProfile General,Storage,SMB      Choose what the performance trace covers.
    -TraceProfile BuiltIn                  Use the standard Windows trace instead.
    -NoEtw                                 No performance trace (counters only).
    -PacketCapture Counters                Count packets and drops per network component.
    -PacketCapture Headers                 Also record packet headers for SMB/iSCSI.
    -PacketFilterIp 10.0.0.25              Only record packets to/from this address.
    -PathTestIp 10.0.0.30                  Also test the network path to this address.
    -NoPathHealth                          Do not poll storage path state.

Example:

    .\Start-CinesysStorageDiagnostic.ps1 -TraceProfile General,Storage,SMB -PacketCapture Counters


OTHER COMMANDS
--------------

Check whether a capture is running:

    .\Get-CinesysStorageDiagnosticStatus.ps1

Abandon a capture without finishing it (whatever was recorded is kept):

    .\Cancel-CinesysStorageDiagnostic.ps1

Pack a capture again (for example if the .summary.zip was deleted). Use the
capture folder that Stop printed:

    .\New-CinesysPackage.ps1 -CapturePath "<the capture folder>"

Pack everything, including the detailed trace (only if Cinesys asks):

    .\New-CinesysPackage.ps1 -CapturePath "<the capture folder>" -Kind Full


IF SOMETHING GOES WRONG
-----------------------

"An active Cinesys capture is already registered"
    A previous capture was never stopped. Run Stop (or Cancel), then Start
    again.

"ETW/WPR not running" or "WPR reports an existing recording"
    The performance trace could not start, often because another tool is
    already recording. The capture still continues with counters and
    configuration data, which is still useful. Send it anyway.

"A Data Collector Set named ... already exists but was not created by Cinesys"
    Something else on this server uses the same name. Contact Cinesys
    before going further.

The window was closed or the server rebooted during a capture
    Open PowerShell as Administrator again and run Stop. If that fails, run
    Cancel. Then send us the folder anyway.

Anything else
    Send us the screenshot or text of the error and the capture folder, if
    one was created.


REMOVING IT
-----------

The scripts leave one entry in Performance Monitor ("Cinesys Storage
Diagnostic" under Data Collector Sets > User Defined) so later captures
reuse it. To remove it:

    .\Remove-CinesysDataCollectorSet.ps1

Then delete this folder, C:\Cinesys\Storage-Diagnostic, and any capture
folders under C:\PerfLogs\Admin\Cinesys Storage Diagnostic that you no
longer need.
