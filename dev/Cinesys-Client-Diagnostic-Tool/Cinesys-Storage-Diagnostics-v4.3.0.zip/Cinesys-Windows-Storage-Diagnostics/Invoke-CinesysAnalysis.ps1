<#
Finds throughput stalls in one or more Cinesys captures and lays out what every
layer was doing around each one.

    .\Invoke-CinesysAnalysis.ps1 -CapturePath "C:\PerfLogs\Admin\Cinesys Storage Diagnostic\VM_20261012-000001"
    .\Invoke-CinesysAnalysis.ps1 -CapturePath <vm capture>,<host capture> -OutputPath C:\Temp\Case

With several captures (for example a file server VM and its Hyper-V host),
the clock offset between them is estimated by matching the VM's disk writes
against the host's virtual disk (VHDX) writes, and every stall table shows
both machines.

Output (in -OutputPath, default: the first capture folder):
    Findings.txt   readable report        Findings.json   full data
    Stalls.csv     one row per stall

The observations are pattern checks to verify, not root-cause verdicts.
Runs in Windows PowerShell 5.1 and PowerShell 7 (also on macOS/Linux, given
a capture that already contains Cinesys-Performance.csv).
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)][string[]]$CapturePath,
    [string]$OutputPath,
    # A workload counts as active above this rate (MB/s) or 25% of its p95, whichever is higher.
    [double]$MinActiveMBps = 50,
    # Shortest drop that is reported as a stall, in samples (seconds).
    [int]$MinStallSeconds = 2
)

$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName Microsoft.VisualBasic
$NaN = [double]::NaN
$inv = [System.Globalization.CultureInfo]::InvariantCulture

# ---------------------------------------------------------------------------
# Small numeric helpers (NaN = missing sample)
# ---------------------------------------------------------------------------
function Get-Valid([double[]]$a) { @($a | Where-Object { -not [double]::IsNaN($_) }) }
function Get-Pct([double[]]$a, [double]$p) {
    $v = @(Get-Valid $a | Sort-Object)
    if ($v.Count -eq 0) { return $NaN }
    $i = [int][math]::Floor(($v.Count - 1) * $p)
    return [double]$v[$i]
}
function Get-Mean([double[]]$a) {
    $v = @(Get-Valid $a)
    if ($v.Count -eq 0) { return $NaN }
    return [double](($v | Measure-Object -Sum).Sum / $v.Count)
}
function Get-Max([double[]]$a) {
    $v = @(Get-Valid $a)
    if ($v.Count -eq 0) { return $NaN }
    return [double](($v | Measure-Object -Maximum).Maximum)
}
function Get-Slice([double[]]$a, [int]$from, [int]$to) {
    if ($from -lt 0) { $from = 0 }
    if ($to -ge $a.Count) { $to = $a.Count - 1 }
    if ($to -lt $from) { return [double[]]@() }
    return [double[]]$a[$from..$to]
}
function Format-Num([double]$v, [string]$unit) {
    if ([double]::IsNaN($v)) { return '-' }
    switch ($unit) {
        'MB/s' { return ('{0:N0}' -f $v) }
        'ms'   { return ('{0:N1}' -f $v) }
        'GB'   { return ('{0:N2}' -f $v) }
        '%'    { return ('{0:N0}' -f $v) }
        default { if ([math]::Abs($v) -ge 100) { return ('{0:N0}' -f $v) } else { return ('{0:N1}' -f $v) } }
    }
}

# ---------------------------------------------------------------------------
# Loading a capture
# ---------------------------------------------------------------------------
function Read-PerfCsv {
    param([string]$Path)
    $parser = New-Object Microsoft.VisualBasic.FileIO.TextFieldParser($Path)
    $parser.SetDelimiters(',')
    $parser.HasFieldsEnclosedInQuotes = $true
    $header = $parser.ReadFields()
    $rows = New-Object System.Collections.Generic.List[string[]]
    while (-not $parser.EndOfData) {
        try { $rows.Add($parser.ReadFields()) } catch {}
    }
    $parser.Close()
    $hostName = $null
    if ($header.Count -gt 1 -and $header[1] -match '^\\\\([^\\]+)\\') { $hostName = $Matches[1] }
    $cols = New-Object System.Collections.Generic.List[object]
    for ($i = 1; $i -lt $header.Count; $i++) {
        $n = $header[$i] -replace '^\\\\[^\\]+', ''
        if ($n -match '^\\(?<obj>[^\\(]+)(\((?<inst>.*)\))?\\(?<ctr>[^\\]+)$') {
            $cols.Add([pscustomobject]@{ Index = $i; Object = $Matches['obj']; Instance = $Matches['inst']; Counter = $Matches['ctr']; Name = $n })
        }
    }
    $formats = [string[]]@('MM/dd/yyyy HH:mm:ss.fff','M/d/yyyy HH:mm:ss.fff','MM/dd/yyyy HH:mm:ss','M/d/yyyy H:mm:ss.fff')
    $times = New-Object System.Collections.Generic.List[datetime]
    $keep = New-Object System.Collections.Generic.List[string[]]
    foreach ($r in $rows) {
        $t = [datetime]::MinValue
        if ([datetime]::TryParseExact($r[0], $formats, $inv, [System.Globalization.DateTimeStyles]::None, [ref]$t)) {
            $times.Add($t.AddMilliseconds(-$t.Millisecond)); $keep.Add($r)
        }
    }
    [pscustomobject]@{ Host = $hostName; Columns = $cols.ToArray(); Rows = $keep; Times = $times.ToArray() }
}

function Get-Column {
    param($Cap, $Col, [double]$Scale = 1)
    $vals = New-Object double[] $Cap.Rows.Count
    for ($i = 0; $i -lt $Cap.Rows.Count; $i++) {
        $s = $Cap.Rows[$i][$Col.Index]
        $d = 0.0
        if ($s -and [double]::TryParse($s.Trim(), [System.Globalization.NumberStyles]::Float, $inv, [ref]$d)) { $vals[$i] = $d * $Scale } else { $vals[$i] = $NaN }
    }
    return ,$vals
}

function Find-Columns {
    param($Cap, [string]$Object, [string]$Counter, [string]$InstanceMatch = '.*', [string]$InstanceExclude = '^$')
    @($Cap.Columns | Where-Object { $_.Object -eq $Object -and $_.Counter -eq $Counter -and ([string]$_.Instance) -match $InstanceMatch -and ([string]$_.Instance) -notmatch $InstanceExclude })
}

function Get-ShareDiskMap {
    # Share name -> disk number, from the v3.10+ topology map.
    param([string]$Path)
    $map = @{}
    foreach ($f in @('Topology-Pre.json','Topology-Post.json')) {
        $p = Join-Path $Path $f
        if (!(Test-Path $p)) { continue }
        try {
            foreach ($sh in @((Get-Content $p -Raw | ConvertFrom-Json).SmbShares)) {
                if ($sh.Name -and $null -ne $sh.DiskNumber -and -not $map.ContainsKey($sh.Name)) { $map[[string]$sh.Name] = [int]$sh.DiskNumber }
            }
        } catch {}
    }
    return $map
}

function Test-NexisCapture {
    # Was the Avid NEXIS client installed? Topology (v4.3+), the Mac/Linux
    # manifest, or the snapshot and PLA files of older captures.
    param([string]$Path, $Manifest)
    foreach ($f in @('Topology-Pre.json','Topology-Post.json')) {
        $p = Join-Path $Path $f
        if (!(Test-Path $p)) { continue }
        try { $t = Get-Content $p -Raw | ConvertFrom-Json; if ($t.PSObject.Properties['AvidNexis'] -and $t.AvidNexis.Present) { return $true } } catch {}
    }
    if ($Manifest -and $Manifest.PSObject.Properties['Storage'] -and @($Manifest.Storage | Where-Object { $_.Protocol -eq 'NEXIS' }).Count) { return $true }
    foreach ($f in @('PreCapture-State.txt','System Services.xml')) {
        $p = Join-Path $Path $f
        if ((Test-Path $p) -and (Select-String -Path $p -Pattern 'AvidFos|Avid NEXIS' -Quiet)) { return $true }
    }
    return $false
}

function Import-CinesysCapture {
    param([string]$Path)
    if (!(Test-Path $Path)) { throw "Capture folder not found: $Path" }
    $csv = Join-Path $Path 'Cinesys-Performance.csv'
    if (!(Test-Path $csv)) {
        $blg = Get-ChildItem $Path -Filter 'Cinesys-Performance*.blg' -ErrorAction SilentlyContinue | Sort-Object Length -Descending | Select-Object -First 1
        if ($blg -and (Get-Command relog.exe -ErrorAction SilentlyContinue)) {
            Write-Host "Exporting $($blg.Name) to CSV..." -ForegroundColor Cyan
            & relog.exe $blg.FullName -f csv -o $csv -y | Out-Null
        }
        if (!(Test-Path $csv)) { throw "No Cinesys-Performance.csv in $Path (and no BLG/relog to create it)." }
    }
    $perf = Read-PerfCsv -Path $csv
    if ($perf.Times.Count -lt 10) { throw "Too few samples in $csv." }
    $manifest = $null
    $mf = Join-Path $Path 'Capture-Manifest.json'
    if (Test-Path $mf) { $manifest = Get-Content $mf -Raw | ConvertFrom-Json }
    $hostName = $perf.Host
    if (-not $hostName -and $manifest) { $hostName = $manifest.Host }
    $index = @{}
    for ($i = 0; $i -lt $perf.Times.Count; $i++) { $index[$perf.Times[$i].Ticks] = $i }
    [pscustomobject]@{
        Path = $Path; Host = $hostName; Columns = $perf.Columns; Rows = $perf.Rows; Times = $perf.Times; Index = $index; Manifest = $manifest
        OffsetSeconds = 0; OffsetNote = 'reference clock'; Series = @(); Events = @(); PathChanges = @()
        ShareDisk = (Get-ShareDiskMap -Path $Path)
        Nexis = (Test-NexisCapture -Path $Path -Manifest $manifest)
    }
}

# ---------------------------------------------------------------------------
# Key series per capture, grouped by layer (top of the stack first)
# ---------------------------------------------------------------------------
function New-Series($Cap, $Order, $Group, $Label, $Unit, $Values, $Kind) {
    [pscustomobject]@{ Capture = $Cap; Host = $Cap.Host; Order = $Order; Group = $Group; Label = $Label; Unit = $Unit; Values = $Values; Kind = $Kind }
}

function Get-KeySeries {
    param($Cap)
    $list = New-Object System.Collections.Generic.List[object]
    $MB = 1.0 / 1MB

    # SMB server and client shares (one set per active share)
    foreach ($obj in @('SMB Server Shares','SMB Client Shares')) {
        $tag = $(if ($obj -like 'SMB Server*') { 'SMB server' } else { 'SMB client' })
        foreach ($c in (Find-Columns $Cap $obj 'Write Bytes/sec' '.' '^(_Total|.*IPC\$)$')) {
            $w = Get-Column $Cap $c $MB
            $rc = @(Find-Columns $Cap $obj 'Read Bytes/sec' ('^' + [regex]::Escape($c.Instance) + '$'))
            $r = $(if ($rc.Count) { Get-Column $Cap $rc[0] $MB } else { $null })
            if ((Get-Max $w) -lt 5 -and (-not $r -or (Get-Max $r) -lt 5)) { continue }
            $share = ($c.Instance -split '\\')[-1]
            $list.Add((New-Series $Cap 10 'SMB' "$tag $share write" 'MB/s' $w 'workload'))
            if ($r -and (Get-Max $r) -ge 5) { $list.Add((New-Series $Cap 11 'SMB' "$tag $share read" 'MB/s' $r 'workload')) }
            foreach ($pair in @(@('Avg. sec/Write','write latency','ms',1000), @('Current Data Queue Length','queue','count',1))) {
                $x = @(Find-Columns $Cap $obj $pair[0] ('^' + [regex]::Escape($c.Instance) + '$'))
                if ($x.Count) { $list.Add((New-Series $Cap 12 'SMB' "$tag $share $($pair[1])" $pair[2] (Get-Column $Cap $x[0] $pair[3]) 'detail')) }
            }
        }
    }

    # Network: active adapters, TCP retransmits
    foreach ($c in (Find-Columns $Cap 'Network Interface' 'Bytes Received/sec' '.' '(?i)isatap|loopback|teredo')) {
        $rx = Get-Column $Cap $c $MB
        $tc = @(Find-Columns $Cap 'Network Interface' 'Bytes Sent/sec' ('^' + [regex]::Escape($c.Instance) + '$'))
        $tx = $(if ($tc.Count) { Get-Column $Cap $tc[0] $MB } else { $null })
        if ((Get-Max $rx) -ge 5) { $list.Add((New-Series $Cap 20 'Network' "NIC $($c.Instance) rx" 'MB/s' $rx 'throughput')) }
        if ($tx -and (Get-Max $tx) -ge 5) { $list.Add((New-Series $Cap 21 'Network' "NIC $($c.Instance) tx" 'MB/s' $tx 'throughput')) }
    }
    foreach ($c in (Find-Columns $Cap 'TCPv4' 'Segments Retransmitted/sec')) { $list.Add((New-Series $Cap 22 'Network' 'TCPv4 retransmits' '/s' (Get-Column $Cap $c) 'rate')) }

    # Network traffic the SMB counters do not account for. Avid NEXIS moves
    # file data over UDP, so a NEXIS copy shows only here. Mac/Linux captures
    # carry it as \Network Unattributed(_Total); on Windows it is the physical
    # adapters minus every SMB client and server byte.
    $rxU = $null; $txU = $null; $n = $Cap.Rows.Count
    $ua = @(Find-Columns $Cap 'Network Unattributed' 'Bytes Received/sec')
    if ($ua.Count) {
        $rxU = Get-Column $Cap $ua[0] $MB
        $ut = @(Find-Columns $Cap 'Network Unattributed' 'Bytes Sent/sec'); if ($ut.Count) { $txU = Get-Column $Cap $ut[0] $MB }
    } else {
        $phys = @(Find-Columns $Cap 'Network Interface' 'Bytes Received/sec' '.' '(?i)isatap|loopback|teredo|hyper-v|vethernet|virtual|pseudo|tunnel|vpn|wan miniport|bluetooth|multiplexor')
        if ($phys.Count) {
            $rxU = New-Object double[] $n; $txU = New-Object double[] $n
            foreach ($c in $phys) {
                $a = Get-Column $Cap $c $MB
                $tc = @(Find-Columns $Cap 'Network Interface' 'Bytes Sent/sec' ('^' + [regex]::Escape($c.Instance) + '$'))
                $b = $(if ($tc.Count) { Get-Column $Cap $tc[0] $MB } else { $null })
                for ($i = 0; $i -lt $n; $i++) {
                    if (-not [double]::IsNaN($a[$i])) { $rxU[$i] += $a[$i] }
                    if ($b -and -not [double]::IsNaN($b[$i])) { $txU[$i] += $b[$i] }
                }
            }
            foreach ($spec in @(@('SMB Client Shares','Read Bytes/sec','rx'), @('SMB Client Shares','Write Bytes/sec','tx'), @('SMB Server Shares','Write Bytes/sec','rx'), @('SMB Server Shares','Read Bytes/sec','tx'))) {
                $cc = @(Find-Columns $Cap $spec[0] $spec[1] '^_Total$')
                if (-not $cc.Count) { continue }
                $v = Get-Column $Cap $cc[0] $MB
                for ($i = 0; $i -lt $n; $i++) { if (-not [double]::IsNaN($v[$i])) { if ($spec[2] -eq 'rx') { $rxU[$i] -= $v[$i] } else { $txU[$i] -= $v[$i] } } }
            }
            for ($i = 0; $i -lt $n; $i++) { if ($rxU[$i] -lt 0) { $rxU[$i] = 0 }; if ($txU[$i] -lt 0) { $txU[$i] = 0 } }
        }
    }
    $other = $(if ($Cap.Nexis) { 'Avid NEXIS' } else { 'non-SMB network' })
    if ($rxU -and (Get-Max $rxU) -ge 20) { $list.Add((New-Series $Cap 13 'Network' "$other read" 'MB/s' $rxU 'workload')) }
    if ($txU -and (Get-Max $txU) -ge 20) { $list.Add((New-Series $Cap 13 'Network' "$other write" 'MB/s' $txU 'workload')) }

    # UDP receive errors and failed IP reassembly: how UDP storage traffic
    # (NEXIS) loses data. Windows counts them cumulatively, Mac/Linux per second.
    foreach ($spec in @(@('UDPv4','Datagrams Received Errors','UDP receive errors'), @('UDPv4','Receive Buffer Errors/sec','UDP receive buffer drops'), @('IPv4','Fragment Re-assembly Failures','IP reassembly failures'))) {
        foreach ($cn in @($spec[1], "$($spec[1])/sec")) {
            $cc = @(Find-Columns $Cap $spec[0] $cn)
            if (-not $cc.Count) { continue }
            $v = Get-Column $Cap $cc[0]
            if ($cn -notlike '*/sec') {
                $r = New-Object double[] $n; $r[0] = $NaN
                for ($i = 1; $i -lt $n; $i++) { $r[$i] = $(if ([double]::IsNaN($v[$i]) -or [double]::IsNaN($v[$i - 1]) -or $v[$i] -lt $v[$i - 1]) { $NaN } else { $v[$i] - $v[$i - 1] }) }
                $v = $r
            }
            $list.Add((New-Series $Cap 23 'Network' $spec[2] '/s' $v 'rate'))
            break
        }
    }

    # Cache manager and memory
    $pageGB = 4096.0 / 1GB
    foreach ($pair in @(@('Cache','Dirty Pages','cache dirty data','GB',$pageGB), @('Cache','Dirty Page Threshold','cache dirty threshold','GB',$pageGB),
                        @('Cache','Lazy Write Pages/sec','lazy write pages','/s',1), @('Memory','Modified Page List Bytes','modified page list','GB',(1.0/1GB)),
                        @('Memory','Available MBytes','available memory','GB',(1.0/1024)))) {
        $c = @(Find-Columns $Cap $pair[0] $pair[1])
        if ($c.Count) { $list.Add((New-Series $Cap 30 'Cache' $pair[2] $pair[3] (Get-Column $Cap $c[0] $pair[4]) 'level')) }
    }

    # Physical disks (active ones)
    foreach ($c in (Find-Columns $Cap 'PhysicalDisk' 'Disk Write Bytes/sec' '.' '^_Total$')) {
        $w = Get-Column $Cap $c $MB
        $rc = @(Find-Columns $Cap 'PhysicalDisk' 'Disk Read Bytes/sec' ('^' + [regex]::Escape($c.Instance) + '$'))
        $r = $(if ($rc.Count) { Get-Column $Cap $rc[0] $MB } else { $null })
        if ((Get-Max $w) -lt 5 -and (-not $r -or (Get-Max $r) -lt 5)) { continue }
        $list.Add((New-Series $Cap 40 'Disk' "disk $($c.Instance) write" 'MB/s' $w 'throughput'))
        if ($r -and (Get-Max $r) -ge 5) { $list.Add((New-Series $Cap 41 'Disk' "disk $($c.Instance) read" 'MB/s' $r 'throughput')) }
        foreach ($pair in @(@('Avg. Disk sec/Write','write latency','ms',1000), @('Current Disk Queue Length','queue','count',1))) {
            $x = @(Find-Columns $Cap 'PhysicalDisk' $pair[0] ('^' + [regex]::Escape($c.Instance) + '$'))
            if ($x.Count) { $list.Add((New-Series $Cap 42 'Disk' "disk $($c.Instance) $($pair[1])" $pair[2] (Get-Column $Cap $x[0] $pair[3]) 'detail')) }
        }
    }

    # Hyper-V virtual disks (host side)
    foreach ($c in (Find-Columns $Cap 'Hyper-V Virtual Storage Device' 'Write Bytes/sec' '.' '(?i)\.vmgs$|^ISO$|^_Total$')) {
        $w = Get-Column $Cap $c $MB
        if ((Get-Max $w) -lt 5) { continue }
        # Instance names flatten the path with '-' (C:-ClusterStorage-...-Virtual Hard Disks-Name.vhdx).
        $name = $c.Instance -replace '^.*Virtual Hard Disks-', ''
        if ($name -eq $c.Instance) { $name = ($c.Instance -split '-')[-1] }
        $list.Add((New-Series $Cap 50 'VHDX' "VHDX $name write" 'MB/s' $w 'throughput'))
        foreach ($pair in @(@('Latency','latency','ms',1), @('Queue Length','queue','count',1))) {
            $x = @(Find-Columns $Cap 'Hyper-V Virtual Storage Device' $pair[0] ('^' + [regex]::Escape($c.Instance) + '$'))
            if ($x.Count) { $list.Add((New-Series $Cap 51 'VHDX' "VHDX $name $($pair[1])" $pair[2] (Get-Column $Cap $x[0] $pair[3]) 'detail')) }
        }
    }

    # Cluster Shared Volumes
    foreach ($c in (Find-Columns $Cap 'Cluster CSV File System' 'Redirected Write Bytes/sec' '.' '^_Total$')) {
        $list.Add((New-Series $Cap 60 'CSV' "CSV $($c.Instance) redirected writes" 'MB/s' (Get-Column $Cap $c $MB) 'redirect'))
    }
    foreach ($c in (Find-Columns $Cap 'Cluster CSV File System' 'Write Latency' '.' '^_Total$')) {
        $list.Add((New-Series $Cap 61 'CSV' "CSV $($c.Instance) write latency" 'raw' (Get-Column $Cap $c) 'detail'))
    }

    # CPU: total plus the busiest core per sample (one hot core can cap a 10G+ flow)
    $tot = @(Find-Columns $Cap 'Processor Information' '% Processor Time' '^_Total$')
    if ($tot.Count) { $list.Add((New-Series $Cap 70 'CPU' 'CPU total' '%' (Get-Column $Cap $tot[0]) 'level')) }
    foreach ($pair in @(@('% Processor Time','busiest core'), @('% DPC Time','busiest core DPC'))) {
        $cores = @(Find-Columns $Cap 'Processor Information' $pair[0] '^\d+,\d+$')
        if ($cores.Count) {
            $mx = New-Object double[] $Cap.Rows.Count
            for ($i = 0; $i -lt $mx.Count; $i++) { $mx[$i] = $NaN }
            foreach ($c in $cores) {
                $v = Get-Column $Cap $c
                for ($i = 0; $i -lt $mx.Count; $i++) { if (-not [double]::IsNaN($v[$i]) -and ([double]::IsNaN($mx[$i]) -or $v[$i] -gt $mx[$i])) { $mx[$i] = $v[$i] } }
            }
            $list.Add((New-Series $Cap 71 'CPU' $pair[1] '%' $mx 'level'))
        }
    }
    return $list.ToArray()
}

# ---------------------------------------------------------------------------
# Events: Storage-Events-*.csv (v3.9+), PreCapture-State.txt (v3.8), path health (v3.10+)
# ---------------------------------------------------------------------------
function Import-CaptureEvents {
    param($Cap)
    $events = @{}
    foreach ($f in @(Get-ChildItem $Cap.Path -Filter 'Storage-Events-*.csv' -ErrorAction SilentlyContinue)) {
        foreach ($e in (Import-Csv $f.FullName)) {
            $t = [datetime]::MinValue
            if ([datetime]::TryParse($e.TimeCreated, $inv, [System.Globalization.DateTimeStyles]::None, [ref]$t)) {
                $key = "$($t.Ticks)|$($e.Provider)|$($e.Id)"
                if (-not $events.ContainsKey($key)) { $events[$key] = [pscustomobject]@{ Time = $t; Provider = $e.Provider; Id = [int]$e.Id; Level = $e.Level; Message = $e.Message } }
            }
        }
    }
    if ($events.Count -eq 0) {
        foreach ($f in @('PreCapture-State.txt','PostCapture-State.txt')) {
            $p = Join-Path $Cap.Path $f
            if (!(Test-Path $p)) { continue }
            $txt = Get-Content $p -Raw
            $i = $txt.IndexOf('===== RECENT STORAGE SYSTEM EVENTS =====')
            if ($i -lt 0) { continue }
            $sec = $txt.Substring($i)
            $j = $sec.IndexOf("`n=====", 10); if ($j -gt 0) { $sec = $sec.Substring(0, $j) }
            foreach ($m in [regex]::Matches($sec, 'TimeCreated\s*:\s*(?<t>[^\r\n]+)\s+Id\s*:\s*(?<id>\d+)\s+ProviderName\s*:\s*(?<p>\S+)\s+LevelDisplayName\s*:\s*(?<l>\S+)\s+Message\s*:\s*(?<m>[^\r\n]*)')) {
                $t = [datetime]::MinValue
                if ([datetime]::TryParse($m.Groups['t'].Value.Trim(), [System.Globalization.CultureInfo]'en-US', [System.Globalization.DateTimeStyles]::None, [ref]$t)) {
                    $key = "$($t.Ticks)|$($m.Groups['p'].Value)|$($m.Groups['id'].Value)"
                    if (-not $events.ContainsKey($key)) { $events[$key] = [pscustomobject]@{ Time = $t; Provider = $m.Groups['p'].Value; Id = [int]$m.Groups['id'].Value; Level = $m.Groups['l'].Value; Message = $m.Groups['m'].Value } }
                }
            }
        }
    }
    $Cap.Events = @($events.Values | Sort-Object Time)
    $pc = Join-Path $Cap.Path 'Path-Health-Changes.csv'
    if (Test-Path $pc) {
        $Cap.PathChanges = @(Import-Csv $pc | Where-Object { $_.Before -ne '(baseline)' } | ForEach-Object {
            $t = [datetime]::MinValue
            [void][datetime]::TryParse($_.Time, $inv, [System.Globalization.DateTimeStyles]::None, [ref]$t)
            [pscustomobject]@{ Time = $t; Category = $_.Category; Key = $_.Key; Before = $_.Before; After = $_.After }
        })
    }
}

# Events worth lining up against a stall. iScsiPrt 5 (failed to set up an
# initiator portal) repeats every few seconds when present; it is summarized
# but not listed per stall.
function Test-NotableEvent($e) {
    if ($e.Provider -match '(?i)iScsiPrt' -and $e.Id -ne 5) { return $true }
    if ($e.Provider -match '(?i)mpio|msdsm|storport|^disk$|FailoverClustering|Hyper-V-Storage') { return $true }
    if ($e.Provider -match '(?i)^(icea|i40ea|bnxt|mlx|e1)' ) { return $true }
    return $false
}

# ---------------------------------------------------------------------------
# Clock alignment between captures
# ---------------------------------------------------------------------------
function Get-Pearson([double[]]$x, [double[]]$y) {
    $n = 0; $sx = 0.0; $sy = 0.0; $sxx = 0.0; $syy = 0.0; $sxy = 0.0
    for ($i = 0; $i -lt $x.Count; $i++) {
        if ([double]::IsNaN($x[$i]) -or [double]::IsNaN($y[$i])) { continue }
        $n++; $sx += $x[$i]; $sy += $y[$i]; $sxx += $x[$i] * $x[$i]; $syy += $y[$i] * $y[$i]; $sxy += $x[$i] * $y[$i]
    }
    if ($n -lt 30) { return [pscustomobject]@{ R = $NaN; N = $n } }
    $num = $n * $sxy - $sx * $sy
    $den = [math]::Sqrt(($n * $sxx - $sx * $sx) * ($n * $syy - $sy * $sy))
    if ($den -eq 0) { return [pscustomobject]@{ R = $NaN; N = $n } }
    [pscustomobject]@{ R = $num / $den; N = $n }
}

function Get-ValueAt($Cap, [double[]]$Values, [datetime]$RefTime) {
    # Value of a series at a reference-clock time, applying the capture's offset.
    $t = $RefTime.AddSeconds(-$Cap.OffsetSeconds)
    if ($Cap.Index.ContainsKey($t.Ticks)) { return $Values[$Cap.Index[$t.Ticks]] }
    return $NaN
}

function Set-CaptureOffset {
    param($Ref, $Other)
    $refDisks = @($Ref.Series | Where-Object { $_.Group -eq 'Disk' -and $_.Label -like '* write' })
    $vhdx = @($Other.Series | Where-Object { $_.Group -eq 'VHDX' -and $_.Label -like '* write' })
    $pairs = @(@($refDisks | ForEach-Object { $a = $_; $vhdx | ForEach-Object { ,@($a, $_) } }))
    if ($pairs.Count -eq 0) {
        # Reverse: the other capture is the guest.
        $refV = @($Ref.Series | Where-Object { $_.Group -eq 'VHDX' -and $_.Label -like '* write' })
        $otherD = @($Other.Series | Where-Object { $_.Group -eq 'Disk' -and $_.Label -like '* write' })
        $pairs = @(@($refV | ForEach-Object { $a = $_; $otherD | ForEach-Object { ,@($a, $_) } }))
    }
    $best = $null
    foreach ($p in $pairs) {
        for ($lag = -30; $lag -le 30; $lag++) {
            $x = New-Object double[] $Ref.Times.Count
            $y = New-Object double[] $Ref.Times.Count
            for ($i = 0; $i -lt $Ref.Times.Count; $i++) {
                $x[$i] = $p[0].Values[$i]
                $t = $Ref.Times[$i].AddSeconds(-$lag)
                if ($Other.Index.ContainsKey($t.Ticks)) { $y[$i] = $p[1].Values[$Other.Index[$t.Ticks]] } else { $y[$i] = $NaN }
            }
            $r = Get-Pearson $x $y
            if (-not [double]::IsNaN($r.R) -and (-not $best -or $r.R -gt $best.R)) { $best = [pscustomobject]@{ R = $r.R; N = $r.N; Lag = $lag; A = $p[0].Label; B = $p[1].Label } }
        }
    }
    if ($best -and $best.R -ge 0.6) {
        $Other.OffsetSeconds = $best.Lag
        $Other.OffsetNote = ("offset {0:+0;-0;0} s from matching '{1}' ({2}) with '{3}' ({4}), r = {5:N2} over {6} s" -f $best.Lag, $best.A, $Ref.Host, $best.B, $Other.Host, $best.R, $best.N)
    } elseif ($best) {
        $Other.OffsetNote = ("clocks assumed equal: best disk/VHDX match '{0}' vs '{1}' only r = {2:N2}" -f $best.A, $best.B, $best.R)
    } else {
        $Other.OffsetNote = 'clocks assumed equal: no guest disk / host VHDX pair to match'
    }
}

# ---------------------------------------------------------------------------
# Stall detection
# ---------------------------------------------------------------------------
function Find-Stalls {
    param($Cap, $Workload, $AllSeries)
    $v = $Workload.Values
    $p95 = Get-Pct $v 0.95
    if ([double]::IsNaN($p95) -or $p95 -le 0) { return @() }
    $active = [math]::Max($MinActiveMBps, 0.25 * $p95)
    $idx = @(for ($i = 0; $i -lt $v.Count; $i++) { if ($v[$i] -ge $active) { $i } })
    if ($idx.Count -lt 10) { return @() }
    $first = $idx[0]; $last = $idx[-1]
    $median = Get-Pct ([double[]]@($idx | ForEach-Object { $v[$_] })) 0.5
    if ($median -lt $MinActiveMBps) {
        $Workload | Add-Member -NotePropertyName Skipped -NotePropertyValue ("typical rate {0:N0} MB/s is below the {1} MB/s analysis threshold (-MinActiveMBps)" -f $median, $MinActiveMBps) -Force
        return @()
    }
    if ($idx.Count -lt 20) {
        $Workload | Add-Member -NotePropertyName Skipped -NotePropertyValue ("only {0} s of activity; at least 20 s are needed" -f $idx.Count) -Force
        return @()
    }
    $low = 0.1 * $median
    $prefix = $Workload.Label -replace ' (write|read)$', ''
    $queue = @($AllSeries | Where-Object { $_.Capture -eq $Cap -and $_.Label -eq "$prefix queue" }) | Select-Object -First 1
    $lat = @($AllSeries | Where-Object { $_.Capture -eq $Cap -and $_.Label -eq "$prefix write latency" }) | Select-Object -First 1

    $stalls = @()
    $i = $first
    while ($i -le $last) {
        if (-not [double]::IsNaN($v[$i]) -and $v[$i] -lt $low) {
            $j = $i
            while ($j + 1 -le $last -and -not [double]::IsNaN($v[$j + 1]) -and $v[$j + 1] -lt $low) { $j++ }
            $len = $j - $i + 1
            if ($len -ge $MinStallSeconds) {
                $qDuring = $(if ($queue) { Get-Mean (Get-Slice $queue.Values $i $j) } else { $NaN })
                $latRecovery = $(if ($lat) { Get-Max (Get-Slice $lat.Values ($j + 1) ($j + 1)) } else { $NaN })
                $latMax = $(if ($lat) { Get-Max (Get-Slice $lat.Values $i ($j + 1)) } else { $NaN })
                $kind = 'Pause (no outstanding requests)'
                if (-not [double]::IsNaN($qDuring) -and $qDuring -ge 0.5) { $kind = 'Stall (requests outstanding)' }
                elseif (-not [double]::IsNaN($latMax) -and $latMax -ge 500) { $kind = 'Stall (slow completion)' }
                elseif ([double]::IsNaN($qDuring)) { $kind = 'Drop (queue not recorded)' }
                # Over two minutes with nothing outstanding (or no queue data) is
                # a break between transfers, not a stall; real hangs keep requests
                # outstanding and are still reported.
                if ($len -gt 120 -and $kind -notlike 'Stall*') { $i = $j + 1; continue }
                $preRate = Get-Mean (Get-Slice $v ($i - 5) ($i - 1))
                $stalls += [pscustomobject]@{
                    Workload = $Workload.Label; Host = $Cap.Host; Kind = $kind
                    StartIndex = $i; EndIndex = $j; Start = $Cap.Times[$i]; End = $Cap.Times[$j]; Seconds = $len
                    PreRate = $preRate; QueueDuring = $qDuring; MaxLatencyMs = $latMax
                    Layers = @(); ChangedFirst = @(); Observations = @(); Events = @(); PathChanges = @()
                }
            }
            $i = $j + 1
        } else { $i++ }
    }
    # Sustained rate over the active span, for the summary.
    $Workload | Add-Member -NotePropertyName ActiveSpan -NotePropertyValue ([pscustomobject]@{
        Start = $Cap.Times[$first]; End = $Cap.Times[$last]; Seconds = $last - $first + 1
        AvgRate = Get-Mean (Get-Slice $v $first $last); MedianActiveRate = $median
    }) -Force
    return $stalls
}

function Get-LayerRows {
    param($Stall, $Series)
    $rows = @()
    foreach ($s in ($Series | Sort-Object Order, Label)) {
        $pre = @(); $during = @(); $rec = $NaN
        for ($k = -5; $k -le -1; $k++) { $pre += Get-ValueAt $s.Capture $s.Values $Stall.Start.AddSeconds($k) }
        for ($k = 0; $k -le $Stall.Seconds - 1; $k++) { $during += Get-ValueAt $s.Capture $s.Values $Stall.Start.AddSeconds($k) }
        $rec = Get-ValueAt $s.Capture $s.Values $Stall.End.AddSeconds(1)
        $preM = Get-Mean ([double[]]$pre); $durM = Get-Mean ([double[]]$during); $durX = Get-Max ([double[]]$during)
        if ([double]::IsNaN($preM) -and [double]::IsNaN($durM)) { continue }
        # Leave out layers that are idle around this stall.
        $top = Get-Max ([double[]]@($preM, $durX, $rec) | ForEach-Object { [math]::Abs($_) })
        if ($s.Kind -in @('throughput','workload') -and $top -lt 1) { continue }
        if ($s.Kind -in @('detail','rate','redirect') -and $top -lt 0.05) { continue }
        $rows += [pscustomobject]@{ Host = $s.Host; Group = $s.Group; Label = $s.Label; Unit = $s.Unit; Before = $preM; During = $durM; Peak = $durX; Recovery = $rec; Series = $s }
    }
    return $rows
}

function Get-ChangedFirst {
    # For each series, the first second in [-10 s, +2 s] around the stall start
    # where it moved clearly away from its level 6-20 s earlier. Heuristic.
    param($Stall, $Series)
    $out = @()
    foreach ($s in $Series) {
        $base = @(); for ($k = -20; $k -le -6; $k++) { $base += Get-ValueAt $s.Capture $s.Values $Stall.Start.AddSeconds($k) }
        $b = Get-Pct ([double[]]$base) 0.5
        if ([double]::IsNaN($b)) { continue }
        $dev = @($base | Where-Object { -not [double]::IsNaN($_) } | ForEach-Object { [math]::Abs($_ - $b) })
        $mad = $(if ($dev.Count) { Get-Pct ([double[]]$dev) 0.5 } else { 0 })
        $floor = $(switch ($s.Unit) { 'MB/s' { 50 } 'ms' { 5 } 'count' { 1 } 'GB' { 0.25 } '%' { 25 } default { 50 } })
        $thr = [math]::Max([math]::Max(0.5 * [math]::Abs($b), 4 * $mad), $floor)
        for ($k = -10; $k -le 2; $k++) {
            $x = Get-ValueAt $s.Capture $s.Values $Stall.Start.AddSeconds($k)
            if (-not [double]::IsNaN($x) -and [math]::Abs($x - $b) -gt $thr) {
                $out += [pscustomobject]@{ Offset = $k; Host = $s.Host; Label = $s.Label; Direction = $(if ($x -gt $b) { 'rose' } else { 'fell' }); From = $b; To = $x; Unit = $s.Unit }
                break
            }
        }
    }
    return @($out | Sort-Object Offset, Label | Select-Object -First 12)
}

function Get-Observations {
    # Explicit pattern checks. Each says what it saw and what it would mean.
    param($Stall, $Rows)
    $obs = @()
    $prefix = $Stall.Workload -replace ' (write|read)$', ''
    $disk = @($Rows | Where-Object { $_.Group -in @('Disk') -and $_.Label -like '* write' -and $_.Host -eq $Stall.Host })
    $diskName = 'local disks'
    $share = ($Stall.Workload -replace '^SMB (server|client) ', '') -replace ' (write|read)$', ''
    $own = @($caps | Where-Object { $_.Host -eq $Stall.Host }) | Select-Object -First 1
    if ($own -and $own.ShareDisk.ContainsKey($share)) {
        $dn = $own.ShareDisk[$share]
        $match = @($disk | Where-Object { $_.Label -match "^disk $dn( |$)" })
        if ($match.Count) { $disk = $match; $diskName = "disk $dn (behind $share)" }
    } elseif ($disk.Count -gt 1) { $diskName = 'all active disks (share-to-disk map not available before v3.10)' }
    $diskDuring = ($disk | Measure-Object -Property During -Sum).Sum
    if ($Stall.Kind -notlike 'Pause*' -and $Stall.Workload -like '* write' -and $Stall.PreRate -gt 0 -and $diskDuring -ge 0.5 * $Stall.PreRate) {
        $o = ("Write-behind pattern: SMB writes stopped while {0} kept writing {1:N0} MB/s ({2:N0}% of the pre-stall SMB rate). The server was flushing cached data, not waiting on the disk." -f $diskName, $diskDuring, (100 * $diskDuring / $Stall.PreRate))
        $dirty = @($Rows | Where-Object { $_.Label -eq 'cache dirty data' -and $_.Host -eq $Stall.Host }) | Select-Object -First 1
        $thr = @($Rows | Where-Object { $_.Label -eq 'cache dirty threshold' -and $_.Host -eq $Stall.Host }) | Select-Object -First 1
        if ($dirty -and $thr -and $thr.Before -gt 0) {
            $ratio = [math]::Max($dirty.Before, $dirty.Peak) / $thr.Before
            if ($ratio -ge 0.9) { $o += (" Cache dirty data reached {0:N0}% of the dirty page threshold: CONFIRMS cache manager write throttling." -f (100 * $ratio)) }
            else { $o += (" But cache dirty data only reached {0:N0}% of the threshold, which does not support throttling; check the disk path." -f (100 * $ratio)) }
        } else {
            $o += ' Not confirmed: \Cache\Dirty Pages / Dirty Page Threshold were not recorded (captures before v3.9).'
        }
        $obs += $o
    }
    foreach ($r in @($Rows | Where-Object { $_.Unit -eq 'ms' -and $_.Label -match 'latency' -and $_.Label -notlike "$prefix*" })) {
        if ($r.Peak -ge 50 -and $r.Before -gt 0 -and $r.Peak -ge 5 * $r.Before) {
            $obs += ("Backend latency: {0} ({1}) rose from {2:N1} ms to {3:N1} ms during the stall." -f $r.Label, $r.Host, $r.Before, $r.Peak)
        }
    }
    $q = @($Rows | Where-Object { $_.Label -eq "$prefix queue" }) | Select-Object -First 1
    # Writes arrive on NIC receive, reads leave on NIC transmit.
    $dir = $(if ($Stall.Workload -like '* read') { 'tx' } else { 'rx' })
    # Avid NEXIS / non-SMB workloads are seen from the client: reads arrive on receive.
    if ($Stall.Workload -match '^(Avid NEXIS|non-SMB network) ') { $dir = $(if ($Stall.Workload -like '* read') { 'rx' } else { 'tx' }) }
    $nic = @($Rows | Where-Object { $_.Host -eq $Stall.Host -and $_.Label -like "NIC * $dir" })
    $nicDuring = ($nic | Measure-Object -Property During -Sum).Sum
    $verb = $(if ($dir -eq 'rx') { 'accepting data' } else { 'returning data' })
    if ($q -and $q.During -lt 0.5 -and $nic.Count -and $nicDuring -lt 5) {
        $obs += 'Client side: no SMB requests were outstanding and the network went quiet, so the client stopped asking. Look at the client or the copy tool, not the server.'
    } elseif ($q -and $q.During -ge 0.5 -and $nic.Count -and $nicDuring -lt 5) {
        $obs += ("Server backpressure: {0:N1} SMB requests outstanding on average while network {1} dropped to {2:N1} MB/s. The server stopped {3}." -f $q.During, $dir, $nicDuring, $verb)
    }
    # A copy between NEXIS and SMB: when one side stops, the other waits.
    $mine = $Stall.Workload
    foreach ($r in @($Rows | Where-Object { $_.Host -eq $Stall.Host -and $_.Series.Kind -eq 'workload' -and $_.Label -ne $mine -and $_.Before -ge 20 -and $_.During -lt 0.1 * $_.Before })) {
        if ($mine -match '^SMB ' -and $r.Label -match '^(Avid NEXIS|non-SMB network) read') {
            $obs += ("{0} dropped from {1:N0} to {2:N0} MB/s at the same time: the copy was waiting for its source, not for the SMB server. See which fell first in the changed-first list." -f $r.Label, $r.Before, $r.During)
        } elseif ($mine -match '^(Avid NEXIS|non-SMB network) ' -and $r.Label -match '^SMB ') {
            $obs += ("{0} dropped from {1:N0} to {2:N0} MB/s at the same time (the other side of the same copy). The changed-first list shows which side stopped first." -f $r.Label, $r.Before, $r.During)
        }
    }
    foreach ($r in @($Rows | Where-Object { $_.Label -in @('UDP receive errors','UDP receive buffer drops','IP reassembly failures') })) {
        if ($r.Peak -gt 0 -and $r.During -gt $r.Before) { $obs += ("{0} on {1}: {2:N1}/s during the stall vs {3:N1}/s before. UDP storage traffic (Avid NEXIS) was losing datagrams at the client and has to resend them." -f $r.Label, $r.Host, $r.During, $r.Before) }
    }
    foreach ($r in @($Rows | Where-Object { $_.Label -like '*retransmits' })) {
        if ($r.Peak -ge 100 -and $r.Peak -ge 5 * [math]::Max($r.Before, 1)) { $obs += ("Retransmits on {0}: {1:N0}/s peak vs {2:N0}/s before." -f $r.Host, $r.Peak, $r.Before) }
    }
    foreach ($r in @($Rows | Where-Object { $_.Label -in @('busiest core DPC','busiest core') })) {
        # Only a core that became saturated at the stall; on large hosts some core is always busy.
        $lim = $(if ($r.Label -eq 'busiest core DPC') { 50 } else { 90 })
        if ($r.During -ge $lim -and $r.Before -lt 0.8 * $r.During) { $obs += ("CPU: {0} on {1} went from {2:N0}% to {3:N0}% during the stall. One saturated core can cap a high-speed flow." -f $r.Label, $r.Host, $r.Before, $r.During) }
    }
    foreach ($r in @($Rows | Where-Object { $_.Group -eq 'CSV' -and $_.Label -like '*redirected writes' })) {
        if ($r.Peak -gt 0) { $obs += ("CSV redirected I/O on {0}: {1} peaked at {2:N1} MB/s. I/O was going through another node." -f $r.Host, $r.Label, $r.Peak) }
    }
    if ($obs.Count -eq 0) { $obs += 'No pattern matched: read the layer table and the changed-first list.' }
    return $obs
}

# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
$caps = @()
foreach ($p in $CapturePath) {
    Write-Host "Loading $p" -ForegroundColor Cyan
    $c = Import-CinesysCapture -Path $p
    $c.Series = @(Get-KeySeries $c)
    Import-CaptureEvents $c
    $caps += $c
}

# Reference capture: the one with the SMB server workload, else the first.
$ref = @($caps | Where-Object { @($_.Series | Where-Object { $_.Kind -eq 'workload' -and $_.Label -like 'SMB server*' }).Count }) | Select-Object -First 1
if (-not $ref) { $ref = $caps[0] }
foreach ($c in $caps) { if ($c -ne $ref) { Set-CaptureOffset -Ref $ref -Other $c } }
$allSeries = @($caps | ForEach-Object { $_.Series })

$stalls = @()
foreach ($c in $caps) {
    foreach ($w in @($c.Series | Where-Object { $_.Kind -eq 'workload' })) { $stalls += Find-Stalls -Cap $c -Workload $w -AllSeries $allSeries }
}
foreach ($s in $stalls) {
    # Reference-clock times (stall times are on its own capture's clock).
    $own = @($caps | Where-Object { $_.Host -eq $s.Host }) | Select-Object -First 1
    if ($own -and $own.OffsetSeconds) { $s.Start = $s.Start.AddSeconds($own.OffsetSeconds); $s.End = $s.End.AddSeconds($own.OffsetSeconds) }
    $s.Layers = @(Get-LayerRows -Stall $s -Series $allSeries)
    $s.ChangedFirst = @(Get-ChangedFirst -Stall $s -Series $allSeries)
    $s.Observations = @(Get-Observations -Stall $s -Rows $s.Layers)
    $from = $s.Start.AddSeconds(-30); $to = $s.End.AddSeconds(30)
    foreach ($c in $caps) {
        $s.Events += @($c.Events | Where-Object { (Test-NotableEvent $_) -and $_.Time.AddSeconds($c.OffsetSeconds) -ge $from -and $_.Time.AddSeconds($c.OffsetSeconds) -le $to } | ForEach-Object { [pscustomobject]@{ Host = $c.Host; Time = $_.Time; Provider = $_.Provider; Id = $_.Id; Message = $_.Message } })
        $s.PathChanges += @($c.PathChanges | Where-Object { $_.Time.AddSeconds($c.OffsetSeconds) -ge $from -and $_.Time.AddSeconds($c.OffsetSeconds) -le $to } | ForEach-Object { [pscustomobject]@{ Host = $c.Host; Time = $_.Time; Category = $_.Category; Key = $_.Key; Before = $_.Before; After = $_.After } })
    }
}
$stalls = @($stalls | Sort-Object Start)

# ---------------------------------------------------------------------------
# Report
# ---------------------------------------------------------------------------
if (-not $OutputPath) { $OutputPath = $caps[0].Path }
New-Item -ItemType Directory -Force -Path $OutputPath | Out-Null
$t = New-Object System.Collections.Generic.List[string]
$t.Add("CINESYS ANALYSIS - $(@($caps | ForEach-Object { $_.Host }) -join ' + ') - generated $((Get-Date).ToString('yyyy-MM-dd HH:mm'))")
$t.Add('Observations below are pattern checks to verify, not root-cause verdicts.')
$t.Add('')
$t.Add('CAPTURES')
foreach ($c in $caps) {
    $t.Add(("  {0,-18} PerfMon {1:HH:mm:ss} - {2:HH:mm:ss} ({3} samples)   {4}" -f $c.Host, $c.Times[0], $c.Times[-1], $c.Times.Count, $c.OffsetNote))
    $t.Add("      $($c.Path)")
    if ($c.Manifest) { foreach ($w in @($c.Manifest.Warnings)) { $t.Add("      manifest warning: $w") } }
}
$t.Add('')
$t.Add('WORKLOADS')
foreach ($w in @($allSeries | Where-Object { $_.Kind -eq 'workload' -and $_.PSObject.Properties['ActiveSpan'] })) {
    $a = $w.ActiveSpan
    $n = @($stalls | Where-Object { $_.Workload -eq $w.Label -and $_.Host -eq $w.Host })
    $st = @($n | Where-Object { $_.Kind -like 'Stall*' -or $_.Kind -like 'Drop*' })
    $t.Add(("  {0} ({1}): active {2:HH:mm:ss}-{3:HH:mm:ss}, average {4:N0} MB/s, typical {5:N0} MB/s when moving; {6} stall(s) totalling {7} s, {8} pause(s)" -f $w.Label, $w.Host, $a.Start, $a.End, $a.AvgRate, $a.MedianActiveRate, $st.Count, (($st | Measure-Object -Property Seconds -Sum).Sum), ($n.Count - $st.Count)))
}
foreach ($w in @($allSeries | Where-Object { $_.Kind -eq 'workload' -and $_.PSObject.Properties['Skipped'] })) { $t.Add("  $($w.Label) ($($w.Host)): not analyzed, $($w.Skipped)") }
$t.Add('')
if ($stalls.Count) {
    $t.Add('PATTERNS ACROSS ALL STALLS')
    $patterns = @{}
    $real = @($stalls | Where-Object { $_.Kind -notlike 'Pause*' })
    foreach ($s in $real) { foreach ($o in $s.Observations) { $k = ($o -split ':')[0]; if (-not $patterns.ContainsKey($k)) { $patterns[$k] = 0 }; $patterns[$k]++ } }
    foreach ($k in ($patterns.Keys | Sort-Object)) { $t.Add(("  {0,-24} {1} of {2} stalls" -f $k, $patterns[$k], $real.Count)) }
    $t.Add('')
}
$pauses = @($stalls | Where-Object { $_.Kind -like 'Pause*' })
if ($pauses.Count) {
    $t.Add('PAUSES (workload went idle with no requests outstanding; usually the client, not a fault)')
    foreach ($s in $pauses) { $t.Add(("  {0:HH:mm:ss}-{1:HH:mm:ss} ({2} s)  {3} on {4}" -f $s.Start, $s.End, $s.Seconds, $s.Workload, $s.Host)) }
    $t.Add('')
}
$n = 0
foreach ($s in @($stalls | Where-Object { $_.Kind -notlike 'Pause*' })) {
    $n++
    $t.Add(('=' * 100))
    $t.Add(("STALL {0}: {1:HH:mm:ss}-{2:HH:mm:ss} ({3} s)  {4} on {5}  [{6}]" -f $n, $s.Start, $s.End, $s.Seconds, $s.Workload, $s.Host, $s.Kind))
    $t.Add(("  before {0:N0} MB/s; queue during {1}; max write latency {2} ms" -f $s.PreRate, (Format-Num $s.QueueDuring 'count'), (Format-Num $s.MaxLatencyMs 'ms')))
    $t.Add('')
    $t.Add(("  {0,-16} {1,-64} {2,6} {3,10} {4,10} {5,10} {6,10}" -f 'host', 'layer', 'unit', 'before', 'during', 'peak', 'recovery'))
    foreach ($r in $s.Layers) {
        $t.Add(("  {0,-16} {1,-64} {2,6} {3,10} {4,10} {5,10} {6,10}" -f $r.Host, $(if ($r.Label.Length -gt 64) { $r.Label.Substring(0,61) + '...' } else { $r.Label }), $r.Unit, (Format-Num $r.Before $r.Unit), (Format-Num $r.During $r.Unit), (Format-Num $r.Peak $r.Unit), (Format-Num $r.Recovery $r.Unit)))
    }
    $t.Add('')
    $t.Add('  Changed first (seconds relative to stall start):')
    if ($s.ChangedFirst.Count -eq 0) { $t.Add('    nothing moved clearly before the stall') }
    foreach ($c in $s.ChangedFirst) { $t.Add(("    {0,3:+0;-0;0} s  {1} {2} {3} ({4} -> {5} {6})" -f $c.Offset, $c.Host, $c.Label, $c.Direction, (Format-Num $c.From $c.Unit), (Format-Num $c.To $c.Unit), $c.Unit)) }
    $t.Add('')
    $t.Add('  Observations:')
    foreach ($o in $s.Observations) { $t.Add("    - $o") }
    if ($s.Events.Count -or $s.PathChanges.Count) {
        $t.Add('  Events within 30 s:')
        foreach ($e in $s.Events) { $t.Add(("    {0:HH:mm:ss} {1} {2} {3}: {4}" -f $e.Time, $e.Host, $e.Provider, $e.Id, $e.Message)) }
        foreach ($e in $s.PathChanges) { $t.Add(("    {0:HH:mm:ss} {1} {2} {3}: {4} -> {5}" -f $e.Time, $e.Host, $e.Category, $e.Key, $e.Before, $e.After)) }
    }
    $t.Add('')
}
$t.Add(('=' * 100))
$t.Add('NOTABLE EVENTS PER CAPTURE (from the event snapshots)')
foreach ($c in $caps) {
    $notable = @($c.Events | Where-Object { Test-NotableEvent $_ })
    $portal = @($c.Events | Where-Object { $_.Provider -match '(?i)iScsiPrt' -and $_.Id -eq 5 })
    $t.Add("  $($c.Host): $($notable.Count) notable event(s)$(if ($portal.Count) { "; iScsiPrt 5 (failed to set up initiator portal) x$($portal.Count)" })")
    foreach ($g in ($notable | Group-Object Provider, Id | Sort-Object Count -Descending)) {
        $first = ($g.Group | Sort-Object Time)[0]; $last = ($g.Group | Sort-Object Time)[-1]
        $t.Add(("    {0,5} x {1} {2}  {3:MM-dd HH:mm:ss} .. {4:MM-dd HH:mm:ss}  {5}" -f $g.Count, $first.Provider, $first.Id, $first.Time, $last.Time, $(if ($first.Message.Length -gt 80) { $first.Message.Substring(0,80) } else { $first.Message })))
    }
    $resets = @($c.Events | Where-Object { $_.Provider -match '(?i)iScsiPrt' -and $_.Id -eq 39 })
    if ($resets.Count) {
        $inside = @($resets | Where-Object { $_.Time -ge $c.Times[0] -and $_.Time -le $c.Times[-1] })
        $t.Add(("    LUN/target resets (iScsiPrt 39): {0} in the snapshot window, {1} inside the PerfMon data" -f $resets.Count, $inside.Count))
    }
}
$txtFile = Join-Path $OutputPath 'Findings.txt'
$t | Set-Content -Path $txtFile -Encoding UTF8

# Stalls.csv and Findings.json
$stalls | ForEach-Object {
    $r = $_
    [pscustomobject]@{
        Start = $r.Start.ToString('yyyy-MM-dd HH:mm:ss'); End = $r.End.ToString('yyyy-MM-dd HH:mm:ss'); Seconds = $r.Seconds
        Workload = $r.Workload; Host = $r.Host; Kind = $r.Kind; PreRateMBps = [math]::Round($r.PreRate, 1)
        QueueDuring = $(if ([double]::IsNaN($r.QueueDuring)) { $null } else { [math]::Round($r.QueueDuring, 2) })
        MaxLatencyMs = $(if ([double]::IsNaN($r.MaxLatencyMs)) { $null } else { [math]::Round($r.MaxLatencyMs, 1) })
        ChangedFirst = (@($r.ChangedFirst | Select-Object -First 3 | ForEach-Object { "$($_.Offset)s $($_.Label) $($_.Direction)" }) -join '; ')
        Observations = ($r.Observations -join ' | ')
        Events = $r.Events.Count; PathChanges = $r.PathChanges.Count
    }
} | Export-Csv -Path (Join-Path $OutputPath 'Stalls.csv') -NoTypeInformation -Encoding UTF8

$json = [ordered]@{
    Generated = (Get-Date).ToString('o')
    Captures = @($caps | ForEach-Object { [ordered]@{ Host = $_.Host; Path = $_.Path; First = $_.Times[0].ToString('o'); Last = $_.Times[-1].ToString('o'); Samples = $_.Times.Count; OffsetSeconds = $_.OffsetSeconds; OffsetNote = $_.OffsetNote } })
    Stalls = @($stalls | ForEach-Object {
        [ordered]@{
            Start = $_.Start.ToString('o'); End = $_.End.ToString('o'); Seconds = $_.Seconds; Workload = $_.Workload; Host = $_.Host; Kind = $_.Kind
            PreRateMBps = $_.PreRate; Observations = $_.Observations
            Layers = @($_.Layers | ForEach-Object { [ordered]@{ Host = $_.Host; Layer = $_.Label; Unit = $_.Unit; Before = $_.Before; During = $_.During; Peak = $_.Peak; Recovery = $_.Recovery } })
            ChangedFirst = @($_.ChangedFirst | ForEach-Object { [ordered]@{ Offset = $_.Offset; Host = $_.Host; Layer = $_.Label; Direction = $_.Direction; From = $_.From; To = $_.To } })
            Events = @($_.Events | ForEach-Object { [ordered]@{ Host = $_.Host; Time = $_.Time.ToString('o'); Provider = $_.Provider; Id = $_.Id } })
        }
    })
}
# NaN is not valid JSON.
($json | ConvertTo-Json -Depth 6) -replace '\bNaN\b', 'null' | Set-Content -Path (Join-Path $OutputPath 'Findings.json') -Encoding UTF8

Write-Host ("{0} stall(s)/pause(s) found. Report: {1}" -f $stalls.Count, $txtFile) -ForegroundColor Green
