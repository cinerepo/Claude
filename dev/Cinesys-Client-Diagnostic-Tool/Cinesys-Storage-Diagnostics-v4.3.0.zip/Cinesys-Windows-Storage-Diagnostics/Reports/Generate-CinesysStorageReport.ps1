﻿#requires -Version 5.1
[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)]
    [string]$CapturePath,

    [string]$Profile = "General",

    [string]$OutputPath
)

$ErrorActionPreference = "Stop"

function Html([string]$s) {
    if ($null -eq $s) { return "" }
    return [System.Net.WebUtility]::HtmlEncode($s)
}

function Parse-Number($value) {
    $n = 0.0
    if ([double]::TryParse([string]$value,
        [Globalization.NumberStyles]::Any,
        [Globalization.CultureInfo]::InvariantCulture,
        [ref]$n)) { return $n }
    return $null
}

function Format-Value([double]$value, [string]$unit) {
    switch ($unit) {
        "BytesPerSecond" {
            if ($value -ge 1GB) { return ("{0:N2} GB/s" -f ($value / 1GB)) }
            if ($value -ge 1MB) { return ("{0:N1} MB/s" -f ($value / 1MB)) }
            if ($value -ge 1KB) { return ("{0:N1} KB/s" -f ($value / 1KB)) }
            return ("{0:N0} B/s" -f $value)
        }
        "Bytes" {
            if ($value -ge 1MB) { return ("{0:N2} MiB" -f ($value / 1MB)) }
            if ($value -ge 1KB) { return ("{0:N1} KiB" -f ($value / 1KB)) }
            return ("{0:N0} B" -f $value)
        }
        "SecondsAsMilliseconds" { return ("{0:N2} ms" -f ($value * 1000)) }
        "Percent" { return ("{0:N1}%" -f $value) }
        "Megabytes" { return ("{0:N0} MB" -f $value) }
        "PerSecond" { return ("{0:N2}/s" -f $value) }
        default { return ("{0:N2}" -f $value) }
    }
}

function Get-Aggregate([double[]]$values, [string]$aggregate) {
    if ($null -eq $values -or $values.Count -eq 0) { return $null }
    switch ($aggregate) {
        "Sum" { return [double](($values | Measure-Object -Sum).Sum) }
        "Max" { return [double](($values | Measure-Object -Maximum).Maximum) }
        "Min" { return [double](($values | Measure-Object -Minimum).Minimum) }
        default { return [double](($values | Measure-Object -Average).Average) }
    }
}

function Get-MatchingColumns($headers, $node) {
    $matchedColumns = @()
    foreach ($h in $headers) {
        if ($h -eq $script:TimestampColumn) { continue }
        $ok = $false
        if ($node.MatchRegex) {
            $ok = $h -match [string]$node.MatchRegex
        } elseif ($node.Match) {
            $pattern = [regex]::Escape([string]$node.Match)
            $pattern = $pattern.Replace('\(\*\)', '\([^)]+\)')
            $ok = $h -match ($pattern + '$')
            # (*) means "every instance". Skip the _Total instance, otherwise Sum
            # aggregates count everything twice. Match (_Total) explicitly to chart it.
            if ($ok -and ([string]$node.Match).Contains('(*)') -and $h -match '\(_Total\)') { $ok = $false }
        }
        if ($ok) { $matchedColumns += [string]$h }
    }
    return @($matchedColumns)
}

function Get-Series($rows, $headers, $node) {
    $cols = @(Get-MatchingColumns $headers $node)
    if ($cols.Count -eq 0) { return @() }

    $series = @()
    foreach ($row in $rows) {
        $vals = @()
        foreach ($c in $cols) {
            $v = Parse-Number $row.$c
            if ($null -ne $v) { $vals += [double]$v }
        }
        if ($vals.Count -gt 0) {
            $agg = Get-Aggregate @($vals) ([string]$node.Aggregate)
            $series += [pscustomobject]@{
                Timestamp = [string]$row.$script:TimestampColumn
                Value = [double]$agg
            }
        }
    }
    return @($series)
}

function Get-Stats($series) {
    if ($series.Count -eq 0) { return $null }
    $v = @($series | ForEach-Object { $_.Value })
    $sorted = @($v | Sort-Object)
    $p95Index = [math]::Min($sorted.Count - 1, [math]::Max(0, [math]::Ceiling($sorted.Count * .95) - 1))
    return [pscustomobject]@{
        Min = [double](($v | Measure-Object -Minimum).Minimum)
        Avg = [double](($v | Measure-Object -Average).Average)
        Max = [double](($v | Measure-Object -Maximum).Maximum)
        P95 = [double]$sorted[$p95Index]
    }
}

function New-Sparkline($series, [string]$unit) {
    if ($series.Count -lt 2) { return "<div class='na'>Insufficient samples</div>" }
    $vals = @($series | ForEach-Object { $_.Value })
    $min = [double](($vals | Measure-Object -Minimum).Minimum)
    $max = [double](($vals | Measure-Object -Maximum).Maximum)
    $scaleMax = $max
    if ($scaleMax -eq $min) { $scaleMax = $min + 1 }
    $width = 900
    $height = 150
    $points = @()
    for ($i=0; $i -lt $vals.Count; $i++) {
        $x = [math]::Round(($i / [double]($vals.Count - 1)) * $width, 1)
        $y = [math]::Round($height - (($vals[$i] - $min) / ($scaleMax - $min)) * ($height - 12) - 6, 1)
        $points += "$x,$y"
    }
    $first = Html ([string]$series[0].Timestamp)
    $last = Html ([string]$series[-1].Timestamp)
    return "<svg viewBox='0 0 $width $height' preserveAspectRatio='none' class='chart'><polyline fill='none' stroke='currentColor' stroke-width='2' points='$($points -join " ")'/></svg><div class='axis'><span>$first</span><span>min $(Html (Format-Value $min $unit)) &nbsp; max $(Html (Format-Value $max $unit))</span><span>$last</span></div>"
}

function Test-Rule($series, $rule) {
    if ($series.Count -eq 0) { return $null }
    $threshold = [double]$rule.Threshold
    $need = 1
    if ($rule.DurationSamples) { $need = [int]$rule.DurationSamples }
    $run = 0
    $first = $null
    $peak = $null

    foreach ($p in $series) {
        $hit = $false
        switch ([string]$rule.Operator) {
            "GreaterThan" { $hit = $p.Value -gt $threshold }
            "GreaterThanOrEqual" { $hit = $p.Value -ge $threshold }
            "LessThan" { $hit = $p.Value -lt $threshold }
            "LessThanOrEqual" { $hit = $p.Value -le $threshold }
            "Equal" { $hit = $p.Value -eq $threshold }
            default { throw "Unsupported rule operator: $($rule.Operator)" }
        }

        if ($hit) {
            if ($run -eq 0) { $first = $p.Timestamp }
            $run++
            if ($null -eq $peak) { $peak = $p.Value }
            elseif ($rule.Operator -like "Less*") { if ($p.Value -lt $peak) { $peak = $p.Value } }
            else { if ($p.Value -gt $peak) { $peak = $p.Value } }

            if ($run -ge $need) {
                return [pscustomobject]@{
                    Name = [string]$rule.Name
                    Severity = [string]$rule.Severity
                    Message = [string]$rule.Message
                    FirstTimestamp = [string]$first
                    Value = [double]$peak
                    Unit = if ($rule.Unit) { [string]$rule.Unit } else { "" }
                }
            }
        } else {
            $run = 0
            $first = $null
            $peak = $null
        }
    }
    return $null
}

if (!(Test-Path $CapturePath)) { throw "Capture path not found: $CapturePath" }
$CapturePath = (Resolve-Path $CapturePath).Path

$blg = Join-Path $CapturePath "Cinesys-Performance.blg"
if (!(Test-Path $blg)) {
    $blg = Get-ChildItem $CapturePath -Filter "Cinesys-Performance*.blg" |
        Sort-Object LastWriteTime -Descending | Select-Object -First 1 -ExpandProperty FullName
}
if (!$blg -or !(Test-Path $blg)) { throw "No Cinesys unified BLG was found in $CapturePath" }

$profilePath = $Profile
if (!(Test-Path $profilePath)) {
    $profilePath = Join-Path $PSScriptRoot ("Profiles\" + $Profile + ".xml")
}
if (!(Test-Path $profilePath)) { throw "Report profile not found: $Profile" }

[xml]$config = Get-Content $profilePath -Raw
$profileName = [string]$config.CinesysReport.Name

if (!$OutputPath) {
    $OutputPath = Join-Path $CapturePath ("Cinesys-Report-" + $profileName + ".html")
}

$csv = Join-Path $env:TEMP ("Cinesys-" + [guid]::NewGuid().ToString("N") + ".csv")
try {
    & relog.exe $blg -f csv -o $csv -y | Out-Null
    if ($LASTEXITCODE -ne 0 -or !(Test-Path $csv)) { throw "relog.exe failed to convert $blg" }

    $rows = @(Import-Csv $csv)
    if ($rows.Count -eq 0) { throw "BLG conversion produced no samples." }
    $headers = @($rows[0].PSObject.Properties.Name)
    $script:TimestampColumn = $headers[0]

    $metadataPath = Join-Path $CapturePath "Capture-Metadata.txt"
    $metadata = if (Test-Path $metadataPath) { Get-Content $metadataPath -Raw } else { "" }
    $hostName = $env:COMPUTERNAME
    if ($metadata -match '(?m)^Host=(.+)$') { $hostName = $Matches[1].Trim() }

    $findings = @()
    foreach ($rule in @($config.CinesysReport.Rules.Rule)) {
        if ($null -eq $rule) { continue }
        $series = @(Get-Series $rows $headers $rule)
        $finding = Test-Rule $series $rule
        if ($finding) { $findings += $finding }
    }

    $sectionsHtml = @()
    foreach ($section in @($config.CinesysReport.Section | Sort-Object { [int]$_.Order })) {
        $charts = @()
        foreach ($chart in @($section.Chart)) {
            $series = @(Get-Series $rows $headers $chart)
            if ($series.Count -eq 0) { continue }
            $stats = Get-Stats $series
            $unit = [string]$chart.Unit
            $cards = "<div class='stats'><span>Avg <b>$(Html (Format-Value $stats.Avg $unit))</b></span><span>Peak <b>$(Html (Format-Value $stats.Max $unit))</b></span><span>P95 <b>$(Html (Format-Value $stats.P95 $unit))</b></span></div>"
            $charts += "<div class='metric'><h3>$(Html ([string]$chart.Name))</h3>$cards$(New-Sparkline $series $unit)</div>"
        }
        if ($charts.Count -gt 0) {
            $sectionsHtml += "<section><h2>$(Html ([string]$section.Name))</h2>$($charts -join "`n")</section>"
        }
    }

    if ($findings.Count -eq 0) {
        $findingsHtml = "<div class='finding ok'><b>No configured threshold was crossed.</b><br>Review the timelines and workload context; absence of a rule hit is not proof of a healthy storage path.</div>"
    } else {
        $parts = foreach ($f in $findings) {
            "<div class='finding'><div class='severity'>$(Html $f.Severity) - $(Html $f.Name)</div><div>$(Html $f.Message)</div><div class='when'>First sustained occurrence: $(Html $f.FirstTimestamp)</div></div>"
        }
        $findingsHtml = $parts -join "`n"
    }

    $configCopy = Join-Path $CapturePath ("Report-Profile-" + $profileName + ".xml")
    Copy-Item $profilePath $configCopy -Force

    $html = @"
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Cinesys Diagnostic Report - $(Html $hostName)</title>
<style>
body{font-family:Segoe UI,Arial,sans-serif;margin:0;background:#f4f6f8;color:#17202a}
header{background:#101820;color:#fff;padding:28px 40px}header h1{margin:0;font-size:27px}header p{margin:7px 0 0;opacity:.8}
main{max-width:1250px;margin:auto;padding:26px 40px 60px}
.summary,section,.finding{background:#fff;border:1px solid #dce2e7;border-radius:8px}
.summary{padding:18px 20px;margin-bottom:18px}.summary code{font-size:12px}
section{padding:18px 20px;margin:18px 0}h2{margin:0 0 14px;border-bottom:1px solid #e1e6ea;padding-bottom:9px}
.metric{margin:20px 0 30px}.metric h3{margin:0 0 8px;font-size:15px}
.stats{display:flex;gap:24px;font-size:12px;color:#5f6b74;margin-bottom:7px}
.chart{width:100%;height:150px;color:#1769aa;background:#fbfcfd;border:1px solid #e4e9ed}
.axis{display:flex;justify-content:space-between;font-size:10px;color:#687680;margin-top:4px}
.finding{padding:14px 16px;margin:9px 0}.finding .severity{font-weight:700;margin-bottom:5px}.finding .when{font-size:11px;color:#66737d;margin-top:6px}
.finding.ok{border-left:4px solid #6b7}.na{padding:15px;background:#fafafa;color:#777}
.note{font-size:12px;color:#65727c}
@media print{body{background:#fff}section,.finding,.summary{break-inside:avoid}}
</style>
</head>
<body>
<header>
<h1>Cinesys Diagnostic Report</h1>
<p>Host: $(Html $hostName) &nbsp; | &nbsp; Profile: $(Html $profileName) &nbsp; | &nbsp; Generated: $(Get-Date -Format "yyyy-MM-dd HH:mm:ss")</p>
</header>
<main>
<div class="summary">
<b>Capture</b><br><code>$(Html $CapturePath)</code>
<p class="note">The BLG remains the evidence source. This report profile only controls organization, aggregation, and threshold observations; it does not change what was captured.</p>
</div>
<section>
<h2>Configured observations</h2>
$findingsHtml
<p class="note">Observations are correlation prompts, not root-cause declarations.</p>
</section>
$($sectionsHtml -join "`n")
</main>
</body>
</html>
"@
    $html | Set-Content -Encoding UTF8 $OutputPath
    Write-Host "Report created: $OutputPath" -ForegroundColor Green
    Write-Host "Profile copied into capture: $configCopy"
}
finally {
    Remove-Item $csv -Force -ErrorAction SilentlyContinue
}
