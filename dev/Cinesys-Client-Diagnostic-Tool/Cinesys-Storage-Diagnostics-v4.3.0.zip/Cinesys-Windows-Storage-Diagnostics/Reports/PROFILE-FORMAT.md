# Report profile format

Report profiles are XML files under `Reports\Profiles`.

`Section` controls report grouping and display order.

`Chart` attributes:
- `Name`: report label.
- `Match`: PerfMon counter path. `(*)` matches any instance.
- `MatchRegex`: optional regular expression for dynamically discovered counters.
- `Aggregate`: `Sum`, `Average`, `Max`, or `Min` across matching instances for each sample.
- `Unit`: `BytesPerSecond`, `Bytes`, `SecondsAsMilliseconds`, `Percent`, `Megabytes`, `PerSecond`, or `Number`.

`Rule` uses the same counter matching and aggregation model. Supported operators:
`GreaterThan`, `GreaterThanOrEqual`, `LessThan`, `LessThanOrEqual`, `Equal`.

`DurationSamples` is consecutive samples. The default collector interval is one second, so `DurationSamples="5"` normally means about five seconds.

Profiles only affect presentation and rule evaluation. They do not alter the BLG collector.
