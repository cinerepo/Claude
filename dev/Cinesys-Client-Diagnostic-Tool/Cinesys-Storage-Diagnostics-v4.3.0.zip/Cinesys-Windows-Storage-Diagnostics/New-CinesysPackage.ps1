<#
Packs a capture folder for sending to Cinesys.

    .\New-CinesysPackage.ps1 -CapturePath "C:\PerfLogs\Admin\Cinesys Storage Diagnostic\HOST_20261014-000003"
    .\New-CinesysPackage.ps1 -CapturePath <folder> -Kind Full
    .\New-CinesysPackage.ps1 -CapturePath <folder> -Kind Full -Zstd

Summary (default): everything except the ETW traces and packet captures,
usually tens of MB. Contains the PerfMon log and CSV, findings, topology,
path health, events, snapshots and the manifest. Send this first.

Full: the whole folder, including the ETW trace (often several GB). -Zstd
writes a .tar.zst instead of a .zip (smaller, faster); it needs zstd.exe on
the PATH or in the Tools folder next to this script.

The package is written next to the capture folder unless -OutputPath is given.
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)][string]$CapturePath,
    [ValidateSet('Summary','Full')][string]$Kind = 'Summary',
    [string]$OutputPath,
    [switch]$Zstd
)

$ErrorActionPreference = 'Stop'
$CapturePath = (Resolve-Path $CapturePath).Path.TrimEnd('\')
if (!(Test-Path $CapturePath -PathType Container)) { throw "Capture folder not found: $CapturePath" }
$name = Split-Path $CapturePath -Leaf
if (-not $OutputPath) { $OutputPath = Split-Path $CapturePath -Parent }
New-Item -ItemType Directory -Force -Path $OutputPath | Out-Null

# Files left out of the summary package: traces, packet captures, and the
# symbol caches WPR writes next to the ETL.
function Test-SummaryExcluded([string]$RelativePath) {
    if ($RelativePath -match '(?i)\.etl$|\.pcapng$') { return $true }
    if ($RelativePath -match '(?i)\.etl\.(NGENPDB|EmbeddedPdbs)\\') { return $true }
    if ($RelativePath -match '(?i)(^|\\)Path-Health\.stop$') { return $true }
    return $false
}

$files = @(Get-ChildItem $CapturePath -Recurse -File)
$included = @()
$excluded = @()
foreach ($f in $files) {
    $rel = $f.FullName.Substring($CapturePath.Length + 1)
    if ($Kind -eq 'Summary' -and (Test-SummaryExcluded $rel)) { $excluded += $f } else { $included += [pscustomobject]@{ File = $f; Relative = $rel } }
}

if ($Zstd) {
    $zstdExe = (Get-Command zstd.exe -ErrorAction SilentlyContinue).Source
    if (-not $zstdExe) { $p = Join-Path $PSScriptRoot 'Tools\zstd.exe'; if (Test-Path $p) { $zstdExe = $p } }
    if (-not $zstdExe) { throw 'zstd.exe was not found on the PATH or in the Tools folder. Use a .zip package (omit -Zstd) or install zstd.' }
    if (-not (Get-Command tar.exe -ErrorAction SilentlyContinue)) { throw 'tar.exe is not available on this Windows build. Use a .zip package (omit -Zstd).' }
    $tar = Join-Path $OutputPath "$name.$($Kind.ToLower()).tar"
    $out = "$tar.zst"
    Remove-Item $tar, $out -Force -ErrorAction SilentlyContinue
    $list = Join-Path $env:TEMP "cinesys-package-$([guid]::NewGuid().ToString('N')).txt"
    $included | ForEach-Object { "$name\$($_.Relative)" } | Set-Content -Path $list -Encoding ASCII
    Write-Host "Creating $tar ..." -ForegroundColor Cyan
    & tar.exe -cf $tar -C (Split-Path $CapturePath -Parent) -T $list
    $tarExit = $LASTEXITCODE
    Remove-Item $list -Force -ErrorAction SilentlyContinue
    if ($tarExit -ne 0) { throw "tar failed (exit $tarExit)." }
    Write-Host "Compressing with zstd ..." -ForegroundColor Cyan
    & $zstdExe -T0 -9 --rm -q -o $out $tar
    if ($LASTEXITCODE -ne 0) { throw "zstd failed (exit $LASTEXITCODE)." }
} else {
    Add-Type -AssemblyName System.IO.Compression
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    $out = Join-Path $OutputPath "$name.$($Kind.ToLower()).zip"
    Remove-Item $out -Force -ErrorAction SilentlyContinue
    Write-Host "Creating $out ..." -ForegroundColor Cyan
    $zip = [System.IO.Compression.ZipFile]::Open($out, [System.IO.Compression.ZipArchiveMode]::Create)
    try {
        foreach ($i in $included) {
            [void][System.IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip, $i.File.FullName, ("$name/" + ($i.Relative -replace '\\', '/')), [System.IO.Compression.CompressionLevel]::Optimal)
        }
    } finally { $zip.Dispose() }
}

$size = (Get-Item $out).Length
Write-Host ("Package: {0} ({1:N1} MB, {2} files)" -f $out, ($size / 1MB), $included.Count) -ForegroundColor Green
if ($excluded.Count) {
    $exBytes = ($excluded | Measure-Object -Property Length -Sum).Sum
    Write-Host ("Left out of the summary: {0} file(s), {1:N1} MB (ETW trace / packet capture). Cinesys will ask for the full package if needed." -f $excluded.Count, ($exBytes / 1MB))
}
[pscustomobject]@{ Path = $out; Bytes = $size; Files = $included.Count; Kind = $Kind; ExcludedFiles = $excluded.Count }
