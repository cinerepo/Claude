#requires -RunAsAdministrator
[CmdletBinding()]
param([string]$Root = "C:\Cinesys\Storage-Diagnostic",
    [switch]$GenerateLegacyHtml,
    # Skip the automatic stall analysis (Findings.txt).
    [switch]$NoAnalysis,
    # Skip creating the summary package (<capture>.summary.zip).
    [switch]$NoPackage)

$ErrorActionPreference = "Continue"
Import-Module (Join-Path $PSScriptRoot 'Cinesys.Common.psm1') -Force
Import-Module (Join-Path $PSScriptRoot 'Cinesys.Trace.psm1') -Force
$version = Get-CinesysVersion

$current = Join-Path $Root "CurrentCapture.json"
if (!(Test-Path $current)) { throw "No active Cinesys capture is registered under $Root." }

$state = Get-Content $current -Raw | ConvertFrom-Json
$capture = $state.CapturePath
$dcsName = $state.DcsName
if (!(Test-Path $capture)) { throw "Capture directory not found: $capture" }
$metadata = Join-Path $capture 'Capture-Metadata.txt'

# Captures started by v3.8 have no manifest; create one so Stop still records timing.
$manifest = Read-CinesysManifest -CapturePath $capture
if ($null -eq $manifest) {
    $manifest = New-CinesysManifest -CapturePath $capture -Properties @{ DcsName = $dcsName; CreatedBy = 'Stop (capture started by an older version)' }
    $manifest.Started = $state.Started
}
function Save-State { Save-CinesysManifest -CapturePath $capture -Manifest $manifest }
$captureStarted = $null
try { $captureStarted = [datetime]::Parse([string]$manifest.Started) } catch {}

# Stop PerfMon FIRST. This prevents WPR merge time from extending the BLG capture,
# and makes the required collector independent of optional ETW cleanup.
$perfMonOk = $true
$pm = $manifest.Collectors.PerfMon
if ($dcsName) {
    Write-Host "Stopping PerfMon collector: $dcsName" -ForegroundColor Cyan
    $before = Get-DcsState -Name $dcsName
    if (-not $before.Exists) {
        Write-Host "PerfMon collector is already absent." -ForegroundColor Yellow
        Add-CinesysManifestWarning -Manifest $manifest -Message "The DCS '$dcsName' no longer exists at stop time."
    } else {
        if ($before.Status -notmatch '(?i)Running') {
            # PerfMon stopped on its own before Stop was run: the BLG will not
            # cover the whole reproduction.
            Add-CinesysManifestWarning -Manifest $manifest -Message "PerfMon was already '$($before.Status)' before Stop was run. The BLG ends before the reproduction did."
        }
        $pm.StopRequested = Get-CinesysTimestamp
        $stop = Invoke-Logman -Arguments @('stop', $dcsName)
        if ($stop.ExitCode -ne 0 -and $before.Status -match '(?i)Running') {
            $perfMonOk = $false
            $pm.Error = $stop.Output
            Write-Warning "logman stop failed (exit $($stop.ExitCode)): $($stop.Output)"
        }
        $afterStop = Wait-DcsStatus -Name $dcsName -Status 'Stopped' -TimeoutSeconds 30
        if ($afterStop.Exists -and $afterStop.Status -notmatch '(?i)Stopped') {
            $perfMonOk = $false
            Write-Warning "PerfMon collector did not verify as Stopped. Current status: $($afterStop.Status)"
        } else {
            $pm.StopConfirmed = Get-CinesysTimestamp
            Write-Host "PerfMon stop: verified. DCS retained: $dcsName" -ForegroundColor Green
        }
    }
}
Save-State

# ETW/WPR is optional and handled independently from PerfMon. Only a session
# this toolkit started is stopped, by instance name where WPR supports it.
$etw = $manifest.Collectors.ETW
$etl = Join-Path $capture "Cinesys-Windows-Storage.etl"
$wprStarted = $false
if ($null -ne $state.PSObject.Properties['WprStarted']) { $wprStarted = [bool]$state.WprStarted }
$instanceName = $null
if ($null -ne $state.PSObject.Properties['WprInstanceName']) { $instanceName = $state.WprInstanceName }
if ($wprStarted) {
    Write-Host "Stopping and merging ETW trace..." -ForegroundColor Cyan
    $wprArgs = @('-stop', $etl, "Cinesys Windows Storage Diagnostic v$version")
    if ($instanceName) { $wprArgs += @('-instancename', $instanceName) }
    $etw.StopRequested = Get-CinesysTimestamp
    $r = Invoke-Wpr -Arguments $wprArgs
    $etw.StopCompleted = Get-CinesysTimestamp
    $etw.StopCommand = $r.Command
    $etw.StopExitCode = $r.ExitCode
    $etw.StopOutput = $r.Output
    if ($r.ExitCode -ne 0) {
        Write-Warning "WPR stop failed (exit $($r.ExitCode)): $($r.Output)"
        Add-CinesysManifestWarning -Manifest $manifest -Message "WPR stop failed (exit $($r.ExitCode)). The ETL may be missing or incomplete."
    }
    if (Test-Path $etl) { $etw.File = Split-Path $etl -Leaf; $etw.Bytes = (Get-Item $etl).Length }
} else {
    Write-Host "ETW/WPR was not active for this capture; skipping ETL merge." -ForegroundColor Yellow
}
Save-State

# Packet Monitor (v4.0+ captures), only when Cinesys started it.
if ($null -ne $state.PSObject.Properties['PktMonStarted'] -and [bool]$state.PktMonStarted) {
    Write-Host "Stopping Packet Monitor..." -ForegroundColor Cyan
    $pkt = Stop-CinesysPktMon -CapturePath $capture -Syntax $state.PktMonSyntax -EtlFile $state.PktMonEtl -NoPcapConversion:([bool]$state.NoPcapConversion) -RemoveFilters:([bool]$state.PktMonFilters)
    if ($null -ne $manifest.Collectors.PSObject.Properties['PacketCapture']) {
        $pc = $manifest.Collectors.PacketCapture
        $pc.Stopped = Get-CinesysTimestamp
        $pc.CountersFile = Split-Path $pkt.CountersFile -Leaf
        if ($pkt.PcapFile) { $pc.PcapFile = Split-Path $pkt.PcapFile -Leaf }
        $pc.Commands = @($pc.Commands) + @($pkt.Commands | ForEach-Object { "$($_.Command) => exit $($_.ExitCode)" })
        if ($pkt.Error) { $pc.Error = $pkt.Error }
    }
    if ($pkt.Error) { Add-CinesysManifestWarning -Manifest $manifest -Message "Packet Monitor: $($pkt.Error)" }
    else { Write-Host "Packet Monitor stopped. Counters: PktMon-Counters.txt$(if ($pkt.PcapFile) { '; capture: PktMon.etl (WPA) and PktMon.pcapng (Wireshark)' })" -ForegroundColor Green }
}
Save-State

# Stop the path-health poller (v3.10+ captures).
if ($null -ne $state.PSObject.Properties['PathHealthPid'] -and $state.PathHealthPid) {
    $result = Stop-CinesysPathHealth -ProcessId ([int]$state.PathHealthPid) -ProcessStart $state.PathHealthProcessStart -StopFile $state.PathHealthStopFile
    if ($null -ne $manifest.Collectors.PSObject.Properties['PathHealth']) {
        $manifest.Collectors.PathHealth.Stopped = Get-CinesysTimestamp
        $manifest.Collectors.PathHealth.StopResult = $result
    }
    if ($result -ne 'Exited') { Add-CinesysManifestWarning -Manifest $manifest -Message "Path-health poller: $result" }
    $changesCsv = Join-Path $capture 'Path-Health-Changes.csv'
    if (Test-Path $changesCsv) {
        $changed = @(Import-Csv $changesCsv | Where-Object { $_.Before -ne '(baseline)' })
        Write-Host "Path health: $($changed.Count) state change(s) during the capture (Path-Health-Changes.csv)" -ForegroundColor $(if ($changed.Count) { 'Yellow' } else { 'Green' })
    }
}
Save-State

# Record the actual time coverage of every BLG PLA wrote. The original files are
# kept as-is; v3.8 also copied the newest BLG to Cinesys-Performance.blg, which
# doubled the package size without adding data.
$blgs = @(Get-ChildItem $capture -Filter 'Cinesys-Performance*.blg' -ErrorAction SilentlyContinue | Sort-Object Name)
$coverage = @()
foreach ($b in $blgs) { $coverage += Get-BlgCoverage -Path $b.FullName }
$pm.Files = @($coverage | Select-Object File, Bytes, Begin, End, Samples, Seconds)
if ($coverage.Count -eq 0) {
    Add-CinesysManifestWarning -Manifest $manifest -Message "No Cinesys-Performance*.blg was found in $capture."
} else {
    $first = ($coverage | Where-Object { $_.BeginTime } | Sort-Object BeginTime | Select-Object -First 1)
    $last = ($coverage | Where-Object { $_.EndTime } | Sort-Object EndTime | Select-Object -Last 1)
    $stopRequested = $null
    try { $stopRequested = [datetime]::Parse([string]$pm.StopRequested) } catch {}
    $startConfirmed = $null
    try { $startConfirmed = [datetime]::Parse([string]$pm.StartConfirmed) } catch {}
    if ($last -and $stopRequested -and ($stopRequested - $last.EndTime).TotalSeconds -gt 30) {
        Add-CinesysManifestWarning -Manifest $manifest -Message ("PerfMon data ends at {0:HH:mm:ss} but Stop was requested at {1:HH:mm:ss} ({2:N0} s missing at the end)." -f $last.EndTime, $stopRequested, ($stopRequested - $last.EndTime).TotalSeconds)
    }
    if ($first -and $startConfirmed -and ($first.BeginTime - $startConfirmed).TotalSeconds -gt 30) {
        Add-CinesysManifestWarning -Manifest $manifest -Message ("PerfMon data begins at {0:HH:mm:ss}, {1:N0} s after the collector started." -f $first.BeginTime, ($first.BeginTime - $startConfirmed).TotalSeconds)
    }
    foreach ($c in $coverage) {
        Write-Host ("BLG {0}: {1} -> {2} ({3} s, {4} samples)" -f $c.File, $c.Begin, $c.End, $c.Seconds, $c.Samples)
    }
}
Save-State

$snapshot = Join-Path $PSScriptRoot 'Snapshot-State.ps1'
if (Test-Path $snapshot) {
    $manifest.Collectors.PostSnapshot.Started = Get-CinesysTimestamp
    $eventsSince = (Get-Date).AddHours(-4)
    if ($captureStarted) { $eventsSince = $captureStarted.AddMinutes(-5) }
    try {
        & $snapshot -OutputFile (Join-Path $capture 'PostCapture-State.txt') -EventsSince $eventsSince -EventsFile (Join-Path $capture 'Storage-Events-Post.csv')
    } catch { $manifest.Collectors.PostSnapshot.Error = $_.Exception.Message }
    $manifest.Collectors.PostSnapshot.Completed = Get-CinesysTimestamp
}

$topology = Join-Path $PSScriptRoot 'Get-CinesysTopology.ps1'
if ((Test-Path $topology) -and $null -ne $manifest.Collectors.PSObject.Properties['Topology']) {
    $manifest.Collectors.Topology.PostStarted = Get-CinesysTimestamp
    $pathIps = @()
    if ($manifest.PSObject.Properties['Parameters'] -and $manifest.Parameters) {
        foreach ($k in 'PathTestIp', 'PacketFilterIp') { if ($manifest.Parameters.PSObject.Properties[$k]) { $pathIps += @($manifest.Parameters.$k) } }
    }
    $pathIps = @($pathIps | Where-Object { $_ } | Select-Object -Unique)
    try { & $topology -OutputPath $capture -Label 'Post' -PathTestIp $pathIps } catch { $manifest.Collectors.Topology.PostError = $_.Exception.Message }
    $manifest.Collectors.Topology.PostCompleted = Get-CinesysTimestamp
}

# Cover the whole capture plus margin; v3.8 always asked for 30 minutes.
if (Get-Command Get-ClusterLog -ErrorAction SilentlyContinue) {
    $minutes = 30
    if ($captureStarted) { $minutes = [int][math]::Ceiling(((Get-Date) - $captureStarted).TotalMinutes) + 15 }
    $manifest.Collectors.ClusterLog.TimeSpanMinutes = $minutes
    try {
        Get-ClusterLog -UseLocalTime -TimeSpan $minutes -Destination $capture -ErrorAction Stop | Out-Null
        $manifest.Collectors.ClusterLog.Collected = $true
    } catch {
        $manifest.Collectors.ClusterLog.Error = $_.Exception.Message
        "ClusterLogError=$($_.Exception.Message)" | Add-Content $metadata
    }
}

"StopAttempt=$($pm.StopRequested)" | Add-Content $metadata
"PerfMonStopVerified=$perfMonOk" | Add-Content $metadata
if ($wprStarted) { "WPRStopExitCode=$($etw.StopExitCode)" | Add-Content $metadata }
foreach ($c in $coverage) { "BlgCoverage=$($c.File)|$($c.Begin)|$($c.End)|$($c.Samples)" | Add-Content $metadata }
if ($etw.Bytes) { "Cinesys-Windows-StorageetlBytes=$($etw.Bytes)" | Add-Content $metadata }

# Keep CurrentCapture.json if required PerfMon cleanup failed. This allows Stop to
# be retried and prevents Start from creating another untracked collector.
$manifest.Stopped = Get-CinesysTimestamp
if ($perfMonOk) {
    if (@($manifest.Warnings).Count -gt 0) { $manifest.Status = 'CompletedWithWarnings' } else { $manifest.Status = 'Completed' }
    "Stopped=$($manifest.Stopped)" | Add-Content $metadata
    Remove-Item $current -Force -ErrorAction SilentlyContinue
} else {
    $manifest.Status = 'NotFinalized'
    Write-Warning "Capture remains registered because PerfMon cleanup was not verified. CurrentCapture.json was preserved."
}
Save-State

# Export the PerfMon log to CSV (used by the analysis and by tools without
# BLG support), then analyze this capture and build the summary package.
# None of this is required for the capture to be complete.
$csv = Join-Path $capture 'Cinesys-Performance.csv'
$blgForCsv = $blgs | Sort-Object Length -Descending | Select-Object -First 1
if ($perfMonOk -and $blgForCsv -and !(Test-Path $csv)) {
    Write-Host "Exporting PerfMon data to CSV..." -ForegroundColor Cyan
    $out = & relog.exe $blgForCsv.FullName -f csv -o $csv -y 2>&1 | Out-String
    if ($LASTEXITCODE -ne 0 -or !(Test-Path $csv)) { Add-CinesysManifestWarning -Manifest $manifest -Message "relog CSV export failed: $($out.Trim())" }
}
if ($perfMonOk -and -not $NoAnalysis -and (Test-Path $csv)) {
    $analysis = Join-Path $PSScriptRoot 'Invoke-CinesysAnalysis.ps1'
    if (Test-Path $analysis) {
        Write-Host "Analyzing capture..." -ForegroundColor Cyan
        try { & $analysis -CapturePath $capture | Out-Null }
        catch { Add-CinesysManifestWarning -Manifest $manifest -Message "Analysis failed: $($_.Exception.Message)" }
        $findings = Join-Path $capture 'Findings.txt'
        if (Test-Path $findings) {
            $stallLine = @(Get-Content $findings | Where-Object { $_ -match 'stall\(s\) totalling' })
            foreach ($l in $stallLine) { Write-Host $l.Trim() }
        }
    }
}
Save-State
$package = $null
if ($perfMonOk -and -not $NoPackage) {
    $packager = Join-Path $PSScriptRoot 'New-CinesysPackage.ps1'
    if (Test-Path $packager) {
        try { $package = & $packager -CapturePath $capture -Kind Summary }
        catch { Add-CinesysManifestWarning -Manifest $manifest -Message "Summary package failed: $($_.Exception.Message)" }
    }
}
Save-State

# Generate the legacy HTML report after the BLG is finalized.
# Reporting is non-fatal: capture completion never depends on HTML generation.
if ($perfMonOk -and $GenerateLegacyHtml) {
    $reporter = Join-Path $PSScriptRoot 'Reports\Generate-CinesysStorageReport.ps1'
    if (Test-Path $reporter) {
        try {
            & $reporter -CapturePath $capture -Profile General
        } catch {
            "ReportError=$($_.Exception.Message -replace '[\r\n]+',' ')" | Add-Content $metadata
            Write-Warning "Capture completed, but report generation failed: $($_.Exception.Message) | $($_.InvocationInfo.PositionMessage -replace '[\r\n]+',' ')"
        }
    }
}

Write-Host ""
if (-not $perfMonOk) {
    Write-Warning "Capture is NOT finalized because the PerfMon collector could not be verified stopped."
} elseif (-not $wprStarted) {
    Write-Host "Capture complete (PerfMon/state only; ETW was not running)." -ForegroundColor Green
} elseif ($etw.StopExitCode -eq 0 -and (Test-Path $etl)) {
    Write-Host "Capture complete." -ForegroundColor Green
} else {
    Write-Warning "PerfMon/state capture completed, but WPR did not produce the expected ETL."
}
foreach ($w in @($manifest.Warnings)) { Write-Warning $w }
Write-Host "Capture directory: $capture"
Write-Host "Manifest: $(Join-Path $capture 'Capture-Manifest.json')"
if (Test-Path (Join-Path $capture 'Findings.txt')) { Write-Host "Findings: $(Join-Path $capture 'Findings.txt')" }
if ($package) { Write-Host "Send to Cinesys: $($package.Path)" -ForegroundColor Green }
