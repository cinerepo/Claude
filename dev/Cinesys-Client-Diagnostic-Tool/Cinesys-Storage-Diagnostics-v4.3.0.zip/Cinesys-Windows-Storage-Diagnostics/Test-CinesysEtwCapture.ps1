#requires -RunAsAdministrator
<#
Checks that the ETW providers in a Cinesys trace actually produced events.

Record a short test trace with generated disk and SMB load, then check it:
    .\Test-CinesysEtwCapture.ps1 -Areas General,Storage,SMB,SAN -Seconds 30
    .\Test-CinesysEtwCapture.ps1 -Areas SAN -TestPath C:\ClusterStorage\Volume1\CinesysTest

Check an existing capture folder:
    .\Test-CinesysEtwCapture.ps1 -CapturePath "C:\PerfLogs\Admin\Cinesys Storage Diagnostic\HOST_20261014-000003"

Writes Etw-Provider-Validation.csv (and the raw statistics) to the capture or
test folder. "NoEvents" can also mean the workload never exercised that
component, for example SAN providers when -TestPath is not on an iSCSI disk.
#>
[CmdletBinding(DefaultParameterSetName='Record')]
param(
    [Parameter(ParameterSetName='Existing', Mandatory=$true)][string]$CapturePath,
    [Parameter(ParameterSetName='Record')]
    [ValidateSet("General","Storage","SMB","Network","SAN","HyperV","PktMonEvents")]
    [string[]]$Areas = @("General","Storage","SMB"),
    [Parameter(ParameterSetName='Record')][ValidateRange(10,600)][int]$Seconds = 30,
    # Folder the load generator writes a temporary file to (deleted afterwards).
    # Point it at the volume whose stack you want to exercise.
    [Parameter(ParameterSetName='Record')][string]$TestPath = $env:TEMP,
    [Parameter(ParameterSetName='Record')][ValidateRange(64,16384)][int]$TestFileMB = 1024,
    [string]$OutputPath,
    # Allow tracerpt on a large ETL when xperf is not installed (slow, uses disk).
    [switch]$AllowTracerpt
)

$ErrorActionPreference = 'Stop'
Import-Module (Join-Path $PSScriptRoot 'Cinesys.Common.psm1') -Force
Import-Module (Join-Path $PSScriptRoot 'Cinesys.Trace.psm1') -Force

# Kernel event classes each WPR kernel keyword should produce.
$kernelClasses = @{
    DiskIO = @('DiskIo','3d6fa8d4-fe05-11d0-9dda-00c04fd7ba7c'); DiskIOInit = @('DiskIo','3d6fa8d4-fe05-11d0-9dda-00c04fd7ba7c')
    FileIO = @('FileIo','90cbdc39-4a3e-11d1-84f4-0000f80464e3'); FileIOInit = @('FileIo','90cbdc39-4a3e-11d1-84f4-0000f80464e3')
    SampledProfile = @('PerfInfo','ce1dbfb4-137e-4da6-87b0-3f59aa102cbc'); DPC = @('PerfInfo','ce1dbfb4-137e-4da6-87b0-3f59aa102cbc'); Interrupt = @('PerfInfo','ce1dbfb4-137e-4da6-87b0-3f59aa102cbc')
    CSwitch = @('Thread','3d6fa8d1-fe05-11d0-9dda-00c04fd7ba7c'); ReadyThread = @('Thread','3d6fa8d1-fe05-11d0-9dda-00c04fd7ba7c'); ProcessThread = @('Process','3d6fa8d0-fe05-11d0-9dda-00c04fd7ba7c')
    HardFaults = @('PageFault','3d6fa8d3-fe05-11d0-9dda-00c04fd7ba7c'); SplitIO = @('SplitIo','d837ca92-12b9-44a5-ad6a-3a65b3578aa8')
    NetworkTrace = @('TcpIp','9a280ac0-c8e0-11d1-84e2-00c04fb998a2'); Loader = @('Image','2cb15d1d-5fc1-11d2-abe1-00a0c911f518')
}

function Find-Xperf {
    $c = Get-Command xperf.exe -ErrorAction SilentlyContinue
    if ($c) { return $c.Source }
    foreach ($p in @("$env:ProgramFiles\Windows Kits\10\Windows Performance Toolkit\xperf.exe", "${env:ProgramFiles(x86)}\Windows Kits\10\Windows Performance Toolkit\xperf.exe")) {
        if ($p -and (Test-Path $p)) { return $p }
    }
    return $null
}

function Get-EventCounts {
    # Returns hashtable key (lower-case GUID or event/provider name) -> count,
    # plus the raw statistics file. Parsing is tolerant: each line holding a
    # GUID or a known name contributes the first number on the line.
    param([string]$Etl, [string]$OutDir, [bool]$Large)
    $counts = @{}
    $xperf = Find-Xperf
    $rawFile = Join-Path $OutDir 'Etw-TraceStats.txt'
    if ($xperf) {
        $r = Invoke-TraceTool -Exe $xperf -Arguments @('-i', $Etl, '-a', 'tracestats')
        $r.Output | Set-Content -Path $rawFile -Encoding UTF8
        $tool = 'xperf tracestats'
    } elseif (-not $Large -or $AllowTracerpt) {
        $tmp = Join-Path $OutDir 'tracerpt-dump.csv'
        $summary = Join-Path $OutDir 'Etw-TraceStats.txt'
        $r = Invoke-TraceTool -Exe 'tracerpt.exe' -Arguments @($Etl, '-o', $tmp, '-of', 'CSV', '-summary', $summary, '-y')
        Remove-Item $tmp -Force -ErrorAction SilentlyContinue
        $tool = 'tracerpt -summary'
    } else {
        throw "xperf.exe (Windows Performance Toolkit) was not found and the ETL is large. Install WPT, or re-run with -AllowTracerpt."
    }
    if (Test-Path $rawFile) {
        foreach ($line in (Get-Content $rawFile)) {
            $guids = @([regex]::Matches($line, '[0-9A-Fa-f]{8}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{12}') | ForEach-Object { $_.Value.ToLower() })
            $rest = [regex]::Replace($line, '\{?[0-9A-Fa-f]{8}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{12}\}?', ' ')
            $num = [regex]::Match(($rest -replace '(?<=\d),(?=\d{3})', ''), '(?<![\w.-])(\d+)(?![\w.-])')
            if (-not $num.Success) { continue }
            $n = [long]$num.Groups[1].Value
            foreach ($g in $guids) { if (-not $counts.ContainsKey($g)) { $counts[$g] = 0 }; $counts[$g] += $n }
            foreach ($w in @([regex]::Matches($rest, '[A-Za-z][A-Za-z0-9_-]+') | ForEach-Object { $_.Value.ToLower() })) {
                if ($w.Length -lt 4) { continue }
                if (-not $counts.ContainsKey($w)) { $counts[$w] = 0 }; $counts[$w] += $n
            }
        }
    }
    [pscustomobject]@{ Counts = $counts; Tool = $tool; RawFile = $rawFile }
}

# ---------------------------------------------------------------------------
if ($PSCmdlet.ParameterSetName -eq 'Record') {
    if (-not $OutputPath) { $OutputPath = Join-Path $env:TEMP ("Cinesys-EtwTest-" + (Get-Date -Format 'yyyyMMdd-HHmmss')) }
    New-Item -ItemType Directory -Force -Path $OutputPath | Out-Null
    $status = Invoke-Wpr -Arguments @('-status')
    if ($status.ExitCode -eq 0 -and $status.Output -notmatch '(?i)not recording|no recording') { throw 'WPR is already recording. Stop that recording first; this test does not touch it.' }

    $catalog = Get-CinesysEtwCatalog
    $resolved = Resolve-CinesysEtwAreas -Areas $Areas -Catalog $catalog -Registered (Get-CinesysRegisteredProviders)
    $resolved | Export-Csv -Path (Join-Path $OutputPath 'Etw-Providers.csv') -NoTypeInformation -Encoding UTF8
    $wprp = New-CinesysWprProfile -Areas $Areas -Catalog $catalog -Resolved $resolved -OutputFile (Join-Path $OutputPath 'Cinesys-Trace-Profile.wprp')
    $etl = Join-Path $OutputPath 'Cinesys-EtwTest.etl'

    Write-Host "Recording $Seconds s test trace ($($Areas -join ', '))..." -ForegroundColor Cyan
    $r = Invoke-Wpr -Arguments @('-start', "$($wprp.Path)!Cinesys", '-filemode')
    if ($r.ExitCode -ne 0) { throw "WPR rejected the generated profile (exit $($r.ExitCode)): $($r.Output)`nProfile: $($wprp.Path)" }
    $started = Get-Date
    try {
        # Load: sequential write and read on TestPath, then the same file read
        # over SMB loopback (exercises SMB client and server).
        $file = Join-Path $TestPath ("cinesys-etw-test-" + [guid]::NewGuid().ToString('N') + '.bin')
        $buf = New-Object byte[] (1MB)
        (New-Object System.Random).NextBytes($buf)
        $fs = [System.IO.File]::Open($file, 'Create', 'Write', 'None')
        for ($i = 0; $i -lt $TestFileMB; $i++) { $fs.Write($buf, 0, $buf.Length) }
        $fs.Flush($true); $fs.Close()
        $fs = [System.IO.File]::OpenRead($file)
        while ($fs.Read($buf, 0, $buf.Length) -gt 0) {}
        $fs.Close()
        if ($file -match '^([A-Za-z]):\\(.*)$') {
            $unc = "\\localhost\$($Matches[1])`$\$($Matches[2])"
            try {
                $fs = [System.IO.File]::OpenRead($unc)
                while ($fs.Read($buf, 0, $buf.Length) -gt 0) {}
                $fs.Close()
            } catch { Write-Warning "SMB loopback read failed ($unc): $($_.Exception.Message)" }
        }
        Remove-Item $file -Force -ErrorAction SilentlyContinue
        $remaining = $Seconds - ((Get-Date) - $started).TotalSeconds
        if ($remaining -gt 0) { Start-Sleep -Seconds ([int][math]::Ceiling($remaining)) }
    } finally {
        $s = Invoke-Wpr -Arguments @('-stop', $etl, 'Cinesys ETW validation')
        if ($s.ExitCode -ne 0) { throw "WPR stop failed (exit $($s.ExitCode)): $($s.Output)" }
    }
    $providersCsv = Join-Path $OutputPath 'Etw-Providers.csv'
    $kernel = $wprp.Kernel
    $outDir = $OutputPath
} else {
    $outDir = $(if ($OutputPath) { $OutputPath } else { $CapturePath })
    $etl = Join-Path $CapturePath 'Cinesys-Windows-Storage.etl'
    $providersCsv = Join-Path $CapturePath 'Etw-Providers.csv'
    if (!(Test-Path $etl)) { throw "No Cinesys-Windows-Storage.etl in $CapturePath" }
    if (!(Test-Path $providersCsv)) { throw "No Etw-Providers.csv in $CapturePath (captures from before v4.0, or recorded with -TraceProfile BuiltIn, cannot be checked per provider)." }
    $resolved = Import-Csv $providersCsv
    $kernel = @()
    $catalog = Get-CinesysEtwCatalog
    foreach ($a in @($resolved | ForEach-Object { $_.Area } | Select-Object -Unique)) { $kernel += @($catalog.Areas[$a].Kernel) }
    $manifest = Read-CinesysManifest -CapturePath $CapturePath
    if ($manifest) { foreach ($a in @($manifest.Collectors.ETW.Profiles)) { if ($catalog.Areas[$a]) { $kernel += @($catalog.Areas[$a].Kernel) } } }
    $kernel = @($kernel | Select-Object -Unique)
}

Write-Host "Counting events per provider..." -ForegroundColor Cyan
$large = (Get-Item $etl).Length -gt 500MB
$stats = Get-EventCounts -Etl $etl -OutDir $outDir -Large $large

$rows = @()
foreach ($p in @($resolved)) {
    if ($p.Status -eq 'NotRegistered') {
        $rows += [pscustomobject]@{ Area = $p.Area; Item = "pattern $($p.Pattern)"; Kind = 'Provider'; Events = $null; Status = 'NotRegistered' }
        continue
    }
    if ($p.Status -ne 'Selected') { continue }
    $n = $null
    if ($stats.Counts.ContainsKey(([string]$p.Guid).ToLower())) { $n = $stats.Counts[([string]$p.Guid).ToLower()] }
    elseif ($stats.Counts.ContainsKey(([string]$p.Name).ToLower())) { $n = $stats.Counts[([string]$p.Name).ToLower()] }
    $rows += [pscustomobject]@{ Area = $p.Area; Item = $p.Name; Kind = 'Provider'; Events = $n; Status = $(if ($n -gt 0) { 'OK' } else { 'NoEvents' }) }
}
foreach ($k in $kernel) {
    $cls = $kernelClasses[$k]
    if (-not $cls) { $rows += [pscustomobject]@{ Area = 'Kernel'; Item = $k; Kind = 'Kernel keyword'; Events = $null; Status = 'NotChecked' }; continue }
    $n = $null
    if ($stats.Counts.ContainsKey($cls[1])) { $n = $stats.Counts[$cls[1]] } elseif ($stats.Counts.ContainsKey($cls[0].ToLower())) { $n = $stats.Counts[$cls[0].ToLower()] }
    $rows += [pscustomobject]@{ Area = 'Kernel'; Item = "$k ($($cls[0]))"; Kind = 'Kernel keyword'; Events = $n; Status = $(if ($n -gt 0) { 'OK' } else { 'NoEvents' }) }
}
$csv = Join-Path $outDir 'Etw-Provider-Validation.csv'
$rows | Export-Csv -Path $csv -NoTypeInformation -Encoding UTF8
$rows | Format-Table Area, Item, Status, Events -AutoSize | Out-String -Width 200 | Write-Host
Write-Host "Statistics: $($stats.Tool), raw output in $($stats.RawFile)"
Write-Host "Validation: $csv"
Write-Host "Trace: $etl"
