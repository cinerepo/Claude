#requires -RunAsAdministrator
[CmdletBinding()]
param([string]$Root = "C:\Cinesys\Storage-Diagnostic")
# Cancel stops the active capture without finalizing it. It never deletes the
# persistent DCS (use Remove-CinesysDataCollectorSet.ps1 for that) and never
# deletes the capture folder, so a partial capture remains available.
$ErrorActionPreference = 'Continue'
Import-Module (Join-Path $PSScriptRoot 'Cinesys.Common.psm1') -Force
Import-Module (Join-Path $PSScriptRoot 'Cinesys.Trace.psm1') -Force

$current = Join-Path $Root "CurrentCapture.json"
if (!(Test-Path $current)) { Write-Host "No active Cinesys capture is registered." -ForegroundColor Yellow; exit 0 }
$state = Get-Content $current -Raw | ConvertFrom-Json
$manifest = $null
if ($state.CapturePath -and (Test-Path $state.CapturePath)) { $manifest = Read-CinesysManifest -CapturePath $state.CapturePath }

$ok = $true
if ($state.DcsName) {
    $s = Get-DcsState -Name $state.DcsName
    if ($s.Exists -and $s.Status -match '(?i)Running') {
        $r = Invoke-Logman -Arguments @('stop', $state.DcsName)
        $after = Wait-DcsStatus -Name $state.DcsName -Status 'Stopped' -TimeoutSeconds 30
        if ($after.Exists -and $after.Status -notmatch '(?i)Stopped') { $ok = $false; Write-Warning "PerfMon collector did not stop: $($r.Output)" }
        elseif ($manifest) { $manifest.Collectors.PerfMon.StopConfirmed = Get-CinesysTimestamp }
    }
}

# Only cancel a WPR session this toolkit started, by instance name where supported.
if ($null -ne $state.PSObject.Properties['WprStarted'] -and [bool]$state.WprStarted) {
    $wprArgs = @('-cancel')
    if ($null -ne $state.PSObject.Properties['WprInstanceName'] -and $state.WprInstanceName) { $wprArgs += @('-instancename', $state.WprInstanceName) }
    $r = Invoke-Wpr -Arguments $wprArgs
    if ($manifest) { Add-CinesysManifestEvent -Manifest $manifest -Step 'WprCancel' -Result "Exit $($r.ExitCode)" -Detail $r.Output }
}

if ($null -ne $state.PSObject.Properties['PktMonStarted'] -and [bool]$state.PktMonStarted) {
    # Keep what was captured, but skip the pcapng conversion to finish quickly.
    $r = Stop-CinesysPktMon -CapturePath $state.CapturePath -Syntax $state.PktMonSyntax -EtlFile $state.PktMonEtl -NoPcapConversion -RemoveFilters:([bool]$state.PktMonFilters)
    if ($manifest) { Add-CinesysManifestEvent -Manifest $manifest -Step 'PktMonStop' -Result "Exit $($r.StopExitCode)" -Detail $r.Error }
}

if ($null -ne $state.PSObject.Properties['PathHealthPid'] -and $state.PathHealthPid) {
    $r = Stop-CinesysPathHealth -ProcessId ([int]$state.PathHealthPid) -ProcessStart $state.PathHealthProcessStart -StopFile $state.PathHealthStopFile
    if ($manifest) { Add-CinesysManifestEvent -Manifest $manifest -Step 'PathHealthStop' -Result $r }
}

if ($manifest) {
    $manifest.Status = 'Cancelled'
    $manifest.Stopped = Get-CinesysTimestamp
    Save-CinesysManifest -CapturePath $state.CapturePath -Manifest $manifest
}

if ($ok) {
    Remove-Item $current -Force -ErrorAction SilentlyContinue
    Write-Host "Active Cinesys capture cancelled. Partial data kept in: $($state.CapturePath)" -ForegroundColor Yellow
    Write-Host "The persistent '$($state.DcsName)' Data Collector Set is retained in Performance Monitor." -ForegroundColor Yellow
} else {
    Write-Warning "Cancellation was incomplete; CurrentCapture.json was preserved for retry."
}
