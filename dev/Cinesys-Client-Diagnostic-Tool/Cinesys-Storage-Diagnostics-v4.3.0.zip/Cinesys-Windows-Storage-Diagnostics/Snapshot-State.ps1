[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)][string]$OutputFile,
    # Storage/network events from this time on are summarised in the text file
    # and exported in full to EventsFile.
    [datetime]$EventsSince = (Get-Date).AddHours(-4),
    [string]$EventsFile,
    # Machine-readable copy of the object-based sections. Defaults to OutputFile with .json.
    [string]$JsonFile
)
$ErrorActionPreference = "Continue"
New-Item -ItemType Directory -Force -Path (Split-Path $OutputFile -Parent) | Out-Null
if (-not $JsonFile) { $JsonFile = [System.IO.Path]::ChangeExtension($OutputFile, '.json') }
if (-not $EventsFile) { $EventsFile = [System.IO.Path]::ChangeExtension($OutputFile, '.events.csv') }

$json = [ordered]@{ Timestamp = (Get-Date).ToString('o'); Computer = $env:COMPUTERNAME }

"=== CINESYS WINDOWS STORAGE DIAGNOSTIC STATE SNAPSHOT ===" | Set-Content $OutputFile
"Timestamp: $(Get-Date -Format o)" | Add-Content $OutputFile
"Computer: $env:COMPUTERNAME`n" | Add-Content $OutputFile

# View: Table or List renders objects and also stores them in the JSON file.
# Raw writes command output as-is (native tools, preformatted text).
function Section {
    param([string]$Title, [scriptblock]$Command, [ValidateSet('Table','List','Raw')][string]$View = 'Table')
    "`n===== $Title =====" | Add-Content $OutputFile
    try {
        $result = @(& $Command 2>&1)
        if ($View -eq 'Raw') {
            ($result | Out-String -Width 300) | Add-Content $OutputFile
            $json[$Title] = ($result | Out-String -Width 300)
            return
        }
        if ($View -eq 'List') { ($result | Format-List * | Out-String -Width 300) | Add-Content $OutputFile }
        else { ($result | Format-Table -AutoSize | Out-String -Width 300) | Add-Content $OutputFile }
        $json[$Title] = @($result | ForEach-Object {
            if ($_ -is [string] -or $_ -is [System.Management.Automation.ErrorRecord]) { [string]$_ }
            else { $_ | Select-Object -Property * -ExcludeProperty CimClass, CimInstanceProperties, CimSystemProperties, PSComputerName }
        })
    } catch {
        "ERROR: $_" | Add-Content $OutputFile
        $json[$Title] = "ERROR: $_"
    }
}

Section "OS" {
    $os = Get-CimInstance Win32_OperatingSystem; $cs = Get-CimInstance Win32_ComputerSystem
    [pscustomobject]@{ WindowsProductName = $os.Caption; OsBuildNumber = $os.BuildNumber; LastBootUpTime = $os.LastBootUpTime; CsManufacturer = $cs.Manufacturer; CsModel = $cs.Model; TotalPhysicalMemoryGB = [math]::Round($cs.TotalPhysicalMemory / 1GB, 1) }
} -View List
Section "PHYSICAL DISKS" { Get-Disk | Select-Object Number,FriendlyName,SerialNumber,HealthStatus,OperationalStatus,Size,PartitionStyle,Location,BusType }
Section "VOLUMES" { Get-Volume | Select-Object DriveLetter,FileSystemLabel,FileSystemType,DriveType,HealthStatus,OperationalStatus,SizeRemaining,Size,Path }
Section "ISCSI SESSIONS" { Get-IscsiSession } -View List
Section "ISCSI CONNECTIONS" { Get-IscsiConnection } -View List
# Targets and portals explain iScsiPrt event 5 ("Failed to setup initiator
# portal"), which fires when a persistent login references an initiator IP
# that no longer exists.
Section "ISCSI TARGETS" { Get-IscsiTarget } -View List
Section "ISCSI TARGET PORTALS" { Get-IscsiTargetPortal } -View List
Section "ISCSI PERSISTENT TARGETS" { iscsicli ListPersistentTargets } -View Raw
Section "MSDSM DEFAULT POLICY" { Get-MSDSMGlobalDefaultLoadBalancePolicy } -View Raw
Section "MSDSM SUPPORTED HARDWARE" { Get-MSDSMSupportedHW }
Section "MPCLAIM DISKS" { mpclaim -s -d } -View Raw
Section "MPCLAIM MPIO DISKS" { mpclaim -s -m } -View Raw
# Per-disk path detail: path IDs, states (Active/Optimized, Unoptimized, Standby),
# TPG and weights.
$mpioDisks = @()
try { $mpioDisks = @((mpclaim -s -d 2>$null | Out-String) -split "`n" | ForEach-Object { if ($_ -match '^\s*MPIO Disk(\d+)\s') { [int]$Matches[1] } }) } catch {}
foreach ($n in $mpioDisks) { Section "MPCLAIM MPIO DISK $n PATHS" { mpclaim -s -d $n } -View Raw }
Section "NETWORK ADAPTERS" { Get-NetAdapter | Sort-Object Name | Select-Object Name,InterfaceDescription,ifIndex,Status,MacAddress,LinkSpeed,MtuSize,VlanID,DriverVersion }
Section "RSS" { Get-NetAdapterRss } -View List
Section "RDMA" { Get-NetAdapterRdma | Select-Object Name,InterfaceDescription,Enabled,Operational,PFC,ETS }
Section "SMB CONNECTIONS" { Get-SmbConnection }
Section "SMB MULTICHANNEL" { Get-SmbMultichannelConnection }
Section "SMB CLIENT INTERFACES" { Get-SmbClientNetworkInterface }
Section "SMB SERVER INTERFACES" { Get-SmbServerNetworkInterface }
Section "SMB SESSIONS" { Get-SmbSession }
Section "SMB CLIENT CONFIG" { Get-SmbClientConfiguration } -View List
Section "SMB SERVER CONFIG" { Get-SmbServerConfiguration } -View List

# ---------------------------------------------------------------------------
# Storage and network events. v3.8 listed every event in full, so repeated
# events (iScsiPrt 5 every 3 s) buried the LUN resets, and the dump data that
# identifies the target was lost. v3.9 writes a summary here and every event,
# including its binary dump data, to EventsFile.
# ---------------------------------------------------------------------------
$providerPattern = '(?i)disk|stor|iscsi|mpio|msdsm|ntfs|partmgr|FailoverClustering|Hyper-V-Storage|Hyper-V-VmSwitch|Hyper-V-VMMS|icea|i40e|ixgb|bnxt|mlx|e1i|e1r|NDIS|Tcpip'
"`n===== RECENT STORAGE SYSTEM EVENTS =====" | Add-Content $OutputFile
"Since: $($EventsSince.ToString('o'))   Full export: $(Split-Path $EventsFile -Leaf)" | Add-Content $OutputFile
try {
    $events = @(Get-WinEvent -FilterHashtable @{ LogName = 'System'; StartTime = $EventsSince } -MaxEvents 50000 -ErrorAction Stop |
        Where-Object { $_.ProviderName -match $providerPattern })
    $rows = foreach ($e in $events) {
        $binary = $null; $data = $null
        try {
            $x = [xml]$e.ToXml()
            $binary = [string]$x.Event.EventData.Binary
            $data = (@($x.Event.EventData.Data) | ForEach-Object { if ($_ -is [System.Xml.XmlElement]) { $_.InnerText } else { [string]$_ } }) -join ' | '
        } catch {}
        $msg = ''
        try { $msg = ([string]$e.Message -replace '[\r\n]+',' ').Trim() } catch {}
        [pscustomobject]@{
            TimeCreated = $e.TimeCreated.ToString('o')
            Provider    = $e.ProviderName
            Id          = $e.Id
            Level       = $e.LevelDisplayName
            Message     = $msg
            Data        = $data
            BinaryData  = $binary
        }
    }
    @($rows) | Export-Csv -Path $EventsFile -NoTypeInformation -Encoding UTF8

    "`n--- Summary by provider/id (count, first, last) ---" | Add-Content $OutputFile
    $groups = @($rows | Group-Object Provider, Id, Level | Sort-Object Count -Descending)
    ($groups | ForEach-Object {
        $sorted = @($_.Group | Sort-Object TimeCreated)
        [pscustomobject]@{
            Count    = $_.Count
            Provider = $sorted[0].Provider
            Id       = $sorted[0].Id
            Level    = $sorted[0].Level
            First    = $sorted[0].TimeCreated
            Last     = $sorted[-1].TimeCreated
            Message  = $(if ($sorted[0].Message.Length -gt 110) { $sorted[0].Message.Substring(0,110) } else { $sorted[0].Message })
        }
    } | Format-Table -AutoSize | Out-String -Width 400) | Add-Content $OutputFile

    # Chronological list of everything except high-volume repeats (>50 of the
    # same provider/id), which are covered by the summary above.
    $noisy = @($groups | Where-Object { $_.Count -gt 50 } | ForEach-Object { $_.Name })
    "`n--- Chronological (repeats over 50 occurrences omitted; see summary) ---" | Add-Content $OutputFile
    (@($rows | Where-Object { $noisy -notcontains ("{0}, {1}, {2}" -f $_.Provider, $_.Id, $_.Level) } | Sort-Object TimeCreated) |
        Format-Table TimeCreated, Provider, Id, Level, @{ n = 'Message'; e = { if ($_.Message.Length -gt 140) { $_.Message.Substring(0,140) } else { $_.Message } } } -AutoSize |
        Out-String -Width 400) | Add-Content $OutputFile
    $json['STORAGE EVENT SUMMARY'] = @($groups | ForEach-Object { [pscustomobject]@{ Key = $_.Name; Count = $_.Count } })
} catch {
    "ERROR: $_" | Add-Content $OutputFile
}

Section "CLUSTER NODES" { if (Get-Command Get-ClusterNode -ErrorAction SilentlyContinue) { Get-ClusterNode } }
Section "CLUSTER NETWORKS" { if (Get-Command Get-ClusterNetwork -ErrorAction SilentlyContinue) { Get-ClusterNetwork } }
Section "CLUSTER SHARED VOLUMES" { if (Get-Command Get-ClusterSharedVolume -ErrorAction SilentlyContinue) { Get-ClusterSharedVolume } } -View List
Section "CLUSTER SHARED VOLUME STATE" { if (Get-Command Get-ClusterSharedVolumeState -ErrorAction SilentlyContinue) { Get-ClusterSharedVolumeState } } -View List
Section "CSV SHARED VOLUME INFO" { if (Get-Command Get-ClusterSharedVolume -ErrorAction SilentlyContinue) { Get-ClusterSharedVolume | ForEach-Object { $_.SharedVolumeInfo } } } -View List
Section "HYPER-V VMS" { if (Get-Command Get-VM -ErrorAction SilentlyContinue) { Get-VM | Select-Object Name,State,CPUUsage,MemoryAssigned,Uptime,Status } }
Section "HYPER-V VHD" { if (Get-Command Get-VM -ErrorAction SilentlyContinue) { Get-VM | Get-VMHardDiskDrive | Select-Object VMName,ControllerType,ControllerNumber,ControllerLocation,Path } }
Section "NET ADAPTER STATS" { Get-NetAdapterStatistics }
Section "UDP STATISTICS (IPv4)" { netstat.exe -s -p UDP } -View Raw
Section "IP STATISTICS (IPv4, fragments)" { netstat.exe -s -p IP } -View Raw
# Avid NEXIS client (data over UDP; invisible to the SMB counters). Found by
# name; registry values whose names suggest secrets are left out.
Section "AVID NEXIS SERVICES AND DRIVERS" {
    Get-Service | Where-Object { $_.Name -match '(?i)avidfos|nexis' -or $_.DisplayName -match '(?i)avid nexis|avidfos' } | Select-Object Name, DisplayName, Status, StartType
    Get-CimInstance Win32_SystemDriver | Where-Object { $_.Name -match '(?i)avidfos|nexis' } | Select-Object Name, State, StartMode, PathName
}
Section "AVID NEXIS VERSION" {
    Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*', 'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*' -ErrorAction SilentlyContinue |
        Where-Object { $_.PSObject.Properties['DisplayName'] -and $_.DisplayName -match '(?i)avid' } | Select-Object DisplayName, DisplayVersion, InstallDate
}
Section "AVID NEXIS WORKSPACES AND NETWORK DRIVES" { net.exe use; Get-CimInstance Win32_NetworkConnection | Select-Object LocalName, RemoteName, ProviderName, ConnectionState } -View Raw
Section "AVID NEXIS CLIENT SOCKETS" {
    $ids = @(Get-Process | Where-Object { $_.ProcessName -match '(?i)^(AvidFos|AvidNEXIS|nxClient)' } | ForEach-Object { $_.Id })
    if ($ids.Count) {
        Get-NetTCPConnection -ErrorAction SilentlyContinue | Where-Object { $ids -contains $_.OwningProcess } | Select-Object @{n='Proto';e={'TCP'}}, LocalAddress, LocalPort, RemoteAddress, RemotePort, State, OwningProcess
        Get-NetUDPEndpoint -ErrorAction SilentlyContinue | Where-Object { $ids -contains $_.OwningProcess } | Select-Object @{n='Proto';e={'UDP'}}, LocalAddress, LocalPort, @{n='RemoteAddress';e={''}}, @{n='RemotePort';e={''}}, @{n='State';e={''}}, OwningProcess
    }
}
Section "AVID NEXIS CLIENT SETTINGS (registry)" {
    foreach ($root in 'HKLM:\SOFTWARE\Avid Technology', 'HKLM:\SOFTWARE\Avid', 'HKLM:\SYSTEM\CurrentControlSet\Services\AvidFos') {
        if (!(Test-Path $root)) { continue }
        foreach ($k in @(Get-Item $root) + @(Get-ChildItem $root -Recurse -Depth 3 -ErrorAction SilentlyContinue)) {
            foreach ($v in @($k.GetValueNames())) {
                if ($v -match '(?i)pass|secret|token|key$|cred') { continue }
                [pscustomobject]@{ Key = ($k.Name -replace '^HKEY_LOCAL_MACHINE', 'HKLM'); Value = $v; Data = [string]$k.GetValue($v) }
            }
        }
    }
}
Section "IP CONFIGURATION" {
    Get-NetIPConfiguration | ForEach-Object {
        [pscustomobject]@{
            InterfaceAlias       = $_.InterfaceAlias
            InterfaceIndex       = $_.InterfaceIndex
            InterfaceDescription = $_.InterfaceDescription
            IPv4Address          = (@($_.IPv4Address | ForEach-Object { "$($_.IPAddress)/$($_.PrefixLength)" }) -join ', ')
            IPv4DefaultGateway   = (@($_.IPv4DefaultGateway | ForEach-Object { $_.NextHop }) -join ', ')
            DNSServer            = (@($_.DNSServer | ForEach-Object { $_.ServerAddresses }) -join ', ')
        }
    }
} -View List
Section "ROUTES" { Get-NetRoute -AddressFamily IPv4 | Sort-Object DestinationPrefix,RouteMetric | Select-Object ifIndex,DestinationPrefix,NextHop,RouteMetric,ifMetric,PolicyStore }

try { $json | ConvertTo-Json -Depth 3 | Set-Content -Path $JsonFile -Encoding UTF8 }
catch { "JSON export failed: $_" | Add-Content $OutputFile }
