[CmdletBinding()]
param([string]$Root = "C:\Cinesys\Storage-Diagnostic")
Import-Module (Join-Path $PSScriptRoot 'Cinesys.Common.psm1') -Force
Write-Host "Cinesys Storage Diagnostics v$(Get-CinesysVersion)" -ForegroundColor Cyan
$current = Join-Path $Root "CurrentCapture.json"
$state = $null
Write-Host "===== CURRENT CAPTURE =====" -ForegroundColor Cyan
if (Test-Path $current) {
    $state = Get-Content $current -Raw | ConvertFrom-Json
    $state | Format-List
    $manifest = $null
    if ($state.CapturePath -and (Test-Path $state.CapturePath)) { $manifest = Read-CinesysManifest -CapturePath $state.CapturePath }
    if ($manifest) {
        Write-Host "Status:          $($manifest.Status)"
        Write-Host "PerfMon started: $($manifest.Collectors.PerfMon.StartConfirmed)"
        Write-Host "ETW started:     $($manifest.Collectors.ETW.StartConfirmed) $($manifest.Collectors.ETW.Error)"
        foreach ($w in @($manifest.Warnings)) { Write-Warning $w }
    }
    Write-Host "===== PERFMON =====" -ForegroundColor Cyan
    if ($state.DcsName) { $s = Get-DcsState -Name $state.DcsName; Write-Host "$($state.DcsName): $($s.Status)" }
} else { Write-Host 'None' }

Write-Host "`n===== WPR =====" -ForegroundColor Cyan
if ($state -and $null -ne $state.PSObject.Properties['WprStarted'] -and -not [bool]$state.WprStarted) {
    Write-Host 'Not started for this capture (PerfMon/state capture is still active).'
} elseif (Get-Command wpr.exe -ErrorAction SilentlyContinue) {
    & wpr.exe -status
} else { Write-Host 'wpr.exe not found.' }

Write-Host ""
Write-Host "Native PerfMon locations:" -ForegroundColor Cyan
Write-Host "  Data Collector Sets > User Defined > Cinesys Storage Diagnostic"
Write-Host "  Reports > User Defined > Cinesys Storage Diagnostic"
