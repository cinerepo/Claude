# ETW trace areas for Cinesys Storage Diagnostics.
#
# Start-CinesysStorageDiagnostic.ps1 -TraceProfile <areas> builds one WPR
# profile from the selected areas. Event providers are matched by regular
# expression against the providers registered on the machine at capture time
# (logman query providers), so a provider that does not exist on a given
# Windows build is skipped and recorded instead of breaking the trace.
#
#   Kernel    WPR SystemProvider keywords (NT kernel events)
#   Stacks    kernel events that also record call stacks
#   Providers Match    regex against the registered provider name
#             Exclude  optional regex; matching names are skipped
#             Level    1 critical .. 5 verbose
#             Keywords optional hex mask; omitted = all keywords (written to the
#                      profile as 0xFFFFFFFFFFFFFFFF; WPR needs it explicit)
#
# Volume notes are in each Note. Test-CinesysEtwCapture.ps1 reports how many
# events each provider actually produced; use it after changing this file.
@{
    Areas = @{
        General = @{
            Description = 'CPU sampling, context switches, DPC/ISR, hard faults, memory. Low to moderate volume.'
            Kernel      = @('ProcessThread','Loader','SampledProfile','CSwitch','ReadyThread','DPC','Interrupt','HardFaults','MemoryInfo')
            Stacks      = @('SampledProfile','CSwitch','ReadyThread')
            Providers   = @()
        }
        Storage = @{
            Description = 'Disk and file I/O with issue and completion times, split I/O, NTFS. Moderate to high volume under heavy I/O.'
            Kernel      = @('ProcessThread','Loader','DiskIO','DiskIOInit','FileIO','FileIOInit','SplitIO')
            Stacks      = @()
            Providers   = @(
                @{ Match = '^Microsoft-Windows-Ntfs$'; Level = 4; Note = 'NTFS operational and performance events.' }
            )
        }
        SMB = @{
            Description = 'SMB server and client request processing, SMB Direct. Moderate volume.'
            Kernel      = @()
            Stacks      = @()
            Providers   = @(
                @{ Match = '^Microsoft-Windows-SMBServer$'; Level = 4; Note = 'Server-side SMB requests, credits, durable handles.' }
                @{ Match = '^Microsoft-Windows-SMBClient$'; Level = 4; Note = 'Client-side SMB requests and reconnects.' }
                @{ Match = '^Microsoft-Windows-SMBDirect$'; Level = 4; Note = 'RDMA (SMB Direct) connections.' }
            )
        }
        Network = @{
            Description = 'TCP/IP connection and retransmission events, NDIS, kernel network trace. High volume; use for short reproductions.'
            Kernel      = @('ProcessThread','NetworkTrace')
            Stacks      = @()
            Providers   = @(
                @{ Match = '^Microsoft-Windows-TCPIP$'; Level = 4; Note = 'Per-connection TCP events including retransmissions. Very high volume at 10G+.' }
                @{ Match = '^Microsoft-Windows-NDIS$'; Level = 4; Note = 'NDIS miniport and filter events.' }
            )
        }
        SAN = @{
            Description = 'Storport, class driver, iSCSI initiator and MPIO events: resets, timeouts, path failover.'
            Kernel      = @()
            Stacks      = @()
            Providers   = @(
                @{ Match = '^Microsoft-Windows-StorPort$'; Level = 4; Note = 'Storport adapter/device events, timeouts, resets, latency buckets.' }
                @{ Match = '(?i)ClassPnP|StorDiag'; Level = 4; Note = 'Disk class driver diagnostics.' }
                @{ Match = '(?i)iscsi'; Exclude = '(?i)target'; Level = 5; Note = 'iSCSI initiator providers (names vary by build).' }
                @{ Match = '(?i)mpio|msdsm'; Level = 5; Note = 'MPIO / Microsoft DSM providers (names vary by build).' }
            )
        }
        HyperV = @{
            Description = 'Hyper-V virtual storage and networking, CSV file system. Volume depends on VM count.'
            Kernel      = @()
            Stacks      = @()
            Providers   = @(
                @{ Match = '(?i)^Microsoft-Windows-Hyper-V-StorageVSP'; Level = 4; Note = 'Host virtual storage service provider.' }
                @{ Match = '(?i)^Microsoft-Windows-Hyper-V-VmSwitch$'; Level = 3; Note = 'Virtual switch. Level 3 only: level 4 logs per packet.' }
                @{ Match = '(?i)^Microsoft-Windows-Hyper-V-(Netvsc|StorVsc|Storvsp)'; Level = 4; Note = 'Guest-side synthetic NIC and storage drivers.' }
                @{ Match = '(?i)FailoverClustering-Csv'; Level = 4; Note = 'Cluster Shared Volume file system and filter.' }
            )
        }
        PktMonEvents = @{
            Description = 'EXPERIMENTAL: adds the PktMon provider to the WPR trace so packets land in the same ETL. Use with -PacketCapture. Validate in a lab first.'
            Kernel      = @()
            Stacks      = @()
            Providers   = @(
                @{ Match = '^Microsoft-Windows-PktMon$'; Level = 4; Note = 'Packet Monitor events.' }
            )
        }
    }
}
