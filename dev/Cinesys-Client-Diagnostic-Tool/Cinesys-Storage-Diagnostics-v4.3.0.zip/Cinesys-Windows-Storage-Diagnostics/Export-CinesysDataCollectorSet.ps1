﻿#requires -RunAsAdministrator
[CmdletBinding()]
param(
    [string]$DcsName = "Cinesys Storage Diagnostic",
    [string]$OutputPath = "$env:USERPROFILE\Desktop\Cinesys-Storage-Diagnostic-DCS.xml"
)

$ErrorActionPreference = "Stop"

Write-Host "=== logman query ===" -ForegroundColor Cyan
& logman.exe query $DcsName
if ($LASTEXITCODE -ne 0) { throw "Data Collector Set '$DcsName' is not registered." }

Write-Host ""
Write-Host "=== exporting native PLA XML ===" -ForegroundColor Cyan
# logman export does not accept -y; remove any previous export first.
Remove-Item $OutputPath -Force -ErrorAction SilentlyContinue
& logman.exe export $DcsName -xml $OutputPath
if ($LASTEXITCODE -ne 0) { throw "Failed to export '$DcsName'." }

Write-Host "Exported: $OutputPath" -ForegroundColor Green
Write-Host "Open Performance Monitor and inspect:"
Write-Host "  Data Collector Sets > User Defined > $DcsName"
Write-Host "  Reports > User Defined > $DcsName"
