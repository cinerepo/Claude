[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)][string]$CapturePath,
    # Stop-CinesysStorageDiagnostic.ps1 creates this file to end the poller.
    [Parameter(Mandatory=$true)][string]$StopFile,
    [int]$IntervalSeconds = 5,
    # Safety limit in case Stop is never run.
    [int]$MaxHours = 24
)
# Polls iSCSI session, MPIO path, CSV and physical NIC state during a capture.
# Launched by Start-CinesysStorageDiagnostic.ps1 as a separate hidden process.
#   Path-Health-Changes.csv  every state change (first sample recorded as Baseline)
#   Path-Health-Samples.csv  one row of totals per sample, for graphing
#   Path-Health-Status.json  process id, start, last sample, why it stopped
# Windows PowerShell 5.1, ASCII only.

$ErrorActionPreference = 'Continue'
$changesFile = Join-Path $CapturePath 'Path-Health-Changes.csv'
$samplesFile = Join-Path $CapturePath 'Path-Health-Samples.csv'
$statusFile = Join-Path $CapturePath 'Path-Health-Status.json'

$hasIscsi = [bool](Get-Command Get-IscsiSession -ErrorAction SilentlyContinue)
$hasMpclaim = [bool](Get-Command mpclaim.exe -ErrorAction SilentlyContinue)
$hasCsv = [bool](Get-Command Get-ClusterSharedVolumeState -ErrorAction SilentlyContinue)

$status = [ordered]@{ Pid = $PID; Started = (Get-Date).ToString('o'); IntervalSeconds = $IntervalSeconds; LastSample = $null; Samples = 0; Changes = 0; Stopped = $null; StopReason = $null; Errors = @() }
function Save-Status { $status | ConvertTo-Json | Set-Content -Path $statusFile -Encoding UTF8 }
Save-Status

function Get-MpclaimLines([string[]]$Arguments) {
    @(& mpclaim.exe @Arguments 2>&1 | ForEach-Object { if ($_ -is [System.Management.Automation.ErrorRecord]) { $_.Exception.Message } else { [string]$_ } })
}

function Get-HealthSample {
    # Returns a hashtable of "category|key" -> state string, plus totals.
    $state = @{}
    $totals = [ordered]@{ SessionsTotal = 0; SessionsConnected = 0; Connections = 0; PathsTotal = 0; PathsOptimized = 0; PathsUnoptimized = 0; PathsOther = 0; CsvNotDirect = 0; NicsDown = 0 }

    if ($hasIscsi) {
        try {
            foreach ($s in @(Get-IscsiSession -ErrorAction Stop)) {
                $tail = ([string]$s.TargetNodeAddress -split ':')[-1]
                $state["iSCSI session|$($s.SessionIdentifier)"] = "Connected=$($s.IsConnected); Connections=$($s.NumberOfConnections); Target=$tail; Initiator=$($s.InitiatorPortalAddress)"
                $totals.SessionsTotal++
                if ($s.IsConnected) { $totals.SessionsConnected++ }
                $totals.Connections += [int]$s.NumberOfConnections
            }
        } catch { $status.Errors = @($status.Errors | Select-Object -Last 20) + "iSCSI: $($_.Exception.Message)" }
    }

    if ($hasMpclaim) {
        try {
            foreach ($line in (Get-MpclaimLines @('-s','-d'))) {
                if ($line -notmatch '^\s*MPIO Disk(\d+)\s+Disk (\d+)') { continue }
                $mpio = $Matches[1]; $disk = $Matches[2]
                foreach ($l in (Get-MpclaimLines @('-s','-d',$mpio))) {
                    if ($l -match '^\s*([0-9a-fA-F]{8,16})\s+(\S+)\s+(\d+\|\d+\|\d+\|\d+)') {
                        $state["MPIO path|Disk$disk $($Matches[1]) ($($Matches[3]))"] = $Matches[2]
                        $totals.PathsTotal++
                        if ($Matches[2] -match '(?i)Active/Optimized') { $totals.PathsOptimized++ }
                        elseif ($Matches[2] -match '(?i)Active/Unoptimized') { $totals.PathsUnoptimized++ }
                        else { $totals.PathsOther++ }
                    }
                }
            }
        } catch { $status.Errors = @($status.Errors | Select-Object -Last 20) + "MPIO: $($_.Exception.Message)" }
    }

    if ($hasCsv) {
        try {
            foreach ($c in @(Get-ClusterSharedVolumeState -ErrorAction Stop)) {
                $state["CSV|$($c.Name) on $($c.Node)"] = "$($c.StateInfo); FS=$($c.FileSystemRedirectedIOReason); Block=$($c.BlockRedirectedIOReason)"
                if ([string]$c.StateInfo -ne 'Direct') { $totals.CsvNotDirect++ }
            }
        } catch { $status.Errors = @($status.Errors | Select-Object -Last 20) + "CSV: $($_.Exception.Message)" }
    }

    try {
        foreach ($n in @(Get-NetAdapter -Physical -ErrorAction Stop)) {
            $state["NIC|$($n.Name)"] = "$($n.Status) $($n.LinkSpeed)"
            if ([string]$n.Status -ne 'Up' -and [string]$n.Status -ne 'Disabled') { $totals.NicsDown++ }
        }
    } catch { $status.Errors = @($status.Errors | Select-Object -Last 20) + "NIC: $($_.Exception.Message)" }

    return @{ State = $state; Totals = $totals }
}

$previous = $null
$deadline = (Get-Date).AddHours($MaxHours)
while ($true) {
    if (Test-Path $StopFile) { $status.StopReason = 'Stop file'; break }
    if ((Get-Date) -gt $deadline) { $status.StopReason = "MaxHours ($MaxHours) reached"; break }

    $t0 = Get-Date
    $sample = Get-HealthSample
    $now = (Get-Date).ToString('o')
    $changes = @()
    if ($null -eq $previous) {
        foreach ($k in ($sample.State.Keys | Sort-Object)) {
            $p = $k -split '\|', 2
            $changes += [pscustomobject]@{ Time = $now; Category = $p[0]; Key = $p[1]; Before = '(baseline)'; After = $sample.State[$k] }
        }
    } else {
        foreach ($k in ($sample.State.Keys | Sort-Object)) {
            if (-not $previous.ContainsKey($k)) {
                $p = $k -split '\|', 2
                $changes += [pscustomobject]@{ Time = $now; Category = $p[0]; Key = $p[1]; Before = '(new)'; After = $sample.State[$k] }
            } elseif ($previous[$k] -ne $sample.State[$k]) {
                $p = $k -split '\|', 2
                $changes += [pscustomobject]@{ Time = $now; Category = $p[0]; Key = $p[1]; Before = $previous[$k]; After = $sample.State[$k] }
            }
        }
        foreach ($k in ($previous.Keys | Sort-Object)) {
            if (-not $sample.State.ContainsKey($k)) {
                $p = $k -split '\|', 2
                $changes += [pscustomobject]@{ Time = $now; Category = $p[0]; Key = $p[1]; Before = $previous[$k]; After = '(gone)' }
            }
        }
    }
    if ($changes.Count -gt 0) {
        $changes | Export-Csv -Path $changesFile -Append -NoTypeInformation -Encoding UTF8
        if ($null -ne $previous) { $status.Changes += $changes.Count }
    }
    $row = [ordered]@{ Time = $now }
    foreach ($k in $sample.Totals.Keys) { $row[$k] = $sample.Totals[$k] }
    $row['SampleMs'] = [int]((Get-Date) - $t0).TotalMilliseconds
    [pscustomobject]$row | Export-Csv -Path $samplesFile -Append -NoTypeInformation -Encoding UTF8

    $previous = $sample.State
    $status.LastSample = $now
    $status.Samples++
    Save-Status

    $sleepMs = ($IntervalSeconds * 1000) - [int]((Get-Date) - $t0).TotalMilliseconds
    # Sleep in short steps so the stop file is noticed quickly.
    while ($sleepMs -gt 0 -and -not (Test-Path $StopFile)) { Start-Sleep -Milliseconds ([math]::Min(500, $sleepMs)); $sleepMs -= 500 }
}
$status.Stopped = (Get-Date).ToString('o')
Save-Status
