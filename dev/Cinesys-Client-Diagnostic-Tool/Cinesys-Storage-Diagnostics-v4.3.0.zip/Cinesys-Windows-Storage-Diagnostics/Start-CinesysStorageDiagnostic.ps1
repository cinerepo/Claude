#requires -RunAsAdministrator
[CmdletBinding()]
param(
    [string]$Root = "C:\Cinesys\Storage-Diagnostic",
    [string]$PerfLogRoot = "$env:SystemDrive\PerfLogs\Admin\Cinesys Storage Diagnostic",
    [string]$DcsName = "Cinesys Storage Diagnostic",
    # ETW areas (Profiles\Cinesys-EtwCatalog.psd1). Combine as needed, e.g.
    # -TraceProfile General,Storage,SMB. BuiltIn = Windows' own GeneralProfile
    # (the v3.x trace). StorageDeep = General,Storage,SMB,Network.
    [ValidateSet("General","Storage","SMB","Network","SAN","HyperV","PktMonEvents","BuiltIn","StorageDeep")]
    [string[]]$TraceProfile = @("General","Storage"),
    # Packet Monitor: None (default), Counters (per-component packet and drop
    # counters, low overhead) or Headers (counters plus a header-only capture
    # filtered by role: SMB 445 and/or iSCSI 3260).
    [ValidateSet("None","Counters","Headers")]
    [string]$PacketCapture = "None",
    # Limit the Headers capture to traffic to/from these IP addresses.
    [string[]]$PacketFilterIp,
    # Extra hosts for the path MTU test (don't-fragment pings at 1500 and at
    # the adapter's MTU), e.g. Avid NEXIS engines. SMB servers, iSCSI portals,
    # NEXIS hosts with TCP connections and -PacketFilterIp are tested anyway.
    [string[]]$PathTestIp,
    [ValidateRange(64,9000)]
    [int]$PacketSize = 128,
    [ValidateRange(64,65535)]
    [int]$PacketFileSizeMB = 2048,
    [switch]$NoPcapConversion,
    # Adds \Per Processor Network Interface Card Activity(*). Useful for VMQ/RSS
    # per-core analysis, but produces cores x NICs instances on large hosts.
    [switch]$PerCoreNetworkCounters,
    # Take over an existing DCS with this name that does not carry the Cinesys
    # owner marker. Without this switch such a DCS is never modified.
    [switch]$AdoptExistingDcs,
    [switch]$NoEtw,
    # Seconds between iSCSI/MPIO/CSV/NIC state samples during the capture.
    [ValidateRange(1,300)]
    [int]$PathHealthIntervalSeconds = 5,
    [switch]$NoPathHealth
)

$ErrorActionPreference = "Stop"
Import-Module (Join-Path $PSScriptRoot 'Cinesys.Common.psm1') -Force
Import-Module (Join-Path $PSScriptRoot 'Cinesys.Trace.psm1') -Force
$traceAreas = @()
foreach ($t in $TraceProfile) {
    if ($t -eq 'StorageDeep') { $traceAreas += 'General','Storage','SMB','Network' } else { $traceAreas += $t }
}
$traceAreas = @($traceAreas | Select-Object -Unique)
$version = Get-CinesysVersion

New-Item -ItemType Directory -Force -Path $Root | Out-Null
New-Item -ItemType Directory -Force -Path $PerfLogRoot | Out-Null

$current = Join-Path $Root "CurrentCapture.json"
if (Test-Path $current) {
    throw "An active Cinesys capture is already registered at $current. Stop or cancel it first."
}

# The DCS is persistent by design. Each run gets a new output folder, but the
# User Defined Data Collector Set itself remains registered in Performance Monitor.
# Never modify a DCS with this name unless it belongs to this toolkit.
$ownership = Test-CinesysDcsOwnership -Name $DcsName -PerfLogRoot $PerfLogRoot
if ($ownership.Exists -and -not $ownership.Owned -and -not $AdoptExistingDcs) {
    throw "A Data Collector Set named '$DcsName' already exists but was not created by Cinesys ($($ownership.Reason)). Use -DcsName to choose another name, or -AdoptExistingDcs to take it over."
}
$dcsState = Get-DcsState -Name $DcsName
if ($dcsState.Exists -and $dcsState.Status -match '(?i)Running') {
    throw "The Data Collector Set '$DcsName' is already running. Stop it before starting another capture."
}

$stamp = Get-Date -Format "yyyyMMdd-HHmmss"
# PLA creates the run folder (<COMPUTER>_yyyyMMdd-NNNNNN under PerfLogRoot) when
# the DCS starts; that is what keeps every run listed under Performance Monitor
# > Reports. Until then the manifest, metadata and counter lists are written to
# a staging folder and moved into the run folder once PLA has created it.
$staging = Join-Path $Root ("Staging\" + $env:COMPUTERNAME + "_" + $stamp)
New-Item -ItemType Directory -Force -Path $staging | Out-Null
$capture = $staging

$manifest = New-CinesysManifest -CapturePath $capture -Properties @{
    TraceProfile           = ($traceAreas -join ',')
    PacketCapture          = $PacketCapture
    PacketFilterIp         = @($PacketFilterIp)
    PathTestIp             = @($PathTestIp)
    PerfMonIntervalSeconds = 1
    DcsName                = $DcsName
    PerfLogRoot            = $PerfLogRoot
    PerCoreNetworkCounters = [bool]$PerCoreNetworkCounters
    NoEtw                  = [bool]$NoEtw
    PathHealthIntervalSeconds = $(if ($NoPathHealth) { $null } else { $PathHealthIntervalSeconds })
}
$manifest.Dcs.Name = $DcsName
$manifest.Dcs.Ownership = $ownership.Reason

# Capture-Metadata.txt is kept for older tooling; Capture-Manifest.json is the
# authoritative record from v3.9 on.
$metadata = Join-Path $capture "Capture-Metadata.txt"
@"
Version=$version
Host=$env:COMPUTERNAME
Started=$(Get-CinesysTimestamp)
TraceProfile=$($traceAreas -join ',')
CapturePath=$capture
PerfMonIntervalSeconds=1
DcsName=$DcsName
PersistentDcs=True
NativePerfMonRoot=$PerfLogRoot
"@ | Set-Content $metadata

function Save-State { Save-CinesysManifest -CapturePath $capture -Manifest $manifest }

# Any terminating error from here on is recorded in the manifest before it
# propagates, so a failed start is never left looking like "Starting".
trap {
    if ($manifest) {
        if (Test-Path $current) { $manifest.Status = 'StartIncomplete' } else { $manifest.Status = 'FailedToStart' }
        Add-CinesysManifestEvent -Manifest $manifest -Step 'Start' -Result 'TerminatingError' -Detail $_.Exception.Message
        Save-CinesysManifest -CapturePath $capture -Manifest $manifest
    }
    break
}

# ---------------------------------------------------------------------------
# Counter list. Optional platform-specific counters are discovered below.
# ---------------------------------------------------------------------------
$core = @(
'\PhysicalDisk(*)\Disk Read Bytes/sec','\PhysicalDisk(*)\Disk Write Bytes/sec','\PhysicalDisk(*)\Disk Reads/sec','\PhysicalDisk(*)\Disk Writes/sec',
'\PhysicalDisk(*)\Avg. Disk sec/Read','\PhysicalDisk(*)\Avg. Disk sec/Write','\PhysicalDisk(*)\Current Disk Queue Length','\PhysicalDisk(*)\Avg. Disk Read Queue Length','\PhysicalDisk(*)\Avg. Disk Write Queue Length','\PhysicalDisk(*)\Avg. Disk Bytes/Read','\PhysicalDisk(*)\Avg. Disk Bytes/Write',
'\LogicalDisk(*)\Disk Read Bytes/sec','\LogicalDisk(*)\Disk Write Bytes/sec','\LogicalDisk(*)\Avg. Disk sec/Read','\LogicalDisk(*)\Avg. Disk sec/Write','\LogicalDisk(*)\Current Disk Queue Length',
'\Process(*)\IO Read Bytes/sec','\Process(*)\IO Write Bytes/sec','\Process(*)\IO Data Bytes/sec','\Process(*)\IO Read Operations/sec','\Process(*)\IO Write Operations/sec','\Process(*)\% Processor Time',
'\Processor Information(*)\% Processor Utility','\Processor Information(*)\% Processor Time','\Processor Information(*)\% Privileged Time','\Processor Information(*)\% User Time','\Processor Information(*)\% DPC Time','\Processor Information(*)\% Interrupt Time','\Processor Information(*)\Interrupts/sec',
'\System\Processor Queue Length','\System\Context Switches/sec','\System\System Calls/sec',
'\Memory\Available MBytes','\Memory\% Committed Bytes In Use','\Memory\Committed Bytes','\Memory\Pages/sec','\Memory\Page Reads/sec','\Memory\Page Writes/sec','\Memory\Cache Bytes','\Memory\Pool Paged Bytes','\Memory\Pool Nonpaged Bytes',
# Cache Manager write-behind. Dirty Pages approaching Dirty Page Threshold means
# the cache manager is about to throttle writers (the SMB "sawtooth" pattern).
'\Memory\Modified Page List Bytes',
'\Cache\Dirty Pages','\Cache\Dirty Page Threshold','\Cache\Lazy Write Flushes/sec','\Cache\Lazy Write Pages/sec','\Cache\Data Flushes/sec','\Cache\Data Flush Pages/sec',
'\Network Interface(*)\Bytes Sent/sec','\Network Interface(*)\Bytes Received/sec','\Network Interface(*)\Bytes Total/sec','\Network Interface(*)\Packets Sent/sec','\Network Interface(*)\Packets Received/sec','\Network Interface(*)\Packets Outbound Errors','\Network Interface(*)\Packets Received Errors','\Network Interface(*)\Packets Outbound Discarded','\Network Interface(*)\Packets Received Discarded',
# Sent/Received are needed to turn retransmits into a percentage.
'\TCPv4\Segments/sec','\TCPv4\Segments Sent/sec','\TCPv4\Segments Received/sec','\TCPv4\Segments Retransmitted/sec','\TCPv4\Connections Established','\TCPv4\Connections Reset','\TCPv4\Connection Failures',
'\TCPv6\Segments/sec','\TCPv6\Segments Sent/sec','\TCPv6\Segments Retransmitted/sec',
# UDP and IP fragments: Avid NEXIS moves file data over UDP, which no SMB
# counter shows; receive errors and failed reassembly are how it loses data.
'\UDPv4\Datagrams Received/sec','\UDPv4\Datagrams Sent/sec','\UDPv4\Datagrams No Port/sec','\UDPv4\Datagrams Received Errors',
'\IPv4\Datagrams Received/sec','\IPv4\Datagrams Received Discarded','\IPv4\Fragments Received/sec','\IPv4\Fragment Re-assembly Failures','\IPv4\Fragmented Datagrams/sec',
'\SMB Client Shares(*)\Data Bytes/sec','\SMB Client Shares(*)\Read Bytes/sec','\SMB Client Shares(*)\Write Bytes/sec','\SMB Client Shares(*)\Avg. sec/Data Request','\SMB Client Shares(*)\Avg. sec/Read','\SMB Client Shares(*)\Avg. sec/Write','\SMB Client Shares(*)\Current Data Queue Length',
'\SMB Server Shares(*)\Data Bytes/sec','\SMB Server Shares(*)\Read Bytes/sec','\SMB Server Shares(*)\Write Bytes/sec','\SMB Server Shares(*)\Avg. sec/Data Request','\SMB Server Shares(*)\Avg. sec/Read','\SMB Server Shares(*)\Avg. sec/Write','\SMB Server Shares(*)\Current Data Queue Length',
'\SMB Server\*',
'\SMB Server Sessions(*)\Write Bytes/sec','\SMB Server Sessions(*)\Read Bytes/sec','\SMB Server Sessions(*)\Avg. sec/Write','\SMB Server Sessions(*)\Avg. sec/Read','\SMB Server Sessions(*)\Current Data Queue Length',
'\SMB Direct Connection(*)\RDMA Read Bytes/sec','\SMB Direct Connection(*)\RDMA Write Bytes/sec',
# Hyper-V virtual networking (host only; skipped elsewhere).
'\Hyper-V Virtual Switch(*)\Bytes Received/sec','\Hyper-V Virtual Switch(*)\Bytes Sent/sec','\Hyper-V Virtual Switch(*)\Dropped Packets Incoming/sec','\Hyper-V Virtual Switch(*)\Dropped Packets Outgoing/sec',
'\Hyper-V Virtual Network Adapter(*)\Bytes Received/sec','\Hyper-V Virtual Network Adapter(*)\Bytes Sent/sec','\Hyper-V Virtual Network Adapter(*)\Dropped Packets Incoming/sec','\Hyper-V Virtual Network Adapter(*)\Dropped Packets Outgoing/sec'
)
if ($PerCoreNetworkCounters) {
    $core += '\Per Processor Network Interface Card Activity(*)\DPCs Queued/sec','\Per Processor Network Interface Card Activity(*)\Interrupts/sec','\Per Processor Network Interface Card Activity(*)\Received Packets/sec','\Per Processor Network Interface Card Activity(*)\Received Bytes/sec'
}

# Validate every counter against one ListSet query. v3.8 called Get-Counter once
# per counter, which delayed the PerfMon start by a minute or more.
$valid = New-Object System.Collections.Generic.List[string]
$discovery = New-Object System.Collections.Generic.List[string]
$sets = @()
try { $sets = @(Get-Counter -ListSet * -ErrorAction SilentlyContinue) } catch {}
$knownPaths = New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
$knownSets = New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
foreach ($set in $sets) {
    [void]$knownSets.Add([string]$set.CounterSetName)
    foreach ($p in @($set.Paths) + @($set.PathsWithInstances)) { if ($p) { [void]$knownPaths.Add([string]$p) } }
}
foreach ($c in $core) {
    $ok = $false
    if ($c -match '^\\([^\\(]+)(\([^)]*\))?\\\*$') { $ok = $knownSets.Contains($Matches[1]) }
    else { $ok = $knownPaths.Contains($c) }
    if ($ok) { $valid.Add($c); $discovery.Add("INCLUDED`t$c") } else { $discovery.Add("SKIPPED`t$c") }
}

# Counter sets installed by the Avid NEXIS client (names vary by version):
# every counter in them is included.
foreach ($set in @($sets | Where-Object { $_.CounterSetName -match '(?i)avid|nexis|isis' })) {
    foreach ($c in @($set.PathsWithInstances) + @($set.Paths)) {
        if ($c -and -not $valid.Contains($c)) { $valid.Add($c); $discovery.Add("DISCOVERED`t$c") }
    }
}

# Discover useful CSV/cluster and Hyper-V storage counters exposed by this OS.
$optionalSets = $sets | Where-Object { $_.CounterSetName -match '(?i)cluster.*csv|csv|hyper-v.*(storage|virtual storage|virtual machine)' }
foreach ($set in $optionalSets) {
    foreach ($c in $set.PathsWithInstances) {
        if ($c -match '(?i)read|write|byte|i/o|io |latency|queue|redirect|flush|operation') {
            if (-not $valid.Contains($c)) { $valid.Add($c); $discovery.Add("DISCOVERED`t$c") }
        }
    }
}

$counterFile = Join-Path $capture "PerfMon-Counters.txt"
$valid | Set-Content $counterFile
$discovery | Set-Content (Join-Path $capture "PerfMon-Counter-Discovery.txt")
if ($valid.Count -eq 0) { throw "No PerfMon counters were valid on this host." }
$manifest.Collectors.PerfMon.CounterCount = $valid.Count

# ---------------------------------------------------------------------------
# Register or update ONE persistent Data Collector Set.
# ---------------------------------------------------------------------------
# No -o: the output file name and folder layout are set through PLA below
# (Set-CinesysDcsCaptureSettings), so the BLG lands in the PLA-created run folder.
$logmanCommon = @('-cf',$counterFile,'-si','00:00:01','-f','bin')
if ($dcsState.Exists) {
    $r = Invoke-Logman -Arguments (@('update','counter',$DcsName) + $logmanCommon)
    if ($r.ExitCode -ne 0) { throw "Failed to update persistent PerfMon collector '$DcsName'. $($r.Output)" }
    $dcsAction = 'Updated'
} else {
    $r = Invoke-Logman -Arguments (@('create','counter',$DcsName) + $logmanCommon + @('-y'))
    if ($r.ExitCode -ne 0) { throw "Failed to create persistent PerfMon collector '$DcsName'. $($r.Output)" }
    $dcsAction = 'Created'
}
$manifest.Dcs.Action = $dcsAction

# Add/refresh native PLA ConfigurationDataCollector objects. These show up
# directly beneath the User Defined DCS in Performance Monitor.
$plaConfigurator = Join-Path $PSScriptRoot "PLA\Configure-CinesysPlaCollectors.ps1"
$plaDefinitions = Join-Path $PSScriptRoot "PLA\Cinesys-ConfigurationCollectors.xml"
if (!(Test-Path $plaConfigurator)) { throw "PLA configurator is missing: $plaConfigurator" }
& $plaConfigurator -DcsName $DcsName -DefinitionPath $plaDefinitions
"PlaConfigurationCollectors=True" | Add-Content $metadata

# Enable the native Windows PLA DataManager report pipeline.
$dataManagerConfigurator = Join-Path $PSScriptRoot "PLA\Configure-CinesysDataManager.ps1"
if (!(Test-Path $dataManagerConfigurator)) { throw "PLA DataManager configurator is missing: $dataManagerConfigurator" }
& $dataManagerConfigurator -DcsName $DcsName
"PlaDataManager=True" | Add-Content $metadata

# Stamp ownership and clear any stop condition left on the persistent DCS.
# Some v3.8 captures stopped recording after ~10 minutes while the capture
# ran for ~20; the previous values are recorded to confirm the cause.
$settings = Set-CinesysDcsCaptureSettings -Name $DcsName -PerfLogRoot $PerfLogRoot
$manifest.Dcs.PreviousSettings = $settings.Previous
$manifest.Dcs.ValidationMessages = @($settings.ValidationMessages)
$prev = $settings.Previous
# SchedulesEnabled=True with no schedules is the Windows default and stops nothing.
if ($prev.Duration -gt 0 -or $prev.Segment -or $prev.SegmentMaxDuration -gt 0 -or $prev.SegmentMaxSize -gt 0 -or ($prev.SchedulesEnabled -and $prev.ScheduleCount -gt 0)) {
    Add-CinesysManifestWarning -Manifest $manifest -Message ("The persistent DCS had a stop/segment condition (Duration=$($prev.Duration)s, Segment=$($prev.Segment), SegmentMaxDuration=$($prev.SegmentMaxDuration)s, SegmentMaxSize=$($prev.SegmentMaxSize)MB, Schedules=$($prev.ScheduleCount)). It was cleared for this capture; earlier captures may be truncated.")
}
foreach ($cc in $prev.CounterCollectors) {
    if ($cc.SegmentMaxRecords -gt 0 -or $cc.LogCircular) {
        Add-CinesysManifestWarning -Manifest $manifest -Message "Counter collector '$($cc.Name)' had SegmentMaxRecords=$($cc.SegmentMaxRecords), LogCircular=$($cc.LogCircular). Cleared for this capture."
    }
}
Save-State

# Export the native PLA/DCS definition for inspection and versioning.
# logman export does not accept -y, so remove any stale file first.
$dcsXml = Join-Path $staging "Cinesys-DCS.xml"
Remove-Item $dcsXml -Force -ErrorAction SilentlyContinue
$export = Invoke-Logman -Arguments @('export',$DcsName,'-xml',$dcsXml)
if ($export.ExitCode -ne 0) {
    "DcsExportError=$($export.Output -replace '[\r\n]+',' ')" | Add-Content $metadata
    Add-CinesysManifestEvent -Manifest $manifest -Step 'DcsExport' -Result 'Failed' -Detail $export.Output
}

# ---------------------------------------------------------------------------
# Start PerfMon first, then ETW, then take the pre-capture snapshot while both
# are already recording. In v3.8 the snapshot ran first and delayed PerfMon.
# ---------------------------------------------------------------------------
$startRequestedAt = Get-Date
$manifest.Collectors.PerfMon.StartRequested = Get-CinesysTimestamp
$start = Invoke-Logman -Arguments @('start',$DcsName)
if ($start.ExitCode -ne 0) {
    $manifest.Collectors.PerfMon.Error = $start.Output
    $manifest.Status = 'FailedToStart'
    Save-State
    throw "Failed to start persistent PerfMon collector '$DcsName'. $($start.Output)"
}
$running = Wait-DcsStatus -Name $DcsName -Status 'Running' -TimeoutSeconds 20
if ($running.Status -match '(?i)Running') {
    $manifest.Collectors.PerfMon.StartConfirmed = Get-CinesysTimestamp
} else {
    Add-CinesysManifestWarning -Manifest $manifest -Message "PerfMon start was requested but the DCS reports '$($running.Status)' after 20 seconds."
}
"PerfMonStarted=$($manifest.Collectors.PerfMon.StartConfirmed)" | Add-Content $metadata

# Move everything staged so far into the run folder PLA just created.
$runFolder = Get-CinesysRunFolder -Name $DcsName -PerfLogRoot $PerfLogRoot -NotBefore $startRequestedAt
if ($runFolder) {
    $capture = $runFolder.Path
    Get-ChildItem $staging -File | ForEach-Object { Copy-Item $_.FullName (Join-Path $capture $_.Name) -Force }
    $metadata = Join-Path $capture "Capture-Metadata.txt"
    (Get-Content $metadata) -replace '^CapturePath=.*$', "CapturePath=$capture" | Set-Content $metadata
    $manifest.CapturePath = $capture
    Add-CinesysManifestEvent -Manifest $manifest -Step 'RunFolder' -Result $runFolder.Source -Detail $capture
    Save-State
    Remove-Item $staging -Recurse -Force -ErrorAction SilentlyContinue
} else {
    # PerfMon is running, so keep going; Cinesys files stay in the staging folder.
    Add-CinesysManifestWarning -Manifest $manifest -Message "Could not determine the PLA run folder under $PerfLogRoot. Cinesys files were kept in $staging; the BLG and PLA files are in the PLA run folder."
    Save-State
}

# Register state immediately after PerfMon starts so an ETW or snapshot failure
# cannot orphan a running data collector.
$state = [ordered]@{
    ToolVersion     = $version
    CapturePath     = $capture
    DcsName         = $DcsName
    PerfMonStarted  = $true
    PersistentDcs   = $true
    WprStarted      = $false
    WprProfiles     = @()
    WprInstanceName = $null
    PathHealthPid   = $null
    PathHealthProcessStart = $null
    PathHealthStopFile = $null
    Started         = Get-CinesysTimestamp
}
$state | ConvertTo-Json | Set-Content $current
$manifest.Status = 'Running'
Save-State

# ETW is optional. PerfMon and state capture continue if WPR is unavailable.
$etw = $manifest.Collectors.ETW
if ($NoEtw) {
    $etw.Requested = $false
    $etw.Fallback = 'ETW skipped by -NoEtw; PerfMon and state capture only.'
} elseif (-not (Get-Command wpr.exe -ErrorAction SilentlyContinue)) {
    $etw.Error = 'wpr.exe was not found on this host.'
    $etw.Fallback = 'PerfMon and state capture only.'
} else {
    $status = Invoke-Wpr -Arguments @('-status')
    if ($status.ExitCode -eq 0 -and $status.Output -notmatch '(?i)not recording|no recording') {
        # Never touch a recording that Cinesys did not start.
        $etw.Error = 'WPR reports an existing recording that was not started by Cinesys. It was left untouched.'
        $etw.Fallback = 'PerfMon and state capture only.'
        $etw.StartOutput = $status.Output
    } else {
        try {
            # Built-in GeneralProfile: what v3.x recorded, and the last resort below.
            $builtInArgs = @('-start','GeneralProfile')
            $attempts = @()
            $named = Test-WprInstanceNameSupport
            $customAreas = @($traceAreas | Where-Object { $_ -ne 'BuiltIn' })
            if ($customAreas.Count) {
                $catalog = Get-CinesysEtwCatalog
                $resolved = Resolve-CinesysEtwAreas -Areas $customAreas -Catalog $catalog -Registered (Get-CinesysRegisteredProviders)
                $resolved | Export-Csv -Path (Join-Path $capture 'Etw-Providers.csv') -NoTypeInformation -Encoding UTF8
                $wprp = New-CinesysWprProfile -Areas $customAreas -Catalog $catalog -Resolved $resolved -OutputFile (Join-Path $capture 'Cinesys-Trace-Profile.wprp')
                $etw.Profiles = @($customAreas)
                $etw.ProfileFile = Split-Path $wprp.Path -Leaf
                $etw.ProviderSummary = "kernel: $(@($wprp.Kernel) -join ', '); event providers: $($wprp.ProviderCount); not registered: $(@($resolved | Where-Object { $_.Status -eq 'NotRegistered' }).Count)"
                # File mode: memory mode is a circular buffer and loses the start of long captures.
                $customArgs = @('-start', "$($wprp.Path)!Cinesys", '-filemode')
                if ($named) { $attempts += ,@{ Args = $customArgs + @('-instancename', (Get-CinesysWprInstanceName)); InstanceName = (Get-CinesysWprInstanceName); Mode = 'Cinesys profile, file, named instance' } }
                $attempts += ,@{ Args = $customArgs; InstanceName = $null; Mode = 'Cinesys profile, file, default instance' }
            } else {
                $etw.Profiles = @('GeneralProfile')
                if ($named) { $attempts += ,@{ Args = $builtInArgs + @('-filemode', '-instancename', (Get-CinesysWprInstanceName)); InstanceName = (Get-CinesysWprInstanceName); Mode = 'GeneralProfile, file, named instance' } }
            }
            # WPR rejected GeneralProfile under -instancename in memory mode on
            # Windows 11 26100 (0x80070032), so the final fallback is the plain v3.x form.
            $attempts += ,@{ Args = $builtInArgs; InstanceName = $null; Mode = 'GeneralProfile, memory, default instance (fallback)' }
            $etw.StartRequested = Get-CinesysTimestamp
            foreach ($a in $attempts) {
                $r = Invoke-Wpr -Arguments $a.Args
                Add-CinesysManifestEvent -Manifest $manifest -Step 'WprStart' -Result "Exit $($r.ExitCode)" -Detail "$($a.Mode): $($r.Command)`r`n$($r.Output)"
                $etw.StartCommand = $r.Command
                $etw.StartExitCode = $r.ExitCode
                $etw.StartOutput = $r.Output
                if ($r.ExitCode -eq 0) {
                    $etw.Started = $true
                    $etw.InstanceName = $a.InstanceName
                    $etw.Mode = $a.Mode
                    $etw.StartConfirmed = Get-CinesysTimestamp
                    if ($a -ne $attempts[0]) { $etw.Fallback = "Started in fallback mode: $($a.Mode)." }
                    if ($a.Mode -like 'GeneralProfile*' -and $customAreas.Count) {
                        $etw.Profiles = @('GeneralProfile')
                        Add-CinesysManifestWarning -Manifest $manifest -Message "WPR rejected the Cinesys trace profile ($($customAreas -join ', ')); the built-in GeneralProfile was recorded instead. See the WprStart events in the manifest."
                    }
                    break
                }
                # Clear whatever this attempt may have left before trying the next one.
                $cancelArgs = @('-cancel')
                if ($a.InstanceName) { $cancelArgs += @('-instancename', $a.InstanceName) }
                Invoke-Wpr -Arguments $cancelArgs | Out-Null
            }
            if (-not $etw.Started) {
                $etw.Error = "WPR failed to start in every mode tried (last exit code $($etw.StartExitCode)). See Events for each attempt."
                $etw.Fallback = 'PerfMon and state capture only.'
            }
        } catch {
            $etw.Error = $_.Exception.Message
            $etw.Fallback = 'PerfMon and state capture only.'
        }
    }
}
"ETWRequested=$($etw.Requested)" | Add-Content $metadata
"ETWStarted=$($etw.Started)" | Add-Content $metadata
"WPRProfiles=$(@($etw.Profiles) -join ',')" | Add-Content $metadata
if ($etw.Error) { "ETWError=$($etw.Error -replace '[\r\n]+',' ')" | Add-Content $metadata }

# Packet Monitor. Off unless -PacketCapture is given. Never touches a pktmon
# session or filters that Cinesys did not create.
$pc = $manifest.Collectors.PacketCapture
$pc.Mode = $PacketCapture
if ($PacketCapture -ne 'None') {
    try {
        $info = Get-CinesysPktMonInfo
        $pc.Syntax = $info.Syntax
        if (-not $info.Available) { $pc.Error = 'pktmon.exe is not available on this Windows build.' }
        elseif ($info.Running) { $pc.Error = 'Packet Monitor is already running (not started by Cinesys). It was left untouched.'; $pc.Output = $info.StatusOutput }
        elseif ($info.HasFilters) { $pc.Error = 'Packet Monitor already has filters configured (not by Cinesys). They were left untouched and no capture was started.'; $pc.Output = $info.FilterOutput }
        elseif ($PacketCapture -eq 'Counters' -and $info.Syntax -ne 'Modern') { $pc.Error = "Counters-only mode needs the newer pktmon (this build: $($info.Syntax))." }
        else {
            $plan = Get-CinesysPacketFilterPlan -Roles @($manifest.Roles) -Ip $PacketFilterIp
            $pc.StartRequested = Get-CinesysTimestamp
            $r = Start-CinesysPktMon -Mode $PacketCapture -CapturePath $capture -Info $info -FilterPlan $plan -PacketSize $PacketSize -FileSizeMB $PacketFileSizeMB
            $pc.Filters = @($r.Filters)
            $pc.Commands = @($r.Commands | ForEach-Object { "$($_.Command) => exit $($_.ExitCode)" })
            $pc.EtlFile = $(if ($r.EtlFile) { Split-Path $r.EtlFile -Leaf } else { $null })
            if ($r.Started) {
                $pc.Started = $true
                $pc.StartConfirmed = Get-CinesysTimestamp
            } else {
                $pc.Error = $r.Error
                # Remove any filters this attempt added.
                if (@($r.Filters).Count) { Invoke-TraceTool -Exe 'pktmon.exe' -Arguments @('filter','remove') | Out-Null }
            }
        }
    } catch { $pc.Error = $_.Exception.Message }
}

$state.WprStarted = [bool]$etw.Started
$state.WprProfiles = @($etw.Profiles)
$state.WprInstanceName = $etw.InstanceName
$state.PktMonStarted = [bool]$pc.Started
$state.PktMonMode = $PacketCapture
$state.PktMonSyntax = $pc.Syntax
$state.PktMonEtl = $(if ($pc.EtlFile) { Join-Path $capture $pc.EtlFile } else { $null })
$state.PktMonFilters = [bool](@($pc.Filters).Count)
$state.NoPcapConversion = [bool]$NoPcapConversion
$state | ConvertTo-Json | Set-Content $current
Save-State

# Path-health poller: iSCSI/MPIO/CSV/NIC state every few seconds for the whole
# capture, in its own process. Failure here is recorded, not fatal.
$ph = $manifest.Collectors.PathHealth
if (-not $NoPathHealth) {
    try {
        $w = Start-CinesysPathHealth -CapturePath $capture -IntervalSeconds $PathHealthIntervalSeconds
        $ph.Started = $true; $ph.Pid = $w.Pid; $ph.ProcessStart = $w.ProcessStart; $ph.StopFile = $w.StopFile
        $ph.Command = $w.Command; $ph.IntervalSeconds = $PathHealthIntervalSeconds
        $state.PathHealthPid = $w.Pid; $state.PathHealthProcessStart = $w.ProcessStart; $state.PathHealthStopFile = $w.StopFile
        $state | ConvertTo-Json | Set-Content $current
    } catch { $ph.Error = $_.Exception.Message }
}
Save-State

# Pre-capture state snapshot. Failure here is recorded, not fatal.
$snapshot = Join-Path $PSScriptRoot "Snapshot-State.ps1"
if (Test-Path $snapshot) {
    $manifest.Collectors.PreSnapshot.Started = Get-CinesysTimestamp
    try {
        & $snapshot -OutputFile (Join-Path $capture "PreCapture-State.txt") -EventsSince (Get-Date).AddHours(-4) -EventsFile (Join-Path $capture "Storage-Events-Pre.csv")
    } catch {
        $manifest.Collectors.PreSnapshot.Error = $_.Exception.Message
    }
    $manifest.Collectors.PreSnapshot.Completed = Get-CinesysTimestamp
}
Save-State

# Topology map (share/VM/vSwitch/VHDX/CSV/MPIO/iSCSI). Failure is recorded, not fatal.
$topology = Join-Path $PSScriptRoot "Get-CinesysTopology.ps1"
if (Test-Path $topology) {
    $manifest.Collectors.Topology.PreStarted = Get-CinesysTimestamp
    $pathIps = @(@($PathTestIp) + @($PacketFilterIp) | Where-Object { $_ } | Select-Object -Unique)
    try { & $topology -OutputPath $capture -Label 'Pre' -PathTestIp $pathIps } catch { $manifest.Collectors.Topology.PreError = $_.Exception.Message }
    $manifest.Collectors.Topology.PreCompleted = Get-CinesysTimestamp
}
Save-State

Write-Host ""
Write-Host "Cinesys Storage Diagnostics v$version started." -ForegroundColor Green
Write-Host "Capture: $capture"
Write-Host "PerfMon DCS: $DcsName ($dcsAction; persistent)"
Write-Host "PerfMon: unified 1-second collector ($($valid.Count) counters), recording since $($manifest.Collectors.PerfMon.StartConfirmed)"
if ($etw.Started) { Write-Host "ETW/WPR: running ($(@($etw.Profiles) -join ', '); $($etw.Mode))" -ForegroundColor Green }
else { Write-Warning "ETW/WPR not running. $($etw.Error) $($etw.Fallback)" }
if ($pc.Started) { Write-Host "Packet Monitor: $($pc.Mode) ($(@($pc.Filters | ForEach-Object { "TCP $($_.Port)$(if ($_.Ip) { " $($_.Ip)" })" }) -join ', '))" -ForegroundColor Green }
elseif ($PacketCapture -ne 'None') { Write-Warning "Packet Monitor not running. $($pc.Error)" }
if ($ph.Started) { Write-Host "Path health: polling every $($ph.IntervalSeconds) s (pid $($ph.Pid))" -ForegroundColor Green }
elseif (-not $NoPathHealth) { Write-Warning "Path-health poller did not start. $($ph.Error)" }
$topoTxt = Join-Path $capture 'Topology-Pre.txt'
if (Test-Path $topoTxt) {
    $topoFindings = @(Get-Content $topoTxt | Where-Object { $_ -match '^\s+\[(Warning|Notice)\]' })
    Write-Host "Topology: $topoTxt ($($topoFindings.Count) finding(s))"
}
foreach ($w in @($manifest.Warnings)) { Write-Warning $w }
Write-Host ""
Write-Host "Ready. Reproduce the issue, then run Stop-CinesysStorageDiagnostic.ps1." -ForegroundColor Green
