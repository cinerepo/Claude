#requires -RunAsAdministrator
[CmdletBinding(SupportsShouldProcess=$true, ConfirmImpact='High')]
param(
    [string]$DcsName = "Cinesys Storage Diagnostic",
    [string]$PerfLogRoot = "$env:SystemDrive\PerfLogs\Admin\Cinesys Storage Diagnostic",
    # Delete a DCS with this name even if it does not look like a Cinesys DCS.
    [switch]$Force
)

$ErrorActionPreference = "Stop"
Import-Module (Join-Path $PSScriptRoot 'Cinesys.Common.psm1') -Force

$s = Get-DcsState -Name $DcsName
if (-not $s.Exists) {
    Write-Host "Data Collector Set '$DcsName' is not registered."
    return
}
if ($s.Status -match '(?i)Running') {
    throw "Data Collector Set '$DcsName' is running. Stop or cancel the active capture before removing it."
}
$ownership = Test-CinesysDcsOwnership -Name $DcsName -PerfLogRoot $PerfLogRoot
if (-not $ownership.Owned -and -not $Force) {
    throw "Data Collector Set '$DcsName' was not created by Cinesys ($($ownership.Reason)). Re-run with -Force to delete it anyway."
}

if ($PSCmdlet.ShouldProcess($DcsName, "Delete persistent Performance Monitor Data Collector Set")) {
    $r = Invoke-Logman -Arguments @('delete', $DcsName)
    if ($r.ExitCode -ne 0) { throw "logman delete failed for '$DcsName'. $($r.Output)" }
    Write-Host "Deleted Data Collector Set '$DcsName'. Capture folders under PerfLogs were not touched." -ForegroundColor Yellow
}
