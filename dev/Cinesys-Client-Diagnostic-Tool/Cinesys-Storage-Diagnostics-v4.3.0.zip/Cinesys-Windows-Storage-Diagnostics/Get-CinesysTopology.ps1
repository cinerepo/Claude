[CmdletBinding()]
param(
    # Folder to write Topology-<Label>.json and Topology-<Label>.txt into.
    [Parameter(Mandatory=$true)][string]$OutputPath,
    [string]$Label = 'Pre',
    # Extra hosts for the path MTU test (for example Avid NEXIS engines,
    # which send data over UDP and so are not found from TCP connections).
    [string[]]$PathTestIp,
    [switch]$NoPathMtuTest
)
# Maps the storage and network path of this machine:
#   SMB share -> volume -> disk
#   VM vNIC -> vSwitch -> physical uplinks (with PerfMon instance names)
#   VM disk -> VHDX -> CSV -> physical disk -> MPIO paths -> iSCSI session ->
#   source NIC -> target portal
# Every query is optional; a role that is not present (no Hyper-V, no cluster,
# no iSCSI) just leaves its section empty. Windows PowerShell 5.1, ASCII only.

$ErrorActionPreference = 'Continue'
New-Item -ItemType Directory -Force -Path $OutputPath | Out-Null
$script:Errors = New-Object System.Collections.Generic.List[string]
$script:Findings = New-Object System.Collections.Generic.List[object]

function Invoke-Safe {
    param([string]$What, [scriptblock]$Block)
    try { & $Block } catch { $script:Errors.Add("${What}: $($_.Exception.Message)"); $null }
}
function Add-Finding {
    param([string]$Severity, [string]$Area, [string]$Message)
    $script:Findings.Add([pscustomobject]@{ Severity = $Severity; Area = $Area; Message = $Message })
}
function Has-Command([string]$Name) { [bool](Get-Command $Name -ErrorAction SilentlyContinue) }
function Get-NativeLines {
    param([string]$Exe, [string[]]$Arguments)
    $ErrorActionPreference = 'Continue'
    @(& $Exe @Arguments 2>&1 | ForEach-Object { if ($_ -is [System.Management.Automation.ErrorRecord]) { $_.Exception.Message } else { [string]$_ } })
}
# PerfMon "Network Interface" instance names replace ( ) # / in the adapter description.
function Get-PerfMonNicName([string]$Description) {
    if (-not $Description) { return $null }
    $Description.Replace('(','[').Replace(')',']').Replace('#','_').Replace('/','_')
}

$topo = [ordered]@{
    Generated  = (Get-Date).ToString('o')
    Computer   = $env:COMPUTERNAME
    Label      = $Label
    Nics       = @()
    VSwitches  = @()
    VmNics     = @()
    Vms        = @()
    VmDisks    = @()
    Csvs       = @()
    Disks      = @()
    Mpio       = @()
    Iscsi      = [ordered]@{ Sessions = @(); TargetPortals = @(); NicUsage = @() }
    SmbShares  = @()
    NetworkQos = [ordered]@{}
    PathMtu    = @()
    AvidNexis  = [ordered]@{ Present = $false }
    Findings   = @()
    Errors     = @()
}

# ---------------------------------------------------------------------------
# Network adapters and IP addresses
# ---------------------------------------------------------------------------
$ipByIndex = @{}
$nicByIp = @{}
Invoke-Safe 'Get-NetIPAddress' {
    foreach ($ip in @(Get-NetIPAddress -AddressFamily IPv4 -ErrorAction Stop)) {
        if (-not $ipByIndex.ContainsKey([int]$ip.InterfaceIndex)) { $ipByIndex[[int]$ip.InterfaceIndex] = @() }
        $ipByIndex[[int]$ip.InterfaceIndex] += "$($ip.IPAddress)/$($ip.PrefixLength)"
        $nicByIp[[string]$ip.IPAddress] = [int]$ip.InterfaceIndex
    }
} | Out-Null

$vmqByName = @{}; $rssByName = @{}; $jumboByName = @{}
Invoke-Safe 'Get-NetAdapterVmq' { foreach ($v in @(Get-NetAdapterVmq -ErrorAction Stop)) { $vmqByName[$v.Name] = $v } } | Out-Null
Invoke-Safe 'Get-NetAdapterRss' { foreach ($v in @(Get-NetAdapterRss -ErrorAction Stop)) { $rssByName[$v.Name] = $v } } | Out-Null
Invoke-Safe 'JumboPacket' { foreach ($v in @(Get-NetAdapterAdvancedProperty -RegistryKeyword '*JumboPacket' -ErrorAction Stop)) { $jumboByName[$v.Name] = $v.DisplayValue } } | Out-Null

# A List, not an array: Invoke-Safe runs blocks in a child scope, where "+=" on
# a script-level array would only create a local copy.
$nics = New-Object System.Collections.Generic.List[object]
Invoke-Safe 'Get-NetAdapter' {
    foreach ($n in @(Get-NetAdapter -ErrorAction Stop | Sort-Object Name)) {
        $vmq = $vmqByName[$n.Name]; $rss = $rssByName[$n.Name]
        $nics.Add([pscustomobject]@{
            Name            = $n.Name
            Description     = $n.InterfaceDescription
            PerfMonInstance = Get-PerfMonNicName $n.InterfaceDescription
            IfIndex         = [int]$n.ifIndex
            Status          = [string]$n.Status
            LinkSpeed       = [string]$n.LinkSpeed
            MacAddress      = $n.MacAddress
            Virtual         = [bool]$n.Virtual
            MtuSize         = $n.MtuSize
            JumboPacket     = $jumboByName[$n.Name]
            IPv4            = @($ipByIndex[[int]$n.ifIndex])
            VmqEnabled      = $(if ($vmq) { [bool]$vmq.Enabled } else { $null })
            VmqQueues       = $(if ($vmq) { $vmq.NumberOfReceiveQueues } else { $null })
            RssEnabled      = $(if ($rss) { [bool]$rss.Enabled } else { $null })
            RssBaseProcessor = $(if ($rss) { $rss.BaseProcessorNumber } else { $null })
            RssMaxProcessors = $(if ($rss) { $rss.MaxProcessors } else { $null })
            Role            = @()
        })
    }
} | Out-Null
$nicByIndex = @{}; foreach ($n in $nics) { $nicByIndex[$n.IfIndex] = $n }
$nicByDesc = @{}; foreach ($n in $nics) { if ($n.Description) { $nicByDesc[$n.Description] = $n } }
function Get-NicForIp([string]$Ip) {
    if ($Ip -and $nicByIp.ContainsKey($Ip)) { return $nicByIndex[$nicByIp[$Ip]] }
    return $null
}

# ---------------------------------------------------------------------------
# Hyper-V: virtual switches, SET teams, VM network adapters
# ---------------------------------------------------------------------------
if (Has-Command 'Get-VMSwitch') {
    Invoke-Safe 'Get-VMSwitch' {
        foreach ($sw in @(Get-VMSwitch -ErrorAction Stop)) {
            $team = $null
            if ($sw.EmbeddedTeamingEnabled) { $team = Invoke-Safe 'Get-VMSwitchTeam' { Get-VMSwitchTeam -Name $sw.Name -ErrorAction Stop } }
            $uplinks = @()
            foreach ($d in @($sw.NetAdapterInterfaceDescriptions) + @($sw.NetAdapterInterfaceDescription)) {
                if (-not $d -or ($uplinks | Where-Object { $_.Description -eq $d })) { continue }
                $n = $nicByDesc[$d]
                if ($n) { $n.Role += "Uplink of vSwitch '$($sw.Name)'" }
                $uplinks += [pscustomobject]@{
                    Description     = $d
                    Name            = $(if ($n) { $n.Name } else { $null })
                    LinkSpeed       = $(if ($n) { $n.LinkSpeed } else { $null })
                    Status          = $(if ($n) { $n.Status } else { $null })
                    PerfMonInstance = Get-PerfMonNicName $d
                }
            }
            $topo.VSwitches += [pscustomobject]@{
                Name                   = $sw.Name
                SwitchType             = [string]$sw.SwitchType
                EmbeddedTeaming        = [bool]$sw.EmbeddedTeamingEnabled
                TeamingMode            = $(if ($team) { [string]$team.TeamingMode } else { $null })
                LoadBalancingAlgorithm = $(if ($team) { [string]$team.LoadBalancingAlgorithm } else { $null })
                AllowManagementOS      = [bool]$sw.AllowManagementOS
                BandwidthReservationMode = [string]$sw.BandwidthReservationMode
                IovEnabled             = [bool]$sw.IovEnabled
                Uplinks                = $uplinks
            }
        }
    } | Out-Null

    Invoke-Safe 'Get-VMNetworkAdapter' {
        foreach ($a in @(Get-VMNetworkAdapter -All -ErrorAction Stop)) {
            $vlan = Invoke-Safe 'Get-VMNetworkAdapterVlan' { Get-VMNetworkAdapterVlan -VMNetworkAdapter $a -ErrorAction Stop }
            $hostNic = $null
            if ($a.IsManagementOs) { $hostNic = $nics | Where-Object { $_.Name -eq "vEthernet ($($a.Name))" } | Select-Object -First 1 }
            $topo.VmNics += [pscustomobject]@{
                VMName          = $(if ($a.IsManagementOs) { '(host)' } else { $a.VMName })
                Name            = $a.Name
                IsManagementOs  = [bool]$a.IsManagementOs
                SwitchName      = $a.SwitchName
                MacAddress      = $a.MacAddress
                IPAddresses     = @($a.IPAddresses)
                Status          = (@($a.Status) -join ',')
                VlanMode        = $(if ($vlan) { [string]$vlan.OperationMode } else { $null })
                AccessVlanId    = $(if ($vlan) { $vlan.AccessVlanId } else { $null })
                VmqWeight       = $a.VmqWeight
                IovWeight       = $a.IovWeight
                VrssEnabled     = $(if ($a.PSObject.Properties['VrssEnabled']) { $a.VrssEnabled } else { $null })
                HostNicName     = $(if ($hostNic) { $hostNic.Name } else { $null })
                HostPerfMonInstance = $(if ($hostNic) { $hostNic.PerfMonInstance } else { $null })
            }
        }
    } | Out-Null
}

# ---------------------------------------------------------------------------
# Disks, partitions and volumes
# ---------------------------------------------------------------------------
$partitions = @(Invoke-Safe 'Get-Partition' { Get-Partition -ErrorAction Stop })
$volumes = @(Invoke-Safe 'Get-Volume' { Get-Volume -ErrorAction Stop })
Invoke-Safe 'Get-Disk' {
    foreach ($d in @(Get-Disk -ErrorAction Stop | Sort-Object Number)) {
        $parts = @($partitions | Where-Object { $_.DiskNumber -eq $d.Number })
        $topo.Disks += [pscustomobject]@{
            Number      = [int]$d.Number
            FriendlyName = $d.FriendlyName
            SerialNumber = $d.SerialNumber
            UniqueId    = $d.UniqueId
            Guid        = $d.Guid
            BusType     = [string]$d.BusType
            Location    = $d.Location
            SizeGB      = [math]::Round($d.Size / 1GB, 1)
            IsClustered = [bool]$d.IsClustered
            OperationalStatus = (@($d.OperationalStatus) -join ',')
            Path        = $d.Path
            AccessPaths = @($parts | ForEach-Object { $_.AccessPaths } | Where-Object { $_ })
        }
    }
} | Out-Null
function Get-DiskForPath([string]$Path) {
    # Longest access path (drive letter, mount point, CSV path) that prefixes $Path.
    if (-not $Path) { return $null }
    $best = $null; $bestLen = 0
    foreach ($d in $topo.Disks) {
        foreach ($ap in $d.AccessPaths) {
            if ($ap -like '\\?\Volume*') { continue }
            $p = $ap.TrimEnd('\') + '\'
            if ($Path.StartsWith($p, [StringComparison]::OrdinalIgnoreCase) -and $p.Length -gt $bestLen) { $best = $d; $bestLen = $p.Length }
        }
    }
    return $best
}

# ---------------------------------------------------------------------------
# MPIO: mpclaim gives each path's state and SCSI address (port|bus|target|lun),
# which is what links a path to an iSCSI session below.
# ---------------------------------------------------------------------------
if (Has-Command 'mpclaim.exe') {
    $summary = Get-NativeLines 'mpclaim.exe' @('-s','-d')
    foreach ($line in $summary) {
        if ($line -match '^\s*MPIO Disk(\d+)\s+Disk (\d+)\s+(\S+)\s+(.+?)\s*$') {
            $mpioNum = [int]$Matches[1]; $diskNum = [int]$Matches[2]; $policy = $Matches[3]; $dsm = $Matches[4]
            $detail = Get-NativeLines 'mpclaim.exe' @('-s','-d',"$mpioNum")
            $paths = @()
            foreach ($l in $detail) {
                if ($l -match '^\s*([0-9a-fA-F]{8,16})\s+(\S+)\s+(\d+)\|(\d+)\|(\d+)\|(\d+)\s+(\d+)') {
                    $paths += [pscustomobject]@{
                        PathId  = $Matches[1]
                        State   = $Matches[2]
                        Port    = [int]$Matches[3]; Bus = [int]$Matches[4]; Target = [int]$Matches[5]; Lun = [int]$Matches[6]
                        Weight  = [int]$Matches[7]
                        ScsiAddress = '{0}|{1}|{2}|{3}' -f [int]$Matches[3], [int]$Matches[4], [int]$Matches[5], [int]$Matches[6]
                        Session = $null; InitiatorIp = $null; Nic = $null; TargetPortal = $null; TargetName = $null
                    }
                }
            }
            $topo.Mpio += [pscustomobject]@{
                MpioDisk    = $mpioNum
                DiskNumber  = $diskNum
                Policy      = $policy
                Dsm         = $dsm
                PathCount   = $paths.Count
                Paths       = $paths
                Raw         = ($detail -join "`r`n")
            }
        }
    }
}

# ---------------------------------------------------------------------------
# iSCSI. iscsicli SessionList shows the actual source IP of every connection,
# including connections whose configured initiator portal is "Default"
# (0.0.0.0 in Get-IscsiConnection), and each session's device mapping.
# ---------------------------------------------------------------------------
if (Has-Command 'iscsicli.exe') {
    $psSessions = @{}
    if (Has-Command 'Get-IscsiSession') {
        Invoke-Safe 'Get-IscsiSession' { foreach ($s in @(Get-IscsiSession -ErrorAction Stop)) { $psSessions[[string]$s.SessionIdentifier] = $s } } | Out-Null
    }
    $sessions = @(); $sess = $null; $conn = $null; $dev = $null
    foreach ($line in (Get-NativeLines 'iscsicli.exe' @('SessionList'))) {
        if ($line -match '^\s*Session Id\s*:\s*(\S+)') {
            $sess = [pscustomobject]@{ SessionId = $Matches[1]; TargetName = $null; NumberConnections = $null; ConfiguredInitiatorPortal = $null; IsPersistent = $null; IsConnected = $null; Connections = @(); Devices = @() }
            $sessions += $sess; $conn = $null; $dev = $null; continue
        }
        if (-not $sess) { continue }
        if ($line -match '^\s*Target Name\s*:\s*(.+?)\s*$') { $sess.TargetName = $Matches[1] }
        elseif ($line -match '^\s*Number Connections\s*:\s*(\d+)') { $sess.NumberConnections = [int]$Matches[1] }
        elseif ($line -match '^\s*Connection Id\s*:\s*(\S+)') {
            $conn = [pscustomobject]@{ ConnectionId = $Matches[1]; InitiatorIp = $null; InitiatorPort = $null; TargetIp = $null; TargetPort = $null; Nic = $null; PerfMonInstance = $null }
            $sess.Connections += $conn
        }
        elseif ($conn -and $line -match '^\s*Initiator Portal\s*:\s*([0-9.]+)/(\d+)') { $conn.InitiatorIp = $Matches[1]; $conn.InitiatorPort = [int]$Matches[2] }
        elseif ($conn -and $line -match '^\s*Target Portal\s*:\s*([0-9.]+)/(\d+)') { $conn.TargetIp = $Matches[1]; $conn.TargetPort = [int]$Matches[2] }
        elseif ($line -match '^\s*Device Type\s*:\s*(.+?)\s*$') {
            $dev = [pscustomobject]@{ DeviceType = $Matches[1]; DeviceNumber = $null; Port = $null; Bus = $null; Target = $null; Lun = $null; LegacyName = $null }
            $sess.Devices += $dev
        }
        elseif ($dev -and $line -match '^\s*Device Number\s*:\s*(\d+)') { $dev.DeviceNumber = [int]$Matches[1] }
        elseif ($dev -and $line -match 'Port (\d+),\s*Bus (\d+),\s*Target Id (\d+),\s*LUN (\d+)') { $dev.Port = [int]$Matches[1]; $dev.Bus = [int]$Matches[2]; $dev.Target = [int]$Matches[3]; $dev.Lun = [int]$Matches[4] }
        elseif ($dev -and $line -match '^\s*Legacy Device Name\s*:\s*(\S+)') { $dev.LegacyName = $Matches[1] }
    }
    foreach ($s in $sessions) {
        $ps = $psSessions[$s.SessionId]
        if ($ps) { $s.ConfiguredInitiatorPortal = [string]$ps.InitiatorPortalAddress; $s.IsPersistent = $ps.IsPersistent; $s.IsConnected = $ps.IsConnected }
        foreach ($c in $s.Connections) {
            $n = Get-NicForIp $c.InitiatorIp
            if ($n) { $c.Nic = $n.Name; $c.PerfMonInstance = $n.PerfMonInstance; if ($n.Role -notcontains 'iSCSI') { $n.Role += 'iSCSI' } }
        }
        # Link MPIO paths to this session by SCSI address.
        foreach ($d in $s.Devices) {
            if ($null -eq $d.Port) { continue }
            foreach ($m in $topo.Mpio) {
                foreach ($p in $m.Paths) {
                    if ($p.Port -eq $d.Port -and $p.Bus -eq $d.Bus -and $p.Target -eq $d.Target -and $p.Lun -eq $d.Lun) {
                        $c0 = @($s.Connections)[0]
                        $p.Session = $s.SessionId; $p.TargetName = $s.TargetName
                        if ($c0) { $p.InitiatorIp = $c0.InitiatorIp; $p.Nic = $c0.Nic; $p.TargetPortal = $c0.TargetIp }
                    }
                }
            }
        }
    }
    $topo.Iscsi.Sessions = $sessions

    if (Has-Command 'Get-IscsiTargetPortal') {
        Invoke-Safe 'Get-IscsiTargetPortal' {
            $topo.Iscsi.TargetPortals = @(Get-IscsiTargetPortal -ErrorAction Stop | ForEach-Object {
                [pscustomobject]@{ TargetPortalAddress = $_.TargetPortalAddress; TargetPortalPortNumber = $_.TargetPortalPortNumber; InitiatorPortalAddress = $_.InitiatorPortalAddress; InitiatorInstanceName = $_.InitiatorInstanceName }
            })
        } | Out-Null
    }

    # Per-NIC usage: how many connections and MPIO paths each source NIC carries.
    $usage = @{}
    foreach ($s in $sessions) {
        foreach ($c in $s.Connections) {
            $k = $(if ($c.Nic) { $c.Nic } else { "(unknown $($c.InitiatorIp))" })
            if (-not $usage.ContainsKey($k)) { $usage[$k] = [pscustomobject]@{ Nic = $k; InitiatorIp = $c.InitiatorIp; PerfMonInstance = $c.PerfMonInstance; Connections = 0; Targets = @(); Paths = 0; OptimizedPaths = 0 } }
            $usage[$k].Connections++
            if ($usage[$k].Targets -notcontains $c.TargetIp) { $usage[$k].Targets += $c.TargetIp }
        }
    }
    foreach ($m in $topo.Mpio) {
        foreach ($p in $m.Paths) {
            if ($p.Nic -and $usage.ContainsKey($p.Nic)) {
                $usage[$p.Nic].Paths++
                if ($p.State -match '(?i)Active/Optimized') { $usage[$p.Nic].OptimizedPaths++ }
            }
        }
    }
    $topo.Iscsi.NicUsage = @($usage.Values | Sort-Object Nic)
}

# ---------------------------------------------------------------------------
# Cluster Shared Volumes
# ---------------------------------------------------------------------------
if (Has-Command 'Get-ClusterSharedVolume') {
    $csvStates = @(Invoke-Safe 'Get-ClusterSharedVolumeState' { Get-ClusterSharedVolumeState -ErrorAction Stop })
    Invoke-Safe 'Get-ClusterSharedVolume' {
        foreach ($c in @(Get-ClusterSharedVolume -ErrorAction Stop)) {
            $info = @($c.SharedVolumeInfo)[0]
            $friendly = $(if ($info) { [string]$info.FriendlyVolumeName } else { $null })
            $disk = Get-DiskForPath ($friendly + '\x')
            $states = @($csvStates | Where-Object { $_.Name -eq $c.Name } | ForEach-Object {
                [pscustomobject]@{ Node = [string]$_.Node; StateInfo = [string]$_.StateInfo; FileSystemRedirectedIOReason = [string]$_.FileSystemRedirectedIOReason; BlockRedirectedIOReason = [string]$_.BlockRedirectedIOReason }
            })
            $topo.Csvs += [pscustomobject]@{
                Name             = $c.Name
                OwnerNode        = [string]$c.OwnerNode
                State            = [string]$c.State
                FriendlyVolumeName = $friendly
                MaintenanceMode  = $(if ($info) { $info.MaintenanceMode } else { $null })
                RedirectedAccess = $(if ($info) { $info.RedirectedAccess } else { $null })
                DiskNumber       = $(if ($disk) { $disk.Number } else { $null })
                NodeStates       = $states
            }
        }
    } | Out-Null
}
function Get-CsvForPath([string]$Path) {
    foreach ($c in $topo.Csvs) {
        if ($c.FriendlyVolumeName -and $Path -and $Path.StartsWith($c.FriendlyVolumeName.TrimEnd('\') + '\', [StringComparison]::OrdinalIgnoreCase)) { return $c }
    }
    return $null
}

# ---------------------------------------------------------------------------
# Hyper-V VMs and virtual disks
# ---------------------------------------------------------------------------
if (Has-Command 'Get-VM') {
    Invoke-Safe 'Get-VM' {
        foreach ($vm in @(Get-VM -ErrorAction Stop)) {
            $snaps = @(Invoke-Safe 'Get-VMSnapshot' { Get-VMSnapshot -VMName $vm.Name -ErrorAction Stop })
            $topo.Vms += [pscustomobject]@{
                Name = $vm.Name; State = [string]$vm.State; Generation = $vm.Generation; ProcessorCount = $vm.ProcessorCount
                MemoryAssignedGB = [math]::Round($vm.MemoryAssigned / 1GB, 1); IsClustered = [bool]$vm.IsClustered; Path = $vm.Path
                Checkpoints = @($snaps | ForEach-Object { $_.Name })
            }
            if ($snaps.Count -gt 0) { Add-Finding 'Notice' 'Hyper-V' "VM '$($vm.Name)' has $($snaps.Count) checkpoint(s); its disks write to differencing files (AVHDX)." }
            foreach ($hd in @(Invoke-Safe "Get-VMHardDiskDrive $($vm.Name)" { Get-VMHardDiskDrive -VM $vm -ErrorAction Stop })) {
                if ($null -eq $hd) { continue }
                $vhd = $null
                if ($hd.Path) { $vhd = Invoke-Safe "Get-VHD $($hd.Path)" { Get-VHD -Path $hd.Path -ErrorAction Stop } }
                $csv = Get-CsvForPath $hd.Path
                $backing = Get-DiskForPath $hd.Path
                $topo.VmDisks += [pscustomobject]@{
                    VMName = $vm.Name; ControllerType = [string]$hd.ControllerType; ControllerNumber = $hd.ControllerNumber; ControllerLocation = $hd.ControllerLocation
                    Path = $hd.Path
                    VhdType = $(if ($vhd) { [string]$vhd.VhdType } else { $null })
                    VhdFormat = $(if ($vhd) { [string]$vhd.VhdFormat } else { $null })
                    SizeGB = $(if ($vhd) { [math]::Round($vhd.Size / 1GB, 1) } else { $null })
                    FileSizeGB = $(if ($vhd) { [math]::Round($vhd.FileSize / 1GB, 1) } else { $null })
                    BlockSizeMB = $(if ($vhd) { [math]::Round($vhd.BlockSize / 1MB, 1) } else { $null })
                    LogicalSectorSize = $(if ($vhd) { $vhd.LogicalSectorSize } else { $null })
                    PhysicalSectorSize = $(if ($vhd) { $vhd.PhysicalSectorSize } else { $null })
                    ParentPath = $(if ($vhd) { $vhd.ParentPath } else { $null })
                    DiskIdentifier = $(if ($vhd) { [string]$vhd.DiskIdentifier } else { $null })
                    MinimumIOPS = $hd.MinimumIOPS; MaximumIOPS = $hd.MaximumIOPS; QoSPolicyID = [string]$hd.QoSPolicyID
                    Csv = $(if ($csv) { $csv.Name } else { $null })
                    BackingDisk = $(if ($backing) { $backing.Number } else { $null })
                }
                if ($vhd -and [string]$vhd.VhdType -eq 'Dynamic') { Add-Finding 'Notice' 'Hyper-V' "$($vm.Name): $(Split-Path $hd.Path -Leaf) is a dynamically expanding VHDX (allocates blocks on first write)." }
                if ($vhd -and $vhd.ParentPath) { Add-Finding 'Notice' 'Hyper-V' "$($vm.Name): $(Split-Path $hd.Path -Leaf) is a differencing disk (parent $($vhd.ParentPath))." }
                if (($hd.MaximumIOPS -and $hd.MaximumIOPS -gt 0) -or ($hd.QoSPolicyID -and [string]$hd.QoSPolicyID -ne '00000000-0000-0000-0000-000000000000')) {
                    Add-Finding 'Warning' 'Hyper-V' "$($vm.Name): storage QoS on $(Split-Path $hd.Path -Leaf) (MaximumIOPS=$($hd.MaximumIOPS), Policy=$($hd.QoSPolicyID))."
                }
            }
        }
    } | Out-Null
}

# ---------------------------------------------------------------------------
# SMB shares -> volume -> disk
# ---------------------------------------------------------------------------
if (Has-Command 'Get-SmbShare') {
    Invoke-Safe 'Get-SmbShare' {
        foreach ($sh in @(Get-SmbShare -Special $false -ErrorAction Stop)) {
            $disk = Get-DiskForPath $sh.Path
            $vol = $null
            if ($sh.Path -match '^([A-Za-z]):') {
                $letter = $Matches[1]
                $vol = $volumes | Where-Object { $_ -and [string]$_.DriveLetter -eq $letter } | Select-Object -First 1
            }
            $topo.SmbShares += [pscustomobject]@{
                Name = $sh.Name; Path = $sh.Path; ScopeName = $sh.ScopeName
                ContinuouslyAvailable = [bool]$sh.ContinuouslyAvailable; CachingMode = [string]$sh.CachingMode; EncryptData = [bool]$sh.EncryptData
                VolumeLabel = $(if ($vol) { $vol.FileSystemLabel } else { $null })
                FileSystem = $(if ($vol) { $vol.FileSystemType } else { $null })
                DiskNumber = $(if ($disk) { $disk.Number } else { $null })
                DiskLocation = $(if ($disk) { $disk.Location } else { $null })
                DiskSerial = $(if ($disk) { $disk.SerialNumber } else { $null })
                DiskUniqueId = $(if ($disk) { $disk.UniqueId } else { $null })
            }
        }
    } | Out-Null
}

# ---------------------------------------------------------------------------
# DCB / PFC / ETS / ECN
# ---------------------------------------------------------------------------
$qos = $topo.NetworkQos
$qos.Policies = @(Invoke-Safe 'Get-NetQosPolicy' { Get-NetQosPolicy -ErrorAction Stop | Select-Object Name, Owner, NetDirectPortMatchCondition, IPProtocolMatchCondition, IPDstPortMatchCondition, PriorityValue8021Action })
$qos.FlowControl = @(Invoke-Safe 'Get-NetQosFlowControl' { Get-NetQosFlowControl -ErrorAction Stop | Select-Object Priority, Enabled })
$qos.TrafficClasses = @(Invoke-Safe 'Get-NetQosTrafficClass' { Get-NetQosTrafficClass -ErrorAction Stop | Select-Object Name, Algorithm, Bandwidth, @{ n = 'Priority'; e = { @($_.Priority) -join ',' } } })
$qos.Dcbx = @(Invoke-Safe 'Get-NetQosDcbxSetting' { Get-NetQosDcbxSetting -ErrorAction Stop | Select-Object InterfaceAlias, Willing })
$qos.AdapterQos = @(Invoke-Safe 'Get-NetAdapterQos' { Get-NetAdapterQos -ErrorAction Stop | Select-Object Name, Enabled, @{ n = 'OperationalTrafficClasses'; e = { [string]$_.OperationalTrafficClasses } } })
$qos.TcpSettings = @(Invoke-Safe 'Get-NetTCPSetting' { Get-NetTCPSetting -ErrorAction Stop | Select-Object SettingName, EcnCapability, CongestionProvider, AutoTuningLevelLocal, InitialCongestionWindowMss })

# ---------------------------------------------------------------------------
# Avid NEXIS client: its file data travels over UDP through Avid's own file
# system driver, so the SMB counters never see it. Found by name.
# ---------------------------------------------------------------------------
$nexisPids = @(Get-Process -ErrorAction SilentlyContinue | Where-Object { $_.ProcessName -match '(?i)^(AvidFos|AvidNEXIS|nxClient)' } | ForEach-Object { $_.Id })
$nx = [ordered]@{ Present = $false; Version = $null; Services = @(); Drivers = @(); Processes = @(); Workspaces = @(); TcpPeers = @(); UdpEndpoints = @() }
$nx.Services = @(Invoke-Safe 'NEXIS services' { Get-Service -ErrorAction Stop | Where-Object { $_.Name -match '(?i)avidfos|nexis' -or $_.DisplayName -match '(?i)avid nexis|avidfos' } | ForEach-Object { [pscustomobject]@{ Name = $_.Name; DisplayName = $_.DisplayName; Status = [string]$_.Status } } })
$nx.Drivers = @(Invoke-Safe 'NEXIS drivers' { Get-CimInstance Win32_SystemDriver -ErrorAction Stop | Where-Object { $_.Name -match '(?i)avidfos|nexis' } | ForEach-Object { [pscustomobject]@{ Name = $_.Name; State = $_.State; Path = $_.PathName } } })
$nx.Processes = @(Get-Process -Id $nexisPids -ErrorAction SilentlyContinue | ForEach-Object { "$($_.ProcessName) ($($_.Id))" })
Invoke-Safe 'NEXIS version' {
    foreach ($k in @('HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*', 'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*')) {
        foreach ($e in @(Get-ItemProperty $k -ErrorAction SilentlyContinue | Where-Object { $_.PSObject.Properties['DisplayName'] -and $_.DisplayName -match '(?i)avid nexis' })) {
            if (-not $nx.Version) { $nx.Version = "$($e.DisplayName) $($e.DisplayVersion)".Trim() }
        }
    }
} | Out-Null
$nx.Workspaces = @(Invoke-Safe 'NEXIS workspaces' {
    @(Get-CimInstance Win32_LogicalDisk -Filter 'DriveType=4' -ErrorAction Stop | Where-Object { $_.ProviderName -match '(?i)avidfos|nexis' } | ForEach-Object { [pscustomobject]@{ Drive = $_.DeviceID; Remote = $_.ProviderName; SizeGB = [math]::Round($_.Size / 1GB); FreeGB = [math]::Round($_.FreeSpace / 1GB) } }) +
    @(Get-CimInstance Win32_NetworkConnection -ErrorAction Stop | Where-Object { $_.ProviderName -match '(?i)avid|nexis' -or $_.RemoteName -match '(?i)avidfos' } | ForEach-Object { [pscustomobject]@{ Drive = $_.LocalName; Remote = $_.RemoteName; SizeGB = $null; FreeGB = $null } })
})
if ($nexisPids.Count) {
    $nx.TcpPeers = @(Invoke-Safe 'NEXIS TCP' { Get-NetTCPConnection -State Established -ErrorAction Stop | Where-Object { $nexisPids -contains $_.OwningProcess } | ForEach-Object { "$($_.RemoteAddress):$($_.RemotePort)" } | Select-Object -Unique })
    $nx.UdpEndpoints = @(Invoke-Safe 'NEXIS UDP' { Get-NetUDPEndpoint -ErrorAction Stop | Where-Object { $nexisPids -contains $_.OwningProcess } | ForEach-Object { "$($_.LocalAddress):$($_.LocalPort)" } | Select-Object -Unique })
}
$nx.Present = [bool]($nx.Services.Count -or $nx.Drivers.Count -or $nx.Processes.Count -or $nx.Workspaces.Count -or $nx.Version)
$topo['AvidNexis'] = $nx
if ($nx.Present) {
    $ws = @($nx.Workspaces | ForEach-Object { $_.Drive } | Where-Object { $_ }) -join ', '
    Add-Finding 'Notice' 'Avid NEXIS' ("Avid NEXIS client{0} is installed{1}. Its file data is UDP, so the SMB counters do not show it; Invoke-CinesysAnalysis reports it as 'Avid NEXIS' network traffic. For the path MTU test, name the NEXIS engines with -PathTestIp." -f $(if ($nx.Version) { " ($($nx.Version))" } else { '' }), $(if ($ws) { " (workspaces $ws)" } else { '' }))
    $stopped = @($nx.Services | Where-Object { $_.Status -ne 'Running' })
    foreach ($sv in $stopped) { Add-Finding 'Warning' 'Avid NEXIS' "NEXIS service '$($sv.DisplayName)' is $($sv.Status)." }
}

# ---------------------------------------------------------------------------
# Path MTU: don't-fragment pings to each storage target
# ---------------------------------------------------------------------------
# Targets: SMB servers in use, iSCSI target portals, Avid NEXIS hosts (TCP
# peers of the NEXIS client processes) and -PathTestIp. Every target gets a
# 1500-byte test; when the adapter that reaches it has an IP MTU above 1500,
# also a test at that size, and when that fails, a search for the largest
# size that passes. .NET Ping is used instead of ping.exe so the result does
# not depend on the Windows display language. Status PacketTooBig means a
# router on the path answered "fragmentation needed"; TimedOut means the
# packet was dropped silently (switch port, VLAN or target interface MTU).
$pathTargets = [ordered]@{}
function Add-PathTarget([string]$Ip, [string]$Role) {
    if (-not $Ip -or $Ip -notmatch '^\d{1,3}(\.\d{1,3}){3}$' -or $Ip -like '127.*' -or $Ip -eq '0.0.0.0') { return }
    if ($pathTargets.Contains($Ip)) { if (([string]$pathTargets[$Ip]) -notlike "*$Role*") { $pathTargets[$Ip] = "$($pathTargets[$Ip]), $Role" } }
    else { $pathTargets[$Ip] = $Role }
}
function Test-DfPing([string]$Ip, [int]$Payload, [int]$Tries = 2) {
    $ping = New-Object System.Net.NetworkInformation.Ping
    $opt = New-Object System.Net.NetworkInformation.PingOptions(64, $true)
    $buf = New-Object byte[] $Payload
    $seen = New-Object System.Collections.Generic.List[string]
    $ok = $false
    for ($i = 0; $i -lt $Tries -and -not $ok; $i++) {
        try { $r = $ping.Send($Ip, 1000, $buf, $opt); $seen.Add([string]$r.Status); if ($r.Status -eq 'Success') { $ok = $true } }
        catch { $seen.Add('Error') }
    }
    $ping.Dispose()
    [pscustomobject]@{ Ok = $ok; Status = (@($seen | Select-Object -Unique) -join ',') }
}
if (-not $NoPathMtuTest) {
    Invoke-Safe 'Get-SmbMultichannelConnection' {
        foreach ($c in @(Get-SmbMultichannelConnection -ErrorAction Stop)) { Add-PathTarget ([string]$c.ServerIpAddress) "SMB $($c.ServerName)" }
    } | Out-Null
    foreach ($s in $topo.Iscsi.Sessions) { foreach ($c in @($s.Connections)) { Add-PathTarget ([string]$c.TargetIp) 'iSCSI' } }
    foreach ($p in @($nx.TcpPeers)) { Add-PathTarget ([string]($p -replace ':\d+$', '')) 'Avid NEXIS' }
    foreach ($ip in @($PathTestIp)) { Add-PathTarget ([string]$ip) 'named with -PathTestIp' }

    $mtuResults = New-Object System.Collections.Generic.List[object]
    $n = 0
    foreach ($ip in @($pathTargets.Keys)) {
        if (++$n -gt 12) { $script:Errors.Add("Path MTU: only the first 12 of $($pathTargets.Count) targets were tested."); break }
        $role = $pathTargets[$ip]
        $res = [ordered]@{ Target = $ip; Role = $role; Nic = $null; SourceIp = $null; NextHop = $null; InterfaceMtu = $null
                           Ping1500 = $null; PingJumbo = $null; LargestPassing = $null; Result = $null }
        Invoke-Safe "Find-NetRoute $ip" {
            $route = @(Find-NetRoute -RemoteIPAddress $ip -ErrorAction Stop)
            $ifx = ($route | Where-Object { $_.InterfaceIndex } | Select-Object -First 1).InterfaceIndex
            $res.SourceIp = [string](($route | Where-Object { $_.PSObject.Properties['IPAddress'] -and $_.IPAddress } | Select-Object -First 1).IPAddress)
            $res.NextHop = [string](($route | Where-Object { $_.PSObject.Properties['NextHop'] -and $_.NextHop } | Select-Object -First 1).NextHop)
            if ($ifx) {
                $res.Nic = $(if ($nicByIndex.ContainsKey([int]$ifx)) { $nicByIndex[[int]$ifx].Name } else { "ifIndex $ifx" })
                $res.InterfaceMtu = [int](Get-NetIPInterface -InterfaceIndex $ifx -AddressFamily IPv4 -ErrorAction Stop).NlMtu
            }
        } | Out-Null
        $mtu = $(if ($res.InterfaceMtu) { [int]$res.InterfaceMtu } else { 1500 })
        $base = Test-DfPing $ip ([math]::Min(1472, $mtu - 28))
        $res.Ping1500 = $base.Status
        $okSize = $null; $failSize = $null; $failStatus = $null
        if ($base.Ok) { $okSize = [math]::Min(1472, $mtu - 28) }
        else {
            $small = Test-DfPing $ip 32
            if ($small.Ok) { $okSize = 32; $failSize = [math]::Min(1472, $mtu - 28); $failStatus = $base.Status }
        }
        if ($base.Ok -and $mtu -gt 1500) {
            $big = Test-DfPing $ip ($mtu - 28)
            $res.PingJumbo = $big.Status
            if ($big.Ok) { $okSize = $mtu - 28 } else { $failSize = $mtu - 28; $failStatus = $big.Status }
        }
        if ($null -ne $okSize -and $null -ne $failSize) {
            $lo = $okSize; $hi = $failSize
            while ($hi - $lo -gt 1) {
                $mid = [int][math]::Floor(($lo + $hi) / 2)
                $t = Test-DfPing $ip $mid
                if ($t.Ok) { $lo = $mid } else { $hi = $mid; if ($t.Status -match 'PacketTooBig') { $failStatus = $t.Status } }
            }
            $res.LargestPassing = $lo + 28
        } elseif ($null -ne $okSize) { $res.LargestPassing = $okSize + 28 }
        $where = "$ip ($role) via $($res.Nic)"
        if ($null -eq $okSize) {
            $res.Result = 'NoReply'
            Add-Finding 'Notice' 'Network' "No reply to pings from $where ($($base.Status)). ICMP may be blocked, so the path MTU could not be tested."
        } elseif ($null -eq $failSize) {
            $res.Result = 'OK'
        } elseif ($failStatus -match 'PacketTooBig') {
            $res.Result = 'RouterRefused'
            Add-Finding 'Warning' 'Network' "$($res.Nic) has IP MTU $mtu, but a router on the path to $ip ($role) refuses packets above $($res.LargestPassing) bytes ('fragmentation needed'). A routed hop or firewall between them uses a smaller MTU."
        } else {
            $res.Result = 'SilentDrop'
            Add-Finding 'Warning' 'Network' "$($res.Nic) has IP MTU $mtu, but $($failSize + 28)-byte packets to $ip ($role) get no reply ($failStatus) while $($res.LargestPassing)-byte packets do. Something drops them without a message: a switch port or VLAN on the path, or the target's own interface, is set to a smaller MTU."
        }
        $mtuResults.Add([pscustomobject]$res)
    }
    $topo['PathMtu'] = $mtuResults.ToArray()
}

# ---------------------------------------------------------------------------
# Findings: factual observations worth checking, not conclusions.
# ---------------------------------------------------------------------------
$hostIps = @($nicByIp.Keys)
foreach ($s in $topo.Iscsi.Sessions) {
    if ($s.ConfiguredInitiatorPortal -eq '0.0.0.0') {
        $src = (@($s.Connections | ForEach-Object { "$($_.InitiatorIp) ($($_.Nic))" }) -join ', ')
        Add-Finding 'Warning' 'iSCSI' "Session $($s.SessionId) to $($s.TargetName) uses the Default initiator portal; Windows routing chose source $src."
    }
    if ($s.NumberConnections -eq 0 -or @($s.Connections).Count -eq 0) {
        Add-Finding 'Warning' 'iSCSI' "Session $($s.SessionId) to $($s.TargetName) has no connections."
    }
}
$dupes = @($topo.Iscsi.Sessions | ForEach-Object { $t = $_.TargetName; $_.Connections | ForEach-Object { "$t|$($_.InitiatorIp)|$($_.TargetIp)" } } | Group-Object | Where-Object { $_.Count -gt 1 })
foreach ($g in $dupes) { $p = $g.Name -split '\|'; Add-Finding 'Warning' 'iSCSI' "$($g.Count) connections from $($p[1]) to $($p[2]) for $($p[0]) (duplicate sessions on the same initiator/target pair)." }
foreach ($tp in $topo.Iscsi.TargetPortals) {
    $ip = [string]$tp.InitiatorPortalAddress
    if ($ip -and $ip -ne '0.0.0.0' -and $hostIps -notcontains $ip) {
        Add-Finding 'Warning' 'iSCSI' "Target portal $($tp.TargetPortalAddress) is bound to initiator IP $ip, which is not configured on this host (causes iScsiPrt event 5 'Failed to setup initiator portal')."
    }
}
$iscsiNics = @($topo.Iscsi.NicUsage | Where-Object { $_.Nic -notlike '(unknown*' })
foreach ($n in $nics) {
    if ($n.Name -match '(?i)iscsi' -and -not ($iscsiNics | Where-Object { $_.Nic -eq $n.Name })) {
        Add-Finding 'Warning' 'iSCSI' "NIC '$($n.Name)' ($($n.IPv4 -join ', ')) is named for iSCSI but carries no iSCSI connection."
    }
}
foreach ($m in $topo.Mpio) {
    $opt = @($m.Paths | Where-Object { $_.State -match '(?i)Active/Optimized' }).Count
    $bad = @($m.Paths | Where-Object { $_.State -match '(?i)fail|unavailable' })
    if ($m.PathCount -gt 0 -and $opt -eq 0) { Add-Finding 'Warning' 'MPIO' "MPIO Disk$($m.MpioDisk) (Disk $($m.DiskNumber)) has no Active/Optimized path; I/O goes through the non-owning controller." }
    foreach ($p in $bad) { Add-Finding 'Warning' 'MPIO' "MPIO Disk$($m.MpioDisk) path $($p.PathId) is $($p.State)." }
    $unmapped = @($m.Paths | Where-Object { -not $_.Session }).Count
    if ($unmapped -gt 0 -and @($topo.Iscsi.Sessions).Count -gt 0) { Add-Finding 'Notice' 'MPIO' "$unmapped of $($m.PathCount) paths on MPIO Disk$($m.MpioDisk) could not be matched to an iSCSI session by SCSI address." }
}
foreach ($c in $topo.Csvs) {
    foreach ($st in $c.NodeStates) {
        if ($st.StateInfo -and $st.StateInfo -ne 'Direct') { Add-Finding 'Warning' 'CSV' "$($c.Name) on $($st.Node) is $($st.StateInfo) (FS reason: $($st.FileSystemRedirectedIOReason), block reason: $($st.BlockRedirectedIOReason))." }
    }
}

$topo['Nics'] = $nics.ToArray()
$topo['Findings'] = $script:Findings.ToArray()
$topo['Errors'] = $script:Errors.ToArray()

# ---------------------------------------------------------------------------
# Output
# ---------------------------------------------------------------------------
$jsonFile = Join-Path $OutputPath "Topology-$Label.json"
$txtFile = Join-Path $OutputPath "Topology-$Label.txt"
try { $topo | ConvertTo-Json -Depth 6 | Set-Content -Path $jsonFile -Encoding UTF8 } catch { $script:Errors.Add("JSON: $($_.Exception.Message)") }

$t = New-Object System.Collections.Generic.List[string]
$t.Add("CINESYS TOPOLOGY - $($topo.Computer) - $Label - $($topo.Generated)")
$t.Add('')
if ($topo.SmbShares.Count) {
    $t.Add('== SMB SHARES -> VOLUME -> DISK ==')
    foreach ($s in $topo.SmbShares) { $t.Add(("  \\{0}\{1}  ->  {2}  [{3} {4}]  ->  Disk {5}  ({6}; serial {7})" -f $env:COMPUTERNAME, $s.Name, $s.Path, $s.VolumeLabel, $s.FileSystem, $s.DiskNumber, $s.DiskLocation, $s.DiskSerial)) }
    $t.Add('')
}
if ($topo.VSwitches.Count -or $topo.VmNics.Count) {
    $t.Add('== VM NETWORK: vNIC -> vSwitch -> uplinks ==')
    foreach ($sw in $topo.VSwitches) {
        $t.Add(("  vSwitch '{0}' ({1}{2})" -f $sw.Name, $sw.SwitchType, $(if ($sw.EmbeddedTeaming) { ", SET $($sw.TeamingMode)/$($sw.LoadBalancingAlgorithm)" } else { '' })))
        foreach ($u in $sw.Uplinks) { $t.Add(("      uplink {0} [{1}] {2} {3}   PerfMon: {4}" -f $u.Name, $u.Description, $u.LinkSpeed, $u.Status, $u.PerfMonInstance)) }
        foreach ($a in @($topo.VmNics | Where-Object { $_.SwitchName -eq $sw.Name })) {
            $t.Add(("      <- {0} / {1}  MAC {2}  IP {3}  VLAN {4} {5}" -f $a.VMName, $a.Name, $a.MacAddress, (@($a.IPAddresses) -join ','), $a.VlanMode, $a.AccessVlanId))
        }
    }
    $t.Add('')
}
if ($topo.VmDisks.Count) {
    $t.Add('== VM STORAGE: disk -> VHDX -> CSV -> physical disk ==')
    foreach ($d in $topo.VmDisks) {
        $t.Add(("  {0} {1}{2}:{3}  {4}" -f $d.VMName, $d.ControllerType, $d.ControllerNumber, $d.ControllerLocation, $d.Path))
        $t.Add(("      {0} {1}, {2} GB (file {3} GB), block {4} MB, sector {5}/{6}  ->  {7}  ->  Disk {8}" -f $d.VhdFormat, $d.VhdType, $d.SizeGB, $d.FileSizeGB, $d.BlockSizeMB, $d.LogicalSectorSize, $d.PhysicalSectorSize, $d.Csv, $d.BackingDisk))
    }
    $t.Add('')
}
if ($topo.Csvs.Count) {
    $t.Add('== CLUSTER SHARED VOLUMES ==')
    foreach ($c in $topo.Csvs) {
        $t.Add(("  {0}  {1}  owner {2}  {3}  Disk {4}" -f $c.Name, $c.FriendlyVolumeName, $c.OwnerNode, $c.State, $c.DiskNumber))
        foreach ($st in $c.NodeStates) { $t.Add(("      {0}: {1}  (FS redirect: {2}; block redirect: {3})" -f $st.Node, $st.StateInfo, $st.FileSystemRedirectedIOReason, $st.BlockRedirectedIOReason)) }
    }
    $t.Add('')
}
if ($topo.Mpio.Count) {
    $t.Add('== MPIO PATHS -> iSCSI SESSION -> SOURCE NIC -> TARGET PORTAL ==')
    foreach ($m in $topo.Mpio) {
        $t.Add(("  MPIO Disk{0} = Disk {1}, policy {2}, {3} paths ({4})" -f $m.MpioDisk, $m.DiskNumber, $m.Policy, $m.PathCount, $m.Dsm))
        foreach ($p in $m.Paths) {
            $t.Add(("      {0}  {1,-20} {2,-13} {3,-15} via {4,-28} -> {5,-15} {6}" -f $p.PathId, $p.State, $p.ScsiAddress, $p.InitiatorIp, $p.Nic, $p.TargetPortal, $p.TargetName))
        }
    }
    $t.Add('')
}
if (@($topo.Iscsi.NicUsage).Count) {
    $t.Add('== iSCSI LOAD BY SOURCE NIC ==')
    foreach ($u in $topo.Iscsi.NicUsage) {
        $t.Add(("  {0,-28} {1,-15} connections {2,3}  paths {3,3} (optimized {4,3})  targets {5}   PerfMon: {6}" -f $u.Nic, $u.InitiatorIp, $u.Connections, $u.Paths, $u.OptimizedPaths, (@($u.Targets) -join ','), $u.PerfMonInstance))
    }
    $t.Add('')
}
if ($nx.Present) {
    $t.Add('== AVID NEXIS CLIENT ==')
    $t.Add("  Version:    $($nx.Version)")
    $t.Add("  Services:   " + (@($nx.Services | ForEach-Object { "$($_.DisplayName) [$($_.Status)]" }) -join '; '))
    $t.Add("  Drivers:    " + (@($nx.Drivers | ForEach-Object { "$($_.Name) [$($_.State)]" }) -join '; '))
    $t.Add("  Processes:  " + ($nx.Processes -join ', '))
    foreach ($w in $nx.Workspaces) { $t.Add(("  Workspace:  {0}  {1}  {2}" -f $w.Drive, $w.Remote, $(if ($null -ne $w.SizeGB) { "$($w.FreeGB) of $($w.SizeGB) GB free" } else { '' }))) }
    $t.Add("  TCP peers:  " + ($nx.TcpPeers -join ', '))
    $t.Add("  UDP ports:  " + ($nx.UdpEndpoints -join ', '))
    $t.Add('')
}
if (@($topo.PathMtu).Count) {
    $t.Add("== PATH MTU (don't-fragment pings) ==")
    foreach ($m in $topo.PathMtu) {
        $t.Add(("  {0,-15} {1,-34} via {2} ({3}), IP MTU {4}{5}" -f $m.Target, $m.Role, $m.Nic, $m.SourceIp, $m.InterfaceMtu, $(if ($m.NextHop -and $m.NextHop -ne '0.0.0.0') { ", routed via $($m.NextHop)" } else { '' })))
        $t.Add(("      1500: {0}   at interface MTU: {1}   largest that passes: {2}   -> {3}" -f $m.Ping1500, $(if ($m.PingJumbo) { $m.PingJumbo } else { '(not tested, MTU 1500)' }), $m.LargestPassing, $m.Result))
    }
    $t.Add('')
}
$t.Add('== FINDINGS ==')
if ($script:Findings.Count -eq 0) { $t.Add('  (none)') }
foreach ($f in $script:Findings) { $t.Add(("  [{0}] {1}: {2}" -f $f.Severity, $f.Area, $f.Message)) }
if ($script:Errors.Count) {
    $t.Add('')
    $t.Add('== QUERY ERRORS (role not present or access denied) ==')
    foreach ($e in $script:Errors) { $t.Add("  $e") }
}
$t | Set-Content -Path $txtFile -Encoding UTF8
