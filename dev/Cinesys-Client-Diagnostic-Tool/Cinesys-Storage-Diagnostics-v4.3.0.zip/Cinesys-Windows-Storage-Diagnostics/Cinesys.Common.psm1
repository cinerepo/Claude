# Shared helpers for the Cinesys Windows Storage Diagnostics scripts.
# Windows PowerShell 5.1 compatible. Keep this file ASCII-only.

$script:OwnerMarker = 'CinesysStorageDiagnostic'
$script:OwnerDescription = 'Created and managed by Cinesys Windows Storage Diagnostics. Owner marker: CinesysStorageDiagnostic'
$script:WprInstanceName = 'CinesysStorageDiagnostic'

# Names of the native PLA configuration collectors this toolkit installs. Used to
# recognise a DCS created by v3.5-v3.8, which predates the ownership marker.
$script:LegacyCollectorNames = @('iSCSI and MPIO Configuration','SMB Configuration','Hyper-V Configuration','Failover Cluster Configuration')

function Get-CinesysVersion {
    # VERSION.txt is the single source of truth for the toolkit version.
    foreach ($p in @((Join-Path $PSScriptRoot 'VERSION.txt'), (Join-Path (Split-Path $PSScriptRoot -Parent) 'VERSION.txt'))) {
        if (Test-Path $p) {
            $v = (Get-Content $p -Raw).Trim([char]0xFEFF, ' ', "`r", "`n", "`t")
            if ($v) { return $v }
        }
    }
    return 'unknown'
}

function Get-CinesysTimestamp { (Get-Date).ToString('o') }

function ConvertTo-NativeText {
    # Under 2>&1, Windows PowerShell wraps each stderr line in an ErrorRecord
    # ("wpr.exe : At ... NativeCommandError"). Keep only the tool's own text.
    param($Lines)
    (@($Lines) | ForEach-Object {
        if ($_ -is [System.Management.Automation.ErrorRecord]) { $_.Exception.Message } else { [string]$_ }
    }) -join "`r`n"
}

function Invoke-Logman {
    param([Parameter(Mandatory=$true)][string[]]$Arguments)
    $ErrorActionPreference = 'Continue'
    $output = ConvertTo-NativeText (& logman.exe @Arguments 2>&1)
    $code = $LASTEXITCODE
    [pscustomobject]@{ Command = 'logman.exe ' + ($Arguments -join ' '); ExitCode = $code; Output = $output.Trim() }
}

function Invoke-Wpr {
    param([Parameter(Mandatory=$true)][string[]]$Arguments)
    $ErrorActionPreference = 'Continue'
    $output = ConvertTo-NativeText (& wpr.exe @Arguments 2>&1)
    $code = $LASTEXITCODE
    [pscustomobject]@{ Command = 'wpr.exe ' + ($Arguments -join ' '); ExitCode = $code; Output = $output.Trim() }
}

function Get-DcsState {
    param([Parameter(Mandatory=$true)][string]$Name)
    $r = Invoke-Logman -Arguments @('query', $Name)
    if ($r.ExitCode -ne 0) {
        return [pscustomobject]@{ Exists = $false; Status = $null; Raw = $r.Output }
    }
    $status = $null
    if ($r.Output -match '(?im)^\s*Status\s*:\s*(\S+)') { $status = $Matches[1] }
    elseif ($r.Output -match '(?im)\b(Running|Stopped)\b') { $status = $Matches[1] }
    [pscustomobject]@{ Exists = $true; Status = $status; Raw = $r.Output }
}

function Wait-DcsStatus {
    param(
        [Parameter(Mandatory=$true)][string]$Name,
        [Parameter(Mandatory=$true)][string]$Status,
        [int]$TimeoutSeconds = 20
    )
    $deadline = (Get-Date).AddSeconds($TimeoutSeconds)
    do {
        $s = Get-DcsState -Name $Name
        if ($s.Exists -and $s.Status -match "(?i)^$Status") { return $s }
        Start-Sleep -Milliseconds 500
    } while ((Get-Date) -lt $deadline)
    return (Get-DcsState -Name $Name)
}

function Get-CinesysDcsObject {
    param([Parameter(Mandatory=$true)][string]$Name)
    $dcs = New-Object -ComObject Pla.DataCollectorSet
    try { $dcs.Query("Service\$Name", $null) } catch { return $null }
    return $dcs
}

function Test-CinesysDcsOwnership {
    # Returns whether an existing DCS with this name belongs to this toolkit.
    # A DCS is ours if it carries the owner marker, or if it is a pre-v3.9
    # Cinesys DCS (rooted under the Cinesys PerfLogs folder or carrying the
    # Cinesys configuration collectors).
    param(
        [Parameter(Mandatory=$true)][string]$Name,
        [Parameter(Mandatory=$true)][string]$PerfLogRoot
    )
    $dcs = Get-CinesysDcsObject -Name $Name
    if ($null -eq $dcs) { return [pscustomobject]@{ Exists = $false; Owned = $false; Legacy = $false; Reason = 'Not registered' } }

    $description = [string]$dcs.Description
    $keywords = @($dcs.Keywords | ForEach-Object { [string]$_ })
    if ($description -match [regex]::Escape($script:OwnerMarker) -or $keywords -contains $script:OwnerMarker) {
        return [pscustomobject]@{ Exists = $true; Owned = $true; Legacy = $false; Reason = 'Owner marker present' }
    }

    $root = [Environment]::ExpandEnvironmentVariables([string]$dcs.RootPath).TrimEnd('\')
    if ($root -and $root -ieq $PerfLogRoot.TrimEnd('\')) {
        return [pscustomobject]@{ Exists = $true; Owned = $true; Legacy = $true; Reason = "Pre-v3.9 Cinesys DCS (RootPath $root)" }
    }
    $collectorNames = @()
    for ($i = 0; $i -lt [int]$dcs.DataCollectors.Count; $i++) { $collectorNames += [string]$dcs.DataCollectors.Item($i).Name }
    $matched = @($collectorNames | Where-Object { $script:LegacyCollectorNames -contains $_ })
    if ($matched.Count -gt 0) {
        return [pscustomobject]@{ Exists = $true; Owned = $true; Legacy = $true; Reason = "Pre-v3.9 Cinesys DCS (collectors: $($matched -join ', '))" }
    }
    return [pscustomobject]@{ Exists = $true; Owned = $false; Legacy = $false; Reason = "RootPath '$root', no Cinesys owner marker or collectors" }
}

function Set-CinesysDcsCaptureSettings {
    # Stamps the owner marker and forces the DCS to run until explicitly
    # stopped. Returns the settings found before the change so they can be
    # recorded; a leftover Duration or segment limit on the persistent DCS
    # silently truncates captures.
    param(
        [Parameter(Mandatory=$true)][string]$Name,
        [Parameter(Mandatory=$true)][string]$PerfLogRoot
    )
    $dcs = Get-CinesysDcsObject -Name $Name
    if ($null -eq $dcs) { throw "Data Collector Set '$Name' could not be opened through PLA." }

    $previous = [ordered]@{
        Duration           = [uint32]$dcs.Duration
        Segment            = [bool]$dcs.Segment
        SegmentMaxDuration = [uint32]$dcs.SegmentMaxDuration
        SegmentMaxSize     = [uint32]$dcs.SegmentMaxSize
        SchedulesEnabled   = [bool]$dcs.SchedulesEnabled
        ScheduleCount      = [int]$dcs.Schedules.Count
        StopOnCompletion   = [bool]$dcs.StopOnCompletion
        Description        = [string]$dcs.Description
        RootPath           = [string]$dcs.RootPath
        SubdirectoryFormat = [int]$dcs.SubdirectoryFormat
        SubdirectoryFormatPattern = [string]$dcs.SubdirectoryFormatPattern
        CounterCollectors  = @()
    }

    # PLA creates one run folder per start: <COMPUTER>_yyyyMMdd-NNNNNN under
    # RootPath, the same layout as the built-in System Diagnostics set.
    # Performance Monitor > Reports lists the run folders PLA created, so this
    # is what keeps every run visible there. v3.8/v3.9.0 created the folder in
    # the script and pointed the collector at it with an absolute path, so PLA
    # only knew about the latest run.
    # SubdirectoryFormat 3 = plaComputer (2) | plaPattern (1).
    $dcs.RootPath = $PerfLogRoot
    $dcs.Subdirectory = ''
    $dcs.SubdirectoryFormat = 3
    $dcs.SubdirectoryFormatPattern = 'yyyyMMdd\-NNNNNN'

    $dcs.Duration = 0
    $dcs.Segment = $false
    $dcs.SegmentMaxDuration = 0
    $dcs.SegmentMaxSize = 0
    $dcs.SchedulesEnabled = $false
    $dcs.Description = $script:OwnerDescription
    $keywords = @($dcs.Keywords | ForEach-Object { [string]$_ } | Where-Object { $_ -and $_ -ne $script:OwnerMarker })
    $dcs.Keywords = [string[]](@($keywords) + $script:OwnerMarker)

    for ($i = 0; $i -lt [int]$dcs.DataCollectors.Count; $i++) {
        $c = $dcs.DataCollectors.Item($i)
        if ([int]$c.DataCollectorType -eq 0) {
            # plaPerformanceCounter
            $previous.CounterCollectors += [ordered]@{
                Name              = [string]$c.Name
                FileName          = [string]$c.FileName
                FileNameFormat    = [int]$c.FileNameFormat
                SegmentMaxRecords = [uint32]$c.SegmentMaxRecords
                LogCircular       = [bool]$c.LogCircular
                SampleInterval    = [uint32]$c.SampleInterval
            }
            $c.SegmentMaxRecords = 0
            $c.LogCircular = $false
            # Relative name: the BLG lands in the PLA-created run folder as
            # Cinesys-Performance.blg (no _NNNNNN suffix).
            $c.FileName = 'Cinesys-Performance'
            $c.FileNameFormat = 0
        }
    }

    $validation = $dcs.Commit("Service\$Name", $null, 0x2)
    $messages = @()
    if ($validation -and [int]$validation.Count -gt 0) {
        for ($i = 0; $i -lt [int]$validation.Count; $i++) {
            $item = $validation.Item($i)
            $code = '0x{0:X8}' -f ([uint32]$item.Value)
            if ($code -ne '0x00300100') { $messages += "$($item.Key): $($item.Description) ($code)" }
        }
    }
    [pscustomobject]@{ Previous = $previous; ValidationMessages = $messages }
}

function Get-CinesysWprInstanceName { $script:WprInstanceName }

function Get-CinesysRunFolder {
    # The folder PLA created for the run that is in progress.
    param(
        [Parameter(Mandatory=$true)][string]$Name,
        [Parameter(Mandatory=$true)][string]$PerfLogRoot,
        [Parameter(Mandatory=$true)][datetime]$NotBefore
    )
    $dcs = Get-CinesysDcsObject -Name $Name
    if ($dcs) {
        foreach ($prop in @('OutputLocation','LatestOutputLocation')) {
            try {
                $p = [Environment]::ExpandEnvironmentVariables([string]$dcs.$prop)
                # Must be this run's folder, not the previous run's.
                if ($p -and (Test-Path $p) -and (Get-Item $p).CreationTime -ge $NotBefore.AddSeconds(-5)) {
                    return [pscustomobject]@{ Path = $p; Source = $prop }
                }
            } catch {}
        }
    }
    # Fallback: the newest run folder created after the start request.
    $d = Get-ChildItem $PerfLogRoot -Directory -ErrorAction SilentlyContinue |
        Where-Object { $_.Name -like "$($env:COMPUTERNAME)_*" -and $_.CreationTime -ge $NotBefore.AddSeconds(-5) } |
        Sort-Object CreationTime -Descending | Select-Object -First 1
    if ($d) { return [pscustomobject]@{ Path = $d.FullName; Source = 'NewestFolder' } }
    return $null
}

function Test-WprInstanceNameSupport {
    if (-not (Get-Command wpr.exe -ErrorAction SilentlyContinue)) { return $false }
    $ErrorActionPreference = 'Continue'
    $help = ConvertTo-NativeText (& wpr.exe -help start 2>&1)
    return ($help -match '(?i)-instancename')
}

function Get-BlgCoverage {
    # Reads the actual first/last sample time of a BLG with relog -q.
    param([Parameter(Mandatory=$true)][string]$Path)
    $ErrorActionPreference = 'Continue'
    $out = ConvertTo-NativeText (& relog.exe $Path -q 2>&1)
    $code = $LASTEXITCODE
    $begin = $null; $end = $null; $samples = $null
    if ($out -match '(?im)^\s*Begin:\s*(.+?)\s*$') { $begin = $Matches[1] }
    if ($out -match '(?im)^\s*End:\s*(.+?)\s*$') { $end = $Matches[1] }
    if ($out -match '(?im)^\s*Samples:\s*(\d+)') { $samples = [int]$Matches[1] }
    $beginDt = $null; $endDt = $null
    try { if ($begin) { $beginDt = [datetime]::Parse($begin) } } catch {}
    try { if ($end) { $endDt = [datetime]::Parse($end) } } catch {}
    [pscustomobject]@{
        File      = Split-Path $Path -Leaf
        Bytes     = (Get-Item $Path).Length
        ExitCode  = $code
        Begin     = $(if ($beginDt) { $beginDt.ToString('o') } else { $begin })
        End       = $(if ($endDt) { $endDt.ToString('o') } else { $end })
        Samples   = $samples
        Seconds   = $(if ($beginDt -and $endDt) { [int]($endDt - $beginDt).TotalSeconds } else { $null })
        BeginTime = $beginDt
        EndTime   = $endDt
    }
}

function Get-CinesysHostRole {
    $roles = @()
    try {
        $cs = Get-CimInstance Win32_ComputerSystem -ErrorAction Stop
        if ([string]$cs.Model -match '(?i)virtual machine') { $roles += 'HyperVGuest' }
    } catch {}
    if (Get-Command Get-VM -ErrorAction SilentlyContinue) {
        try { Get-VM -ErrorAction Stop | Out-Null; $roles += 'HyperVHost' } catch {}
    }
    if (Get-Command Get-ClusterNode -ErrorAction SilentlyContinue) {
        try { Get-ClusterNode -ErrorAction Stop | Out-Null; $roles += 'ClusterNode' } catch {}
    }
    if (Get-Command Get-IscsiSession -ErrorAction SilentlyContinue) {
        try { if (@(Get-IscsiSession -ErrorAction Stop).Count -gt 0) { $roles += 'IscsiInitiator' } } catch {}
    }
    if (Get-Command Get-SmbShare -ErrorAction SilentlyContinue) {
        try { if (@(Get-SmbShare -Special $false -ErrorAction Stop).Count -gt 0) { $roles += 'SmbServer' } } catch {}
    }
    if ($roles.Count -eq 0) { $roles += 'Standalone' }
    return $roles
}

function Start-CinesysPathHealth {
    # Launches Watch-CinesysPathHealth.ps1 as a separate hidden process so it
    # keeps polling after Start exits.
    param(
        [Parameter(Mandatory=$true)][string]$CapturePath,
        [int]$IntervalSeconds = 5
    )
    $watcher = Join-Path $PSScriptRoot 'Watch-CinesysPathHealth.ps1'
    if (!(Test-Path $watcher)) { throw "Path-health poller is missing: $watcher" }
    $stopFile = Join-Path $CapturePath 'Path-Health.stop'
    Remove-Item $stopFile -Force -ErrorAction SilentlyContinue
    $exe = Join-Path $PSHOME 'powershell.exe'
    if (!(Test-Path $exe)) { $exe = (Get-Process -Id $PID).Path }
    $argLine = '-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "{0}" -CapturePath "{1}" -StopFile "{2}" -IntervalSeconds {3}' -f $watcher, $CapturePath, $stopFile, $IntervalSeconds
    $p = Start-Process -FilePath $exe -ArgumentList $argLine -WindowStyle Hidden -PassThru
    [pscustomobject]@{ Pid = $p.Id; ProcessStart = $p.StartTime.ToString('o'); StopFile = $stopFile; Command = "$exe $argLine" }
}

function Stop-CinesysPathHealth {
    # Signals the poller through its stop file and waits for it to exit. Only a
    # process whose id AND start time match the one Start launched is ever
    # force-stopped, so a reused process id is never touched.
    param(
        [Parameter(Mandatory=$true)][int]$ProcessId,
        [string]$ProcessStart,
        [Parameter(Mandatory=$true)][string]$StopFile,
        [int]$TimeoutSeconds = 30
    )
    New-Item -ItemType File -Force -Path $StopFile | Out-Null
    $deadline = (Get-Date).AddSeconds($TimeoutSeconds)
    do {
        $proc = Get-Process -Id $ProcessId -ErrorAction SilentlyContinue
        $ours = $proc -and (-not $ProcessStart -or $proc.StartTime.ToString('o') -eq $ProcessStart)
        if (-not $ours) { return 'Exited' }
        Start-Sleep -Milliseconds 500
    } while ((Get-Date) -lt $deadline)
    try { Stop-Process -Id $ProcessId -Force -ErrorAction Stop; return "Force-stopped after $TimeoutSeconds s" }
    catch { return "Still running: $($_.Exception.Message)" }
}

function New-CinesysManifest {
    param(
        [Parameter(Mandatory=$true)][string]$CapturePath,
        [Parameter(Mandatory=$true)][hashtable]$Properties
    )
    $os = $null
    try { $os = Get-CimInstance Win32_OperatingSystem -ErrorAction Stop } catch {}
    $manifest = [ordered]@{
        ManifestVersion = 1
        ToolVersion     = Get-CinesysVersion
        Host            = $env:COMPUTERNAME
        Roles           = @(Get-CinesysHostRole)
        OS              = $(if ($os) { "$($os.Caption) build $($os.BuildNumber)" } else { $null })
        UtcOffset       = (Get-Date).ToString('zzz')
        CapturePath     = $CapturePath
        Status          = 'Starting'
        Started         = Get-CinesysTimestamp
        Stopped         = $null
        Parameters      = $Properties
        Dcs             = [ordered]@{ Name = $null; Action = $null; Ownership = $null; PreviousSettings = $null; ValidationMessages = @() }
        Collectors      = [ordered]@{
            PerfMon = [ordered]@{ StartRequested = $null; StartConfirmed = $null; StopRequested = $null; StopConfirmed = $null; CounterCount = $null; Files = @(); Error = $null }
            ETW     = [ordered]@{ Requested = $true; Started = $false; Profiles = @(); ProfileFile = $null; ProviderSummary = $null; Mode = $null; InstanceName = $null; StartRequested = $null; StartConfirmed = $null; StopRequested = $null; StopCompleted = $null; StartCommand = $null; StartExitCode = $null; StartOutput = $null; StopCommand = $null; StopExitCode = $null; StopOutput = $null; Fallback = $null; Error = $null; File = $null; Bytes = $null }
            PreSnapshot  = [ordered]@{ Started = $null; Completed = $null; Error = $null }
            PostSnapshot = [ordered]@{ Started = $null; Completed = $null; Error = $null }
            ClusterLog   = [ordered]@{ Collected = $false; TimeSpanMinutes = $null; Error = $null }
            Topology     = [ordered]@{ PreStarted = $null; PreCompleted = $null; PreError = $null; PostStarted = $null; PostCompleted = $null; PostError = $null }
            PacketCapture = [ordered]@{ Mode = 'None'; Syntax = $null; Started = $false; Filters = @(); Commands = @(); EtlFile = $null; PcapFile = $null; CountersFile = $null; StartRequested = $null; StartConfirmed = $null; Stopped = $null; Output = $null; Error = $null }
            PathHealth   = [ordered]@{ Started = $false; Pid = $null; ProcessStart = $null; IntervalSeconds = $null; StopFile = $null; Command = $null; Stopped = $null; StopResult = $null; Error = $null }
        }
        Warnings        = @()
        Events          = @()
    }
    Save-CinesysManifest -CapturePath $CapturePath -Manifest $manifest
    return (Read-CinesysManifest -CapturePath $CapturePath)
}

function Read-CinesysManifest {
    param([Parameter(Mandatory=$true)][string]$CapturePath)
    $p = Join-Path $CapturePath 'Capture-Manifest.json'
    if (!(Test-Path $p)) { return $null }
    return (Get-Content $p -Raw | ConvertFrom-Json)
}

function Save-CinesysManifest {
    param(
        [Parameter(Mandatory=$true)][string]$CapturePath,
        [Parameter(Mandatory=$true)]$Manifest
    )
    $p = Join-Path $CapturePath 'Capture-Manifest.json'
    $Manifest | ConvertTo-Json -Depth 8 | Set-Content -Path $p -Encoding UTF8
}

function Add-CinesysManifestEvent {
    param(
        [Parameter(Mandatory=$true)]$Manifest,
        [Parameter(Mandatory=$true)][string]$Step,
        [Parameter(Mandatory=$true)][string]$Result,
        [string]$Detail
    )
    $Manifest.Events = @($Manifest.Events) + [pscustomobject]@{ Time = Get-CinesysTimestamp; Step = $Step; Result = $Result; Detail = $Detail }
}

function Add-CinesysManifestWarning {
    param(
        [Parameter(Mandatory=$true)]$Manifest,
        [Parameter(Mandatory=$true)][string]$Message
    )
    # Recorded only. Start/Stop print every warning once at the end.
    $Manifest.Warnings = @($Manifest.Warnings) + $Message
}

Export-ModuleMember -Function *
