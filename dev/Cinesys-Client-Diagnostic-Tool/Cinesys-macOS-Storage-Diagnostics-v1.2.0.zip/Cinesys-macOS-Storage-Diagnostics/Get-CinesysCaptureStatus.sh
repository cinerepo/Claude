#!/bin/zsh
[ -z "$ZSH_VERSION" ] && exec /bin/zsh "$0" "$@"
# Shows whether a capture is running, for how long, and whether every
# collector is still alive. Safe to run at any time; does not need sudo.
#
#     zsh Get-CinesysCaptureStatus.sh

CINESYS_ROOT=${0:A:h}
source "$CINESYS_ROOT/lib/common.zsh"

if ! cs_read_state; then
    print -r -- "No capture is running."
    print -r -- "Earlier captures are in $CINESYS_DEFAULT_OUTPUT (unless --output was used)."
    exit 0
fi
source $CAP/Raw/config.zsh

el=$(( EPOCHSECONDS - START_EPOCH ))
printf 'Capture running since %s (%dh %02dm %02ds)\n' "$STARTED" $(( el / 3600 )) $(( el % 3600 / 60 )) $(( el % 60 ))
print -r -- "Folder: $CAP ($(cs_bytes_h $(cs_dir_bytes $CAP)))"
[[ -n $LABEL ]] && print -r -- "Label:  $LABEL"
(( DURATION > 0 )) && print -r -- "Stops by itself after $DURATION minutes."
[[ -f $CAP/Raw/stopping ]] && print -r -- "Stop is in progress."
print -r -- ""
print -r -- "Collectors:"
while IFS=$'\t' read -r name pid started out match; do
    if cs_pid_is $pid "$match"; then st=running; else st="NOT RUNNING"; fi
    sz=""
    [[ $out != - && -f $CAP/$out ]] && sz=$(cs_bytes_h $(stat -f %z $CAP/$out))
    printf '  %-14s %-12s %s\n' $name $st $sz
done < $CAP/Raw/collectors.tsv

if [[ -s $CAP/Raw/sampler.csv ]]; then
    n=$(( $(wc -l < $CAP/Raw/sampler.csv) - 1 ))
    last=$(tail -1 $CAP/Raw/sampler.csv | cut -d, -f1)
    [[ $last == <-> ]] && print -r -- "" && print -r -- "Samples: $n, newest $(( EPOCHSECONDS - last )) s ago"
fi
if [[ -s $CAP/Raw/warnings.txt ]]; then
    print -r -- ""
    print -r -- "Warnings:"
    sed 's/^/  /' $CAP/Raw/warnings.txt
fi
nchg=$(awk -F, 'NR>1 && $4 != "\"(baseline)\""' $CAP/Path-Health-Changes.csv 2>/dev/null | wc -l | tr -d ' ')
(( nchg > 0 )) && { print -r -- ""; print -r -- "Path changes so far: $nchg (latest below)"; awk -F, 'NR>1 && $4 != "\"(baseline)\""' $CAP/Path-Health-Changes.csv | tail -5 | sed 's/^/  /' }
exit 0
