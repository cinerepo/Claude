#!/bin/zsh
[ -z "$ZSH_VERSION" ] && exec /bin/zsh "$0" "$@"
# Packs a capture folder for sending to Cinesys.
#
#     zsh New-CinesysPackage.sh --capture <folder>                 summary (default)
#     zsh New-CinesysPackage.sh --capture <folder> --kind full
#
# Summary: everything except the packet capture and the I/O trace, usually a
# few MB. Send this first.
# Full: the whole folder.
# The zip is written next to the capture folder unless --output is given.

CINESYS_ROOT=${0:A:h}
source "$CINESYS_ROOT/lib/common.zsh"

KIND=summary
CAPTURE=""
OUTDIR=""
while (( $# )); do
    case $1 in
        --capture) CAPTURE=$2; shift 2 ;;
        --kind) KIND=${(L)2}; shift 2 ;;
        --output) OUTDIR=$2; shift 2 ;;
        -h|--help) print "Usage: zsh New-CinesysPackage.sh --capture <folder> [--kind summary|full] [--output <folder>]"; exit 0 ;;
        *) cs_die "Unknown option: $1" ;;
    esac
done
[[ -n $CAPTURE ]] || cs_die "Give the capture folder: --capture <folder>"
[[ -d $CAPTURE ]] || cs_die "Capture folder not found: $CAPTURE"
[[ $KIND == (summary|full) ]] || cs_die "--kind must be summary or full."
CAPTURE=${CAPTURE:A}
name=${CAPTURE:t}
parent=${CAPTURE:h}
OUTDIR=${OUTDIR:-$parent}
mkdir -p $OUTDIR || cs_die "Cannot create $OUTDIR"
out=${OUTDIR:A}/$name.$KIND.zip
rm -f $out

print -r -- "Creating $out ..."
excluded=()
if [[ $KIND == summary ]]; then
    excluded=($CAPTURE/Raw/Packets*.pcapng*(N) $CAPTURE/Raw/FS-Usage.txt(N))
    ( cd $parent && zip -r -q -X $out $name -x "$name/Raw/Packets*.pcapng*" "$name/Raw/FS-Usage.txt" "$name/Raw/stopping" )
else
    ( cd $parent && zip -r -q -X $out $name -x "$name/Raw/stopping" )
fi
[[ -f $out ]] || cs_die "zip failed."
if cs_is_root && [[ -n ${SUDO_USER:-} ]]; then chown "$SUDO_USER" $out 2>/dev/null; fi

size=$(stat -f %z $out)
print -r -- "Package: $out ($(cs_bytes_h $size), $(zipinfo -1 $out | grep -vc '/$') files)"
if (( ${#excluded} )); then
    ex=0; for f in $excluded; do (( ex += $(stat -f %z $f) )); done
    print -r -- "Left out of the summary: ${#excluded} file(s), $(cs_bytes_h $ex) (packet capture / I/O trace). Cinesys will ask for the full package if needed."
fi
