#!/bin/zsh
[ -z "$ZSH_VERSION" ] && exec /bin/zsh "$0" "$@"
# Stops the running capture without processing it: no post snapshot, no
# summary, no package. The folder and everything recorded so far are kept.
# Use Stop-CinesysCapture.sh for a normal stop.
#
#     sudo zsh Cancel-CinesysCapture.sh

CINESYS_ROOT=${0:A:h}
source "$CINESYS_ROOT/lib/common.zsh"

cs_read_state || { print -r -- "No capture is running."; exit 0 }
source $CAP/Raw/config.zsh
if ! cs_is_root && [[ $ALLOW_NONROOT != yes ]]; then cs_die "Run with sudo:  sudo zsh $0"; fi
source $CINESYS_ROOT/lib/manifest.zsh

cs_log "Cancelling capture $CAP ..."
STOPPED=$(cs_now)
: > $CAP/Raw/collector-status.tsv
while IFS=$'\t' read -r name pid started out match; do
    if cs_pid_is $pid "$match"; then
        pkill -TERM -P $pid 2>/dev/null; kill -TERM $pid 2>/dev/null
        for i in {1..25}; do kill -0 $pid 2>/dev/null || break; sleep 0.2; done
        kill -0 $pid 2>/dev/null && { pkill -KILL -P $pid 2>/dev/null; kill -KILL $pid 2>/dev/null }
        print -r -- "$name	Cancelled	$STOPPED" >> $CAP/Raw/collector-status.tsv
    else
        print -r -- "$name	Had already exited	" >> $CAP/Raw/collector-status.tsv
    fi
done < <(tail -r $CAP/Raw/collectors.tsv)
cs_write_manifest Cancelled
if cs_is_root && [[ -n $SMB_USER && $SMB_USER != root ]]; then chown -R "$SMB_USER" "$CAP" 2>/dev/null; fi
rm -f $CINESYS_STATE $CAP/Raw/stopping
cs_log "Cancelled. Data recorded so far is kept in $CAP"
