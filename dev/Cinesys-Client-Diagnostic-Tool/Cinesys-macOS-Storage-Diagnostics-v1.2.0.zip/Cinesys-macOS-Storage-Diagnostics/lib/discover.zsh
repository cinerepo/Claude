# What to watch: storage targets, SMB mounts, adapters. Sourced after
# common.zsh and detect.zsh by Start-CinesysCapture.sh and
# Get-CinesysStorageInfo.sh.
#
#   cs_discover <storage report file>
#
# In:  ARG_SERVERS (from --target / --server; may be empty)
# Out: SERVER_IPS (every storage target), SERVER_NAME, TARGET_ROLE,
#      SMB_SERVERS, MOUNTS, MOUNT_INST, MOUNT_SHARE, MOUNT_SERVER,
#      STORAGE_IFS (adapters with live connections to a target),
#      WATCH_IFS (those plus every adapter with an IPv4 address), IF_LABEL

typeset -ga SERVER_IPS SMB_SERVERS MOUNTS STORAGE_IFS WATCH_IFS
typeset -gA SERVER_NAME TARGET_ROLE MOUNT_INST MOUNT_SHARE MOUNT_SERVER IF_LABEL

cs_add_role() {
    # ip role: adds the role once
    local cur=${TARGET_ROLE[$1]:-}
    [[ ", $cur, " == *", $2, "* ]] && return
    TARGET_ROLE[$1]=${cur:+$cur, }$2
}

cs_discover() {
    local s ip line mp rest srv share sip c r i role
    for s in $ARG_SERVERS; do
        ip=$(cs_resolve $s)
        [[ $ip == <0-255>.<0-255>.<0-255>.<0-255> ]] || cs_die "Cannot resolve '$s' to an IPv4 address."
        (( ${SERVER_IPS[(Ie)$ip]} )) || SERVER_IPS+=($ip)
        [[ $s != $ip ]] && SERVER_NAME[$ip]=$s
        cs_add_role $ip "named with --target"
    done

    # SMB shares (per-share counters need the mount)
    for line in ${(f)"$(cs_smb_mounts)"}; do
        mp=${line%%|*}; rest=${line#*|}; srv=${rest%%|*}; share=${rest#*|}
        sip=$(cs_resolve ${srv%:<->})      # mounted through a port forward: //host:port/share
        if (( ${#ARG_SERVERS} )); then
            (( ${SERVER_IPS[(Ie)$sip]} )) || continue
        else
            (( ${SERVER_IPS[(Ie)$sip]} )) || SERVER_IPS+=($sip)
            [[ ${srv%:<->} != $sip ]] && SERVER_NAME[$sip]=${srv%:<->}
        fi
        MOUNTS+=($mp); MOUNT_INST[$mp]="\\\\$srv\\$share"; MOUNT_SHARE[$mp]=$share; MOUNT_SERVER[$mp]=$sip
        SMB_SERVERS+=($sip); cs_add_role $sip "SMB server"
    done

    # Everything else the detectors found (NFS, StorNext MDC and DLC
    # gateways, iSCSI portals, NVMe/TCP targets). With --target, only the
    # named addresses are captured; the rest is still in the storage report.
    cs_detect $1
    local -a f
    for line in $CS_DET; do
        f=("${(@s:|:)line}")
        ip=$f[2]; [[ $ip == <0-255>.<0-255>.<0-255>.<0-255> && $ip != 127.* ]] || continue
        case "$f[1] $f[5]" in
            "SMB "*) role="SMB server"; SMB_SERVERS+=($ip) ;;
            "NFS "*) role="NFS server" ;;
            "STORNEXT mdc") role="StorNext metadata controller" ;;
            "STORNEXT gateway"|"STORNEXT flow") [[ $f[6] == *metadata* ]] && role="StorNext metadata controller" || role="StorNext DLC gateway" ;;
            "ISCSI "*) role="iSCSI portal" ;;
            "NEXIS "*) role="Avid NEXIS host" ;;
            "NVMEOF "*) role="NVMe/TCP target" ;;
            *) continue ;;
        esac
        if (( ${#ARG_SERVERS} )); then
            (( ${SERVER_IPS[(Ie)$ip]} )) || continue
        else
            (( ${SERVER_IPS[(Ie)$ip]} )) || SERVER_IPS+=($ip)
        fi
        cs_add_role $ip $role
    done
    SMB_SERVERS=(${(u)SMB_SERVERS})

    # Adapters: the ones live connections to a target use, the route to each
    # target, then every other adapter with an IPv4 address.
    for s in $SERVER_IPS; do
        for c in ${(f)"$(cs_conn_ifs $s)"}; do r=${${c#* }%% *}; [[ $r != unknown ]] && STORAGE_IFS+=($r); done
        r=$(cs_route_if $s); [[ -n $r && $r != lo0 ]] && WATCH_IFS+=($r)
    done
    STORAGE_IFS=(${(u)STORAGE_IFS:#lo0})
    for line in ${(f)"$(cs_ipv4_table)"}; do
        i=${line%% *}; [[ $i == lo0 ]] || WATCH_IFS+=($i)
    done
    WATCH_IFS=(${(u)STORAGE_IFS} ${(u)WATCH_IFS})
    WATCH_IFS=(${(u)WATCH_IFS})
    for i in $WATCH_IFS; do IF_LABEL[$i]=$(cs_if_label $i); done
}
