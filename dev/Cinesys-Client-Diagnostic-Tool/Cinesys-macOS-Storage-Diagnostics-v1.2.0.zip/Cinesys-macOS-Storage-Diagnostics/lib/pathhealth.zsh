#!/bin/zsh
# Path health watcher. Started in the background by Start-CinesysCapture.sh:
#     zsh lib/pathhealth.zsh <capture folder>
# Every 5 seconds: link state of each watched interface, the route to each
# server (catches traffic moving to Wi-Fi), server reachability, each SMB
# mount and its reconnect count. Writes Path-Health-Samples.csv and
# Path-Health-Changes.csv (same columns as the Windows toolkit, so the
# analyzer reads them). Also guards disk space and trace file sizes.

CAP=$1
CINESYS_ROOT=${0:A:h:h}
source "$CINESYS_ROOT/lib/common.zsh"
source "$CAP/Raw/config.zsh"
cs_load_hwports

SAMPLES=$CAP/Path-Health-Samples.csv
CHANGES=$CAP/Path-Health-Changes.csv
STEP=5
running=1
trap 'running=0' TERM INT HUP

[[ -f $SAMPLES ]] || print -r -- 'Time,Category,Key,State,Detail' > $SAMPLES
[[ -f $CHANGES ]] || print -r -- 'Time,Category,Key,Before,After' > $CHANGES

typeset -A last
csvq() { local s=${1//\"/\"\"}; print -rn -- "\"$s\"" }

record() {
    # category key state [detail]
    local k="$1|$2" now=$(cs_now)
    print -r -- "$now,$(csvq $1),$(csvq $2),$(csvq $3),$(csvq ${4:-})" >> $SAMPLES
    if [[ -z ${last[$k]+x} ]]; then
        print -r -- "$now,$(csvq $1),$(csvq $2),\"(baseline)\",$(csvq $3)" >> $CHANGES
    elif [[ ${last[$k]} != $3 ]]; then
        print -r -- "$now,$(csvq $1),$(csvq $2),$(csvq ${last[$k]}),$(csvq $3)" >> $CHANGES
        cs_log "Path change: $1 $2: ${last[$k]} -> $3" >/dev/null
    fi
    last[$k]=$3
}

stop_collector() {
    # name reason: stops a size-limited collector (packet capture, I/O trace)
    local line name pid rest
    for line in ${(f)"$(cat $CAP/Raw/collectors.tsv 2>/dev/null)"}; do
        name=${line%%$'\t'*}; rest=${line#*$'\t'}; pid=${rest%%$'\t'*}
        [[ $name == $1 || $name == $1-* ]] || continue
        if kill -0 $pid 2>/dev/null; then
            kill -TERM $pid 2>/dev/null
            print -r -- "$name	$(cs_now)	Stopped early	$2" >> $CAP/Raw/collector-notes.tsv
            cs_warn "$name stopped early: $2" 2>/dev/null
        fi
    done
}

typeset -A stopped
while (( running )); do
    t0=$EPOCHREALTIME
    tbl=$(cs_ipv4_table)
    for i in $WATCH_IFS; do
        st=$(cs_if_status $i); md=$(cs_if_media $i); mtu=$(cs_if_mtu $i)
        ip=$(print -r -- $tbl | awk -v d=$i '$1==d{print $2; exit}')
        record Link "${IF_LABEL[$i]:-$i}" "${st:-missing} ${md:-} mtu ${mtu:-?} ip ${ip:-none}"
    done
    for s in $SERVER_IPS; do
        rif=$(cs_route_if $s)
        record Route $s "${rif:-none} ${CS_HWPORT[$rif]:-}"
        rtt=$(ping -n -c 1 -t 1 $s 2>/dev/null | awk -F'time=' '/time=/{split($2,a," "); print a[1]; exit}')
        if [[ -n $rtt ]]; then record Server $s reachable "$rtt ms"; else record Server $s "no reply"; fi
    done
    # Default route and gateway (the only path checked when there is no target)
    gw=$(cs_route_gw default); rif=$(cs_route_if default)
    record Route default "${rif:-none} ${CS_HWPORT[$rif]:-}"
    if [[ -n $gw && $gw == <0-255>.<0-255>.<0-255>.<0-255> ]]; then
        rtt=$(ping -n -c 1 -t 1 $gw 2>/dev/null | awk -F'time=' '/time=/{split($2,a," "); print a[1]; exit}')
        if [[ -n $rtt ]]; then record Gateway $gw reachable "$rtt ms"; else record Gateway $gw "no reply"; fi
    fi
    sess=$(cs_smb_sessions)
    mnt=$(cs_smb_mounts)
    for m in $MOUNTS; do
        if print -r -- $mnt | grep -qF -- "$m|"; then
            line=$(print -r -- $sess | grep -F -- "$m|" | head -1)
            rc=$(print -r -- $line | awk -F'|' '{print $6}')
            record 'SMB mount' "${MOUNT_INST[$m]}" "mounted reconnects ${rc:-?}"
        else
            record 'SMB mount' "${MOUNT_INST[$m]}" "not mounted"
        fi
    done

    # Safety: stop the packet capture and I/O trace if the disk is nearly full
    # or they grow past their limit.
    freemb=$(df -m "$CAP" 2>/dev/null | awk 'NR==2{print $4}')
    if [[ -n $freemb ]] && (( freemb < MIN_FREE_MB )); then
        for c in PacketCapture IoTrace; do
            [[ -z ${stopped[$c]:-} ]] && { stop_collector $c "less than $MIN_FREE_MB MB free on the capture volume"; stopped[$c]=1 }
        done
    fi
    if [[ -z ${stopped[IoTrace]:-} && -f $CAP/Raw/FS-Usage.txt ]]; then
        sz=$(stat -f %z $CAP/Raw/FS-Usage.txt 2>/dev/null)
        if (( ${sz:-0} > IOTRACE_MAX_MB * 1048576 )); then stop_collector IoTrace "I/O trace reached $IOTRACE_MAX_MB MB"; stopped[IoTrace]=1; fi
    fi

    # sleep the rest of the step in short slices so SIGTERM is handled quickly
    while (( running && EPOCHREALTIME - t0 < STEP )); do zselect -t 20 2>/dev/null; done
done
