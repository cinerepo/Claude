# Finds the network and SAN storage this Mac uses. Sourced after common.zsh.
#
#   cs_detect <report file>   fills CS_DET and writes the report (Storage-*.txt)
#
# Everything here only reads: mount, netstat, diskutil info, system_profiler,
# systemextensionsctl/kmutil listings, config files, and a fixed list of
# cvadmin queries. Nothing is mounted, unmounted, selected for writing,
# restarted or changed.
#
# CS_DET records, one per line: "protocol|ip|port|where|role|detail"
#   protocol  SMB NFS STORNEXT NEXIS ISCSI NVMEOF FC DISK
#   role      share mount mdc gateway portal target initiator hba disk flow fs

typeset -ga CS_DET

# Well-known ports. StorNext and Ardis DDP ports are configurable, so they are
# found from cvadmin output and live connections instead.
typeset -gA CS_PORT_PROTO=( [445]=SMB [2049]=NFS [3260]=ISCSI [4420]=NVMEOF [8009]=NVMEOF )

# The only cvadmin commands this toolkit ever runs. All of them only display.
CS_CVADMIN_OK=(select stat proxy 'proxy long' paths)

cs_det_add() {
    # protocol ip port where role detail
    local d=${6:--}; d=${d//|//}; d=${d//$'\n'/ }
    CS_DET+=("$1|${2:--}|${3:--}|${4:--}|$5|$d")
}

# "localip localport remoteip remoteport" for every established IPv4 TCP connection.
cs_tcp_est() {
    netstat -an -p tcp 2>/dev/null | awk '$1 ~ /^tcp4/ && $6 == "ESTABLISHED" {
        n = split($4, a, "."); m = split($5, b, ".")
        if (n == 5 && m == 5) print a[1] "." a[2] "." a[3] "." a[4], a[5], b[1] "." b[2] "." b[3] "." b[4], b[5] }'
}

cs_is_private() {
    [[ $1 == 10.* || $1 == 192.168.* || $1 == 169.254.* ]] && return 0
    [[ $1 == 172.* ]] && { local o=${${1#172.}%%.*}; (( o >= 16 && o <= 31 )) && return 0 }
    return 1
}

cs_cvadmin_bin() {
    local p
    for p in /Library/Filesystems/Xsan/bin/cvadmin /usr/cvfs/bin/cvadmin ${commands[cvadmin]:-}; do
        [[ -x $p ]] && { print -r -- $p; return 0 }
    done
    return 1
}

# cs_cvadmin <file system | -> <query>
# Refuses anything not on CS_CVADMIN_OK. stdin is closed so cvadmin can never
# wait for interactive input, and it is killed after 20 seconds.
cs_cvadmin() {
    local fs=$1 q=$2 bin
    (( ${CS_CVADMIN_OK[(Ie)$q]} )) || { print -r -- "(not run: '$q' is not on the read-only list)"; return 1 }
    bin=$(cs_cvadmin_bin) || { print -r -- "(cvadmin not found)"; return 1 }
    if [[ $fs == - ]]; then
        cs_timeout 20 $bin -e "$q" </dev/null 2>&1
    else
        [[ $fs == [A-Za-z0-9_.-]## ]] || { print -r -- "(not run: unexpected file system name '$fs')"; return 1 }
        cs_timeout 20 $bin -e "select $fs" -e "$q" </dev/null 2>&1
    fi
}

# "host:port" and bare IPv4 addresses mentioned in some text -> "ip port" lines
cs_hostports() {
    local hp h p ip
    for hp in ${(f)"$(print -r -- $1 | grep -oE '[A-Za-z0-9][A-Za-z0-9.-]*:[0-9]{2,5}' | sort -u)"}; do
        h=${hp%:*}; p=${hp##*:}
        [[ $h == <-> ]] && continue
        ip=$(cs_resolve $h)
        [[ $ip == <0-255>.<0-255>.<0-255>.<0-255> && $ip != 127.* ]] && print -r -- "$ip $p"
    done
    for ip in ${(f)"$(print -r -- $1 | grep -oE '\b([0-9]{1,3}\.){3}[0-9]{1,3}\b' | sort -u)"}; do
        [[ $ip == <0-255>.<0-255>.<0-255>.<0-255> && $ip != 127.* && $ip != 0.* ]] && print -r -- "$ip -"
    done
}

cs_rsec() {
    # report section: title, then the output of a command (already read-only)
    print -r -- ""
    print -r -- "===== $1 ====="
    print -r -- "\$ $2"
    cs_timeout ${3:-30} eval "$2" 2>&1
}

cs_detect() {
    local rpt=$1
    CS_DET=()
    local est; est=$(cs_tcp_est)
    local mnt; mnt=$(mount 2>/dev/null)
    # declared once: re-declaring a set variable with 'local' prints it in zsh
    local line ip port mp src l lp rip rp srv share f h fsn hp q pr t pp d info proto name size loc p hd
    local -a r

    # --- SMB ---------------------------------------------------------------
    for line in ${(f)"$(cs_smb_mounts)"}; do
        mp=${line%%|*}; src=${line#*|}
        srv=${src%%|*}; share=${src#*|}
        ip=$(cs_resolve ${srv%:<->}); port=445; [[ $srv == *:<-> ]] && port=${srv##*:}
        cs_det_add SMB "$ip" "$port" "$mp" share "\\\\$srv\\$share"
    done

    # --- NFS ---------------------------------------------------------------
    for line in ${(f)"$(print -r -- $mnt | grep -E '\((nfs|nfs4)[,)]')"}; do
        src=${line%% on *}; mp=${${line#* on }% \(*}
        ip=$(cs_resolve ${src%%:*})
        cs_det_add NFS "$ip" 2049 "$mp" mount "$src"
    done

    # --- StorNext / Xsan ---------------------------------------------------
    local -a sn_mounts sn_fs mdc gw
    local sn_text="" cvsel=""
    for line in ${(f)"$(print -r -- $mnt | grep -E '\((acfs|cvfs)[,)]')"}; do
        src=${line%% on *}; mp=${${line#* on }% \(*}
        sn_mounts+=($mp)
        [[ $src != /dev/* && $src == [A-Za-z0-9_.-]## ]] && sn_fs+=($src)
        [[ ${mp:t} == [A-Za-z0-9_.-]## ]] && sn_fs+=(${mp:t})
        cs_det_add STORNEXT - - "$mp" fs "mounted from $src"
    done
    # cvadmin ships with every Mac (Xsan is built in), so it is only run when
    # this Mac is set up as a StorNext/Xsan client.
    local -a nsfiles; nsfiles=(/Library/Preferences/Xsan/fsnameservers(N) /usr/cvfs/config/fsnameservers(N))
    local havesn=0 havecv=0
    (( ${#sn_mounts} || ${#nsfiles} )) || [[ -d /usr/cvfs ]] && havesn=1
    (( havesn )) && cs_cvadmin_bin >/dev/null && havecv=1
    if (( havesn )); then
        for f in $nsfiles; do
            for h in ${(f)"$(grep -v '^[[:space:]]*#' $f | awk 'NF{print $1}')"}; do
                ip=$(cs_resolve $h)
                [[ $ip == <0-255>.<0-255>.<0-255>.<0-255> ]] && mdc+=($ip) && cs_det_add STORNEXT "$ip" - "$f" mdc "name server $h"
            done
        done
        if (( havecv )); then
            cvsel=$(cs_cvadmin - select)
            # " 1>*snfs1[0]   located on mdc1:39121 (pid 1234)"
            for line in ${(f)"$(print -r -- $cvsel | grep -E '^[[:space:]]*[0-9]+>')"}; do
                fsn=${line#*>}; fsn=${fsn#\*}; fsn=${${fsn## #}%%\[*}
                [[ $fsn == [A-Za-z0-9_.-]## ]] && sn_fs+=($fsn)
                hp=${${line##*located on }%% *}
                if [[ $hp == *:<-> ]]; then
                    ip=$(cs_resolve ${hp%:*})
                    [[ $ip == <0-255>.<0-255>.<0-255>.<0-255> ]] && { mdc+=($ip); cs_det_add STORNEXT "$ip" "${hp##*:}" "$fsn" mdc "file system service" }
                fi
            done
            sn_fs=(${(u)sn_fs})
            for fsn in $sn_fs; do
                for q in stat proxy 'proxy long'; do
                    sn_text+=$'\n'"===== cvadmin: select $fsn; $q ====="$'\n'"$(cs_cvadmin $fsn $q)"$'\n'
                done
            done
            sn_text+=$'\n'"===== cvadmin: paths ====="$'\n'"$(cs_cvadmin - paths)"$'\n'
            # Addresses named in the proxy output that are not metadata
            # controllers are DLC gateways (or the proxy servers' data ports).
            mdc=(${(u)mdc})
            pr=$(print -r -- $sn_text | awk '/^===== cvadmin: select .*; proxy/{on=1; next} /^===== /{on=0} on')
            for line in ${(f)"$(cs_hostports $pr)"}; do
                ip=${line% *}; port=${line#* }
                (( ${mdc[(Ie)$ip]} )) && continue
                gw+=($ip)
                cs_det_add STORNEXT "$ip" "$port" - gateway "named in cvadmin proxy output"
            done
            gw=(${(u)gw})
        fi
        # Live connections to the MDCs and gateways (the DLC data port shows here)
        for line in ${(f)est}; do
            read l lp rip rp <<< $line
            if (( ${gw[(Ie)$rip]} )); then cs_det_add STORNEXT "$rip" "$rp" "$l" flow "DLC gateway connection"
            elif (( ${mdc[(Ie)$rip]} )); then cs_det_add STORNEXT "$rip" "$rp" "$l" flow "metadata controller connection"
            fi
        done
    fi

    # --- Initiators and drivers (iSCSI, Ardis DDP, NVMe-oF, FC, SAS) --------
    local sw
    sw=$( { systemextensionsctl list 2>/dev/null
            cs_timeout 30 kmutil showloaded --list-only 2>/dev/null | grep -v com.apple
            ls -1 /Applications /Library/Extensions /Library/PreferencePanes 2>/dev/null
            ps -axco comm= 2>/dev/null | grep -iE 'avid|nexis' | sed 's/^/process /'
          } | grep -iE 'atto|ardis|iscsi|globalsan|xtend|ddp|nvme.?of|nvmf|celerity|fibre|sanlink|promise|areca|highpoint|sonnet|lacie|avid|nexis' | sort -u)
    for line in ${(f)sw}; do
        t=${line//$'\t'/ }; t=${${t## #}% #}
        case ${(L)t} in
            *nexis*|*avid*) cs_det_add NEXIS - - - client "$t" ;;
            *iscsi*|*xtend*|*globalsan*) cs_det_add ISCSI - - - initiator "$t" ;;
            *ardis*|*ddp*) cs_det_add ISCSI - - - initiator "$t (Ardis DDP)" ;;
            *nvme*of*|*nvmf*) cs_det_add NVMEOF - - - initiator "$t" ;;
            *celerity*|*fibre*) cs_det_add FC - - - initiator "$t" ;;
            *) cs_det_add DISK - - - driver "$t" ;;
        esac
    done

    # Connections on well-known storage ports (iSCSI, NVMe/TCP; SMB and NFS
    # are listed so a session without a mount shows up too)
    for line in ${(f)est}; do
        read l lp rip rp <<< $line
        pp=${CS_PORT_PROTO[$rp]:-}
        [[ -z $pp ]] && continue
        case $pp in
            ISCSI) cs_det_add ISCSI "$rip" "$rp" "$l" portal "iSCSI session" ;;
            NVMEOF) cs_det_add NVMEOF "$rip" "$rp" "$l" target "NVMe/TCP connection" ;;
            *) cs_det_add "$pp" "$rip" "$rp" "$l" flow "connection" ;;
        esac
    done

    # --- Avid NEXIS: mounted workspaces and the hosts the client talks to -----
    # NEXIS data is UDP through Avid's own client, so no SMB counter sees it.
    for line in ${(f)"$(print -r -- $mnt | grep -iE '\((avid|nexis|fos)[a-z]*[,)]')"}; do
        src=${line%% on *}; mp=${${line#* on }% \(*}
        cs_det_add NEXIS - - "$mp" mount "workspace $src"
    done
    local nxpeers=""
    if print -r -- ${(F)CS_DET} | grep -q '^NEXIS|'; then
        # sockets of Avid processes (all processes need sudo)
        nxpeers=$(lsof -nP -iTCP -iUDP 2>/dev/null | grep -iE '^(avid|nexis)' | awk '{print $8, $9}' | grep -- '->' | sort -u)
        for line in ${(f)nxpeers}; do
            local pr=${line%% *} peer=${${line#*->}%% *}
            ip=${peer%:*}; port=${peer##*:}
            [[ $ip == <0-255>.<0-255>.<0-255>.<0-255> && $ip != 127.* ]] && cs_det_add NEXIS "$ip" "$port" - flow "$pr socket of the NEXIS client"
        done
    fi

    # --- Fibre Channel HBAs -------------------------------------------------
    local fc; fc=$(cs_timeout 60 system_profiler SPFibreChannelDataType 2>/dev/null)
    if [[ -n ${fc//[[:space:]]/} && $fc == *[A-Za-z]*:*[A-Za-z]* && $(print -r -- $fc | wc -l) -gt 2 ]]; then
        hd=$(print -r -- $fc | grep -iE 'model|status|speed|link|port wwn|^ +port' | sed 's/^ *//' | head -12 | paste -sd ';' -)
        cs_det_add FC - - - hba "$hd"
    fi

    # --- Disks: how each physical disk is attached --------------------------
    for d in ${(f)"$(diskutil list physical 2>/dev/null | awk '/^\/dev\/disk[0-9]+/{print $1}')"}; do
        info=$(cs_timeout 15 diskutil info $d 2>/dev/null)
        proto=$(print -r -- $info | awk -F': *' '/^ *Protocol:/{print $2; exit}')
        name=$(print -r -- $info | awk -F': *' '/Device \/ Media Name:/{print $2; exit}')
        size=$(print -r -- $info | awk -F': *' '/^ *Disk Size:/{split($2,a," \\("); print a[1]; exit}')
        loc=$(print -r -- $info | awk -F': *' '/^ *Device Location:/{print $2; exit}')
        p=DISK
        case ${(L)proto} in *fibre*) p=FC ;; *iscsi*) p=ISCSI ;; *nvme*fabric*|*nvme-of*|*nvmeof*) p=NVMEOF ;; esac
        cs_det_add "$p" - - "$d" disk "$proto, $name, $size${loc:+, "$loc"}"
    done

    # --- Report ---------------------------------------------------------------
    {
        print -r -- "Cinesys Storage Diagnostics for macOS $CINESYS_VERSION - storage on this Mac"
        print -r -- "Host: ${HOSTTAG:-$(hostname -s)}   Written: $(cs_now)"
        print -r -- "Only read-only commands are used (cvadmin: ${(j:, :)CS_CVADMIN_OK})."
        print -r -- ""
        print -r -- "FOUND"
        print -r -- "-----"
        printf '%-9s %-10s %-16s %-6s %-28s %s\n' Protocol Role Address Port Where Detail
        for line in $CS_DET; do
            r=("${(@s:|:)line}")
            printf '%-9s %-10s %-16s %-6s %-28s %s\n' $r[1] $r[5] $r[2] $r[3] $r[4] $r[6]
        done
        (( ${#CS_DET} )) || print -r -- "(no network or SAN storage found)"
        if (( havesn )); then
            print -r -- ""
            print -r -- "STORNEXT / XSAN CLIENT MODE"
            print -r -- "---------------------------"
            if (( ${#gw} )) && print -r -- ${(F)CS_DET} | grep -q '^STORNEXT|.*|flow|DLC'; then
                print -r -- "LAN client (DLC): data goes through gateway(s) ${gw[*]}"
            elif (( ${#gw} )); then
                print -r -- "Gateways are listed by cvadmin (${gw[*]}) but no connection to them is open right now"
            elif print -r -- ${(F)CS_DET} | grep -qE '^(FC|ISCSI)\|.*\|disk\|'; then
                print -r -- "SAN client (no DLC gateway found; FC or iSCSI disks are present)"
            else
                print -r -- "Not determined (no gateway in cvadmin output and no SAN disks found)"
            fi
        fi

        print -r -- ""
        print -r -- "OTHER CONNECTIONS TO PRIVATE ADDRESSES (configurable storage ports show up here)"
        print -r -- "--------------------------------------------------------------------------------"
        print -r -- $est | awk '{print $3":"$4}' | while read hp; do cs_is_private ${hp%:*} && print -r -- $hp; done | sort | uniq -c | sort -rn | head -40

        cs_rsec 'MOUNTS' 'mount'
        print -r -- $mnt | grep -qE '\((nfs|nfs4)[,)]' && cs_rsec 'NFS MOUNT OPTIONS' 'nfsstat -m'
        if (( havesn )); then
            print -r -- ""
            print -r -- "===== cvadmin: select ====="
            print -r -- ${cvsel:-"(cvadmin not found)"}
            print -r -- $sn_text
            cs_rsec 'STORNEXT / XSAN CONFIGURATION FILES (names only, except name servers)' \
                'ls -la /Library/Preferences/Xsan /usr/cvfs/config 2>/dev/null; for f in /Library/Preferences/Xsan/fsnameservers /usr/cvfs/config/fsnameservers; do [[ -f $f ]] && { print "--- $f"; cat $f } ; done'
            cs_rsec 'STORNEXT / XSAN CLIENT LOGS (newest 150 lines each)' \
                'for f in /Library/Logs/Xsan/debug/*.out(N) /usr/cvfs/debug/*.out(N); do print "--- $f"; tail -150 $f; done'
        fi
        [[ -n $sw ]] && { print -r -- ""; print -r -- "===== STORAGE DRIVERS AND INITIATORS (extensions, applications) ====="; print -r -- $sw }
        if print -r -- ${(F)CS_DET} | grep -q '^NEXIS|'; then
            print -r -- ""; print -r -- "===== AVID NEXIS CLIENT SOCKETS (lsof, sudo shows all) ====="; print -r -- ${nxpeers:-"(none found)"}
            cs_rsec 'UDP FLOWS (nettop, busiest first)' 'nettop -m udp -L 1 -n -x -J bytes_in,bytes_out 2>/dev/null | sort -t, -k3 -rn | head -25' 20
        fi
        [[ -n ${fc//[[:space:]]/} ]] && { print -r -- ""; print -r -- "===== FIBRE CHANNEL (system_profiler SPFibreChannelDataType) ====="; print -r -- $fc }
        cs_rsec 'PHYSICAL DISKS' 'diskutil list physical'
        for d in ${(f)"$(diskutil list physical 2>/dev/null | awk '/^\/dev\/disk[0-9]+/{print $1}')"}; do
            cs_rsec "DISK $d" "diskutil info $d" 15
        done
    } > $rpt 2>&1
}
