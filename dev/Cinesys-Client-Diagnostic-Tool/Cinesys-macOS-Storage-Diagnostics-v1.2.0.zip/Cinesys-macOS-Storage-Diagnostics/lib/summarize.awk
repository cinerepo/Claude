# Statistics and throughput drops from Cinesys-Performance.csv.
#   awk -v stalls=Stalls.csv -v mindrop=2 -v names="nas01=10.1.2.3" -f summarize.awk Cinesys-Performance.csv
# Prints the body of Capture-Summary.txt; writes one Stalls.csv row per drop.

BEGIN {
    FS = ","; MB = 1048576
    # server name -> IP, for shares mounted by name ("nas01=10.1.2.3;...")
    n = split(names, NP, ";"); for (i = 1; i <= n; i++) { split(NP[i], kv, "="); if (kv[1] != "") NAMEIP[kv[1]] = kv[2] }
    # target IP -> role ("10.1.2.3=StorNext DLC gateway;...")
    n = split(roles, NP, ";"); for (i = 1; i <= n; i++) { k = index(NP[i], "="); if (k) ROLE[substr(NP[i], 1, k - 1)] = substr(NP[i], k + 1) }
}

function unq(s) { gsub(/"/, "", s); return s }
function num(s) { return (s == "") ? "" : s + 0 }
# "10/15/2026 16:34:16.769" -> "2026-10-15 16:34:16"
function iso(t) { t = unq(t); return substr(t, 7, 4) "-" substr(t, 1, 2) "-" substr(t, 4, 2) " " substr(t, 12, 8) }

function qsort(A, lo, hi,   i, last, t) {
    if (lo >= hi) return
    t = A[lo]; A[lo] = A[int((lo + hi) / 2)]; A[int((lo + hi) / 2)] = t
    last = lo
    for (i = lo + 1; i <= hi; i++) if (A[i] < A[lo]) { last++; t = A[last]; A[last] = A[i]; A[i] = t }
    t = A[lo]; A[lo] = A[last]; A[last] = t
    qsort(A, lo, last - 1); qsort(A, last + 1, hi)
}
# percentile of column c over all rows (or only rows where column g >= gmin)
function pct(c, p, g, gmin,   n, i, A) {
    n = 0
    for (i = 1; i <= rows; i++) {
        if (V[i, c] == "") continue
        if (g && (V[i, g] == "" || V[i, g] < gmin)) continue
        A[++n] = V[i, c]
    }
    if (n == 0) return ""
    qsort(A, 1, n)
    return A[int((n - 1) * p) + 1]
}
function mx(c,   i, m) { m = ""; for (i = 1; i <= rows; i++) if (V[i, c] != "" && (m == "" || V[i, c] > m)) m = V[i, c]; return m }
function mn(c,   i, m) { m = ""; for (i = 1; i <= rows; i++) if (V[i, c] != "" && (m == "" || V[i, c] < m)) m = V[i, c]; return m }
function sum(c,   i, s) { s = 0; for (i = 1; i <= rows; i++) if (V[i, c] != "") s += V[i, c]; return s }
function avgwhere(c, g, gmin,   i, s, n) { s = 0; n = 0; for (i = 1; i <= rows; i++) if (V[i, c] != "" && V[i, g] != "" && V[i, g] >= gmin) { s += V[i, c]; n++ } return n ? s / n : "" }
function f1(x) { return (x == "") ? "n/a" : sprintf("%.1f", x) }
function f0(x) { return (x == "") ? "n/a" : sprintf("%.0f", x) }
function mbs(x) { return (x == "") ? "n/a" : sprintf("%.1f MB/s", x / MB) }
function rmax(c, a, b,   i, m) { m = ""; for (i = a; i <= b; i++) if (i >= 1 && i <= rows && V[i, c] != "" && (m == "" || V[i, c] > m)) m = V[i, c]; return m }
function rsum(c, a, b,   i, s) { s = 0; for (i = a; i <= b; i++) if (i >= 1 && i <= rows && V[i, c] != "") s += V[i, c]; return s }
function ravg(c, a, b,   i, s, n) { s = 0; n = 0; for (i = a; i <= b; i++) if (i >= 1 && i <= rows && V[i, c] != "") { s += V[i, c]; n++ } return n ? s / n : "" }

# Header names are quoted and can contain commas ("Processor Information(0,3)");
# data rows are plain numbers.
function splithdr(line, H,   n, q, i, ch, f) {
    n = 0; q = 0; f = ""
    for (i = 1; i <= length(line); i++) {
        ch = substr(line, i, 1)
        if (ch == "\"") q = !q
        else if (ch == "," && !q) { H[++n] = f; f = "" }
        else f = f ch
    }
    H[++n] = f
    return n
}

NR == 1 {
    nh = splithdr($0, HDR)
    for (i = 2; i <= nh; i++) {
        h = HDR[i]; sub(/^\\\\[^\\]+\\/, "", h)
        obj = h; sub(/[(\\].*/, "", obj)
        inst = ""; if (h ~ /\(/) { inst = h; sub(/^[^(]*\(/, "", inst); sub(/\)\\[^\\]*$/, "", inst) }
        ctr = h; sub(/.*\\/, "", ctr)
        O[i] = obj; I[i] = inst; C[i] = ctr; ncol = nh
        if (obj == "Processor Information" && inst ~ /^0,[0-9]+$/) corecols[++ncores] = i
    }
    next
}
{
    rows++; T[rows] = $1
    for (i = 2; i <= NF; i++) V[rows, i] = num($i)
}

function col(o, inst, c,   i) { for (i = 2; i <= ncol; i++) if (O[i] == o && I[i] == inst && C[i] == c) return i; return 0 }

END {
    if (rows == 0) { print "No samples were recorded."; exit }
    printf "Samples: %d, from %s to %s\n\n", rows, iso(T[1]), iso(T[rows])

    # busiest core per row
    if (ncores) for (r = 1; r <= rows; r++) { m = ""; for (k = 1; k <= ncores; k++) { v = V[r, corecols[k]]; if (v != "" && (m == "" || v > m)) m = v } BUSY[r] = m }

    # --- SMB shares --------------------------------------------------------
    print "SMB SHARES (bytes the SMB session sent and received, including protocol overhead)"
    print "------------------------------------------------------------------------------------"
    ns = 0
    for (i = 2; i <= ncol; i++) if (O[i] == "SMB Client Shares" && C[i] == "Read Bytes/sec") {
        ns++; inst = I[i]; rc = i; wc = col("SMB Client Shares", inst, "Write Bytes/sec"); rcc = col("SMB Client Shares", inst, "Reconnect Count")
        printf "%s\n", inst
        for (d = 1; d <= 2; d++) {
            c = (d == 1) ? rc : wc; dir = (d == 1) ? "read " : "write"
            p95 = pct(c, 0.95, c, MB); pk = mx(c); tot = sum(c)
            thr = (p95 == "") ? 0 : p95 * 0.25; if (thr < 5 * MB) thr = 5 * MB
            printf "    %s  peak %s, typical while active %s, p95 while active %s, total %.2f GB\n", dir, mbs(pk), mbs(avgwhere(c, c, thr)), mbs(p95), tot / 1073741824
        }
        if (rcc) { a = mn(rcc); b = mx(rcc); if (a != "" && b > a) printf "    RECONNECTED %d time(s) during the capture\n", b - a }
        SHARE[ns] = inst; SR[ns] = rc; SW[ns] = wc
        split(inst, parts, "\\"); srv = parts[3]; sub(/:[0-9]+$/, "", srv); if (srv in NAMEIP) srv = NAMEIP[srv]; SRV[ns] = srv
    }
    if (!ns) print "(no SMB share counters: no share was mounted at Start)"
    print ""

    # --- Connections to the targets ----------------------------------------
    nc = 0
    for (i = 2; i <= ncol; i++) if ((O[i] == "SMB Client Connection" || O[i] == "Storage Connection") && C[i] == "Bytes Sent/sec") {
        if (!nc++) { print "STORAGE CONNECTIONS (TCP to each target, all ports, from nettop)"; print "----------------------------------------------------------------" }
        ip = I[i]; txc = i; rxc = col(O[i], ip, "Bytes Received/sec"); rtc = col(O[i], ip, "Retransmitted Bytes/sec")
        duc = col(O[i], ip, "Duplicate Bytes Received/sec"); ooc = col(O[i], ip, "Out-of-Order Bytes Received/sec"); rttc = col(O[i], ip, "Round Trip Time ms"); rwc = col(O[i], ip, "Receive Window Bytes")
        tx = sum(txc); rt = sum(rtc)
        printf "%s%s\n", ip, (ip in ROLE) ? " - " ROLE[ip] : ""
        printf "    received peak %s, sent peak %s\n", mbs(mx(rxc)), mbs(mx(txc))
        printf "    retransmitted %.1f MB of %.1f MB sent (%.2f%%), peak %s\n", rt / MB, tx / MB, tx ? 100 * rt / tx : 0, mbs(mx(rtc))
        printf "    received duplicate %.1f MB, out of order %.1f MB\n", sum(duc) / MB, sum(ooc) / MB
        printf "    round trip (smoothed) median %s ms, p95 %s ms, max %s ms; largest receive window %s KB\n", f1(pct(rttc, 0.5)), f1(pct(rttc, 0.95)), f1(mx(rttc)), f0(mx(rwc) / 1024)
        CONN_RT[ip] = rtc; CONN_RTT[ip] = rttc; CONN_TX[ip] = txc
        # Non-SMB targets have no share counters: their connection bytes are
        # what the drop search looks at.
        if (O[i] == "Storage Connection") { ns++; SHARE[ns] = ip; SR[ns] = rxc; SW[ns] = txc; SRV[ns] = ip }
    }
    if (nc) print ""

    # --- Traffic no tracked protocol accounts for (Avid NEXIS is UDP) --------
    ur = col("Network Unattributed", "_Total", "Bytes Received/sec"); ut = col("Network Unattributed", "_Total", "Bytes Sent/sec")
    if (ur && (mx(ur) >= 5 * MB || mx(ut) >= 5 * MB)) {
        print "OTHER NETWORK TRAFFIC (en* adapters minus the storage connections above)"
        print "-------------------------------------------------------------------------"
        if (nexis) print "The Avid NEXIS client is installed: its data is UDP, so it is counted here."
        for (d = 1; d <= 2; d++) {
            c = (d == 1) ? ur : ut; dir = (d == 1) ? "received" : "sent    "
            p95 = pct(c, 0.95, c, MB); thr = (p95 == "") ? 0 : p95 * 0.25; if (thr < 5 * MB) thr = 5 * MB
            printf "    %s peak %s, typical while active %s, total %.2f GB\n", dir, mbs(mx(c)), mbs(avgwhere(c, c, thr)), sum(c) / 1073741824
        }
        ns++; SHARE[ns] = (nexis ? "Avid NEXIS (other network traffic)" : "other network traffic"); SR[ns] = ur; SW[ns] = ut; SRV[ns] = ""
        print ""
    }

    # --- Adapters ----------------------------------------------------------
    print "ADAPTERS"
    print "--------"
    for (i = 2; i <= ncol; i++) if (O[i] == "Network Interface" && C[i] == "Bytes Received/sec") {
        inst = I[i]; tc = col(O[i], inst, "Bytes Sent/sec"); e1 = col(O[i], inst, "Packets Received Errors/sec"); e2 = col(O[i], inst, "Packets Outbound Errors/sec")
        pr = mx(i); pt = mx(tc)
        if (pr < MB && pt < MB) { printf "%-40s idle (under 1 MB/s)\n", inst; continue }
        printf "%-40s receive peak %s, send peak %s, errors in %d / out %d\n", inst, mbs(pr), mbs(pt), sum(e1), sum(e2)
    }
    print ""

    # --- TCP, memory, CPU, disks -------------------------------------------
    c = col("TCPv4", "", "Segments Retransmitted/sec")
    if (c) {
        printf "TCP (whole Mac): %d segments retransmitted (peak %s/s), %d retransmit timeouts, %d duplicate ACKs\n\n", sum(c), f0(mx(c)), sum(col("TCPv4", "", "Retransmit Timeouts/sec")), sum(col("TCPv4", "", "Duplicate Acks Received/sec"))
    } else print "TCP (whole Mac): not collected (needs sudo)\n"
    c = col("UDPv4", "", "Datagrams Received/sec")
    if (c) printf "UDP (whole Mac): peak %s datagrams/s received, %d receive errors, %d dropped because a socket buffer was full; IP fragments received %d, dropped %d\n\n", f0(mx(c)), sum(col("UDPv4", "", "Datagrams Received Errors/sec")), sum(col("UDPv4", "", "Receive Buffer Errors/sec")), sum(col("IPv4", "", "Fragments Received/sec")), sum(col("IPv4", "", "Fragment Re-assembly Failures/sec"))

    am = col("Memory", "", "Available MBytes"); pl = col("Memory", "", "Pressure Level"); po = col("Memory", "", "Pageouts/sec")
    printf "MEMORY: available min %s MB / max %s MB, pressure level max %s (1 normal, 2 warning, 4 critical), pageouts %d\n", f0(mn(am)), f0(mx(am)), f0(mx(pl)), sum(po)
    tc = col("Processor Information", "_Total", "% Processor Time")
    printf "CPU: total peak %s%%", f0(mx(tc))
    if (ncores) {
        hot = 0; m = ""; for (r = 1; r <= rows; r++) { if (BUSY[r] != "" && BUSY[r] >= 95) hot++; if (BUSY[r] != "" && (m == "" || BUSY[r] > m)) m = BUSY[r] }
        printf ", busiest core peak %s%%, %d second(s) with a core at 95%% or more", f0(m), hot
    }
    th = col("Thermal", "", "Pressure Level")
    if (th) printf ", thermal pressure max %s (0 nominal .. 4 sleeping)", f0(mx(th))
    printf "\n\n"

    print "LOCAL DISKS"
    print "-----------"
    for (i = 2; i <= ncol; i++) if (O[i] == "PhysicalDisk" && C[i] == "Disk Read Bytes/sec") {
        inst = I[i]; wc = col(O[i], inst, "Disk Write Bytes/sec"); lr = col(O[i], inst, "Avg. Disk sec/Read"); lw = col(O[i], inst, "Avg. Disk sec/Write")
        printf "%-8s read peak %s (p95 latency %s ms while reading), write peak %s (p95 latency %s ms while writing)\n", inst, mbs(mx(i)), f1(pct(lr, 0.95, i, MB) * 1000), mbs(mx(wc)), f1(pct(lw, 0.95, wc, MB) * 1000)
    }
    print ""

    # --- Throughput drops --------------------------------------------------
    print "THROUGHPUT DROPS"
    print "----------------"
    print "A drop: throughput on an SMB share, or on the connection to another storage"
    print "target (DLC gateway, iSCSI portal, NFS server), falls below 10% of its usual rate for"
    print mindrop " seconds or more and then recovers, inside an active transfer. The Mac"
    print "cannot see whether the application stopped asking or the server stopped"
    print "answering; compare with the server capture (Invoke-CinesysAnalysis.ps1)."
    print ""
    print "Share,Direction,Start,Seconds,BeforeMBps,DuringMBps,AfterMBps,RetransmittedKB,MaxRttMs,BusiestCorePct,MemoryPressure" > stalls
    nd = 0
    for (k = 1; k <= ns; k++) for (d = 1; d <= 2; d++) {
        c = (d == 1) ? SR[k] : SW[k]; dir = (d == 1) ? "read" : "write"
        p95 = pct(c, 0.95, c, MB); if (p95 == "" || p95 < 5 * MB) continue
        hi = p95 * 0.25; if (hi < 5 * MB) hi = 5 * MB; lo = p95 * 0.10
        srv = SRV[k]
        r = 1
        while (r <= rows) {
            if (V[r, c] == "" || V[r, c] < hi) { r++; continue }
            # r is active; find the next non-active run
            s = r + 1; while (s <= rows && V[s, c] != "" && V[s, c] >= hi) s++
            if (s > rows) break
            e = s; nlow = 0
            while (e <= rows && (V[e, c] == "" || V[e, c] < hi)) { if (V[e, c] != "" && V[e, c] < lo) nlow++; e++ }
            if (e <= rows && nlow >= mindrop && e - s <= 120) {
                nd++
                before = ravg(c, s - 3, s - 1); during = ravg(c, s, e - 1); after = ravg(c, e, e + 2)
                rtk = ""; rtm = ""
                if (srv in CONN_RT) { rtk = rsum(CONN_RT[srv], s, e - 1) / 1024; rtm = rmax(CONN_RTT[srv], s, e - 1) }
                bc = ""; if (ncores) { for (q = s; q <= e - 1; q++) if (BUSY[q] != "" && (bc == "" || BUSY[q] > bc)) bc = BUSY[q] }
                mp = rmax(col("Memory", "", "Pressure Level"), s, e - 1)
                printf "%s  %-5s %-28s %3d s  before %s, during %s, after %s", iso(T[s]), dir, SHARE[k], e - s, mbs(before), mbs(during), mbs(after)
                if (rtk != "" && rtk > 0) printf ", retransmitted %.0f KB", rtk
                if (rtm != "") printf ", RTT max %.1f ms", rtm
                if (bc != "" && bc >= 95) printf ", a CPU core at %.0f%%", bc
                if (mp != "" && mp > 1) printf ", memory pressure %d", mp
                printf "\n"
                printf "%s,%s,%s,%d,%.1f,%.1f,%.1f,%s,%s,%s,%s\n", SHARE[k], dir, iso(T[s]), e - s, before / MB, during / MB, after / MB, (rtk == "" ? "" : sprintf("%.0f", rtk)), (rtm == "" ? "" : sprintf("%.1f", rtm)), (bc == "" ? "" : sprintf("%.0f", bc)), mp > stalls
            }
            r = e
        }
    }
    if (!nd) print "(none found)"
    print ""
}
