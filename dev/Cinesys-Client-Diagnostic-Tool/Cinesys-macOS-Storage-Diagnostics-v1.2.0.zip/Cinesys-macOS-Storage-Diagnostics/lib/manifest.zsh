# Capture-Manifest.json. Sourced after common.zsh and Raw/config.zsh.
#     cs_write_manifest <Status>

cs_write_manifest() {
    local cstatus=$1 f=$CAP/Capture-Manifest.json
    local stopped=${STOPPED:-}
    local -a parts items
    local s m i line name pid started out match st note

    j() { cs_json "$1" }
    jarr() { print -rn -- "[${(j:,:)@}]" }

    # Collectors: started (collectors.tsv), stopped (collector-status.tsv),
    # notes (collector-notes.tsv: failed at start, stopped early).
    typeset -A cstate cstop cnote
    if [[ -f $CAP/Raw/collector-status.tsv ]]; then
        while IFS=$'\t' read -r name st stopped_at; do cstate[$name]=$st; cstop[$name]=$stopped_at; done < $CAP/Raw/collector-status.tsv
    fi
    if [[ -f $CAP/Raw/collector-notes.tsv ]]; then
        while IFS=$'\t' read -r name started st note; do cnote[$name]="${cnote[$name]:+${cnote[$name]}; }$st${note:+: $note}"; done < $CAP/Raw/collector-notes.tsv
    fi
    items=()
    if [[ -f $CAP/Raw/collectors.tsv ]]; then
        while IFS=$'\t' read -r name pid started out match; do
            items+=("{\"Name\":$(j $name),\"Pid\":$pid,\"Started\":$(j $started),\"Output\":$(j ${out:#-}),\"Stopped\":$(j ${cstop[$name]:-}),\"State\":$(j ${cstate[$name]:-$cstatus}),\"Note\":$(j ${cnote[$name]:-})}")
        done < $CAP/Raw/collectors.tsv
    fi
    local collectors; collectors=$(jarr $items)

    items=()
    for s in $SERVER_IPS; do items+=("{\"Ip\":$(j $s),\"Name\":$(j ${SERVER_NAME[$s]:-}),\"Role\":$(j ${TARGET_ROLE[$s]:-})}"); done
    local servers; servers=$(jarr $items)
    items=()
    for m in $MOUNTS; do items+=("{\"Instance\":$(j ${MOUNT_INST[$m]}),\"MountPoint\":$(j $m),\"Server\":$(j ${MOUNT_SERVER[$m]})}"); done
    local shares; shares=$(jarr $items)
    items=()
    for i in $WATCH_IFS; do
        local st=false; (( ${STORAGE_IFS[(Ie)$i]} )) && st=true
        items+=("{\"Device\":$(j $i),\"Label\":$(j ${IF_LABEL[$i]}),\"CarriesStorage\":$st}")
    done
    local ifaces; ifaces=$(jarr $items)

    # Storage found by the detectors at Start
    items=()
    local sf=$CAP/Raw/storage-pre.txt; [[ -f $sf ]] || sf=$CAP/Raw/storage-info.txt
    if [[ -f $sf ]]; then
        local -a r
        while IFS= read -r line; do
            [[ -z $line ]] && continue
            r=("${(@s:|:)line}")
            items+=("{\"Protocol\":$(j $r[1]),\"Role\":$(j $r[5]),\"Address\":$(j ${r[2]:#-}),\"Port\":$(j ${r[3]:#-}),\"Where\":$(j ${r[4]:#-}),\"Detail\":$(j ${r[6]:#-})}")
        done < $sf
    fi
    local storage; storage=$(jarr $items)

    # Coverage of the per-second data
    local cov='{}'
    if [[ -s $CAP/Raw/sampler.csv ]]; then
        cov=$(awk -F, -v iv=$INTERVAL '
            NR==1 { next }
            { e=$1+0; if (n==0) first=e; if (n>0 && e-last > 2*iv && ng < 20) gaps[++ng]=last " " (e-last); last=e; n++ }
            END {
                printf "{\"Samples\":%d,\"FirstEpoch\":%d,\"LastEpoch\":%d,\"Gaps\":[", n, first, last
                for (k=1;k<=ng;k++) { split(gaps[k],g," "); printf "%s{\"AfterEpoch\":%d,\"Seconds\":%d}", (k>1?",":""), g[1], g[2] }
                printf "]}"
            }' $CAP/Raw/sampler.csv)
    fi

    items=()
    local fw
    for fw in pre post; do
        [[ -f $CAP/Raw/findings-$fw.txt ]] || continue
        while IFS='|' read -r st note; do items+=("{\"When\":$(j $fw),\"Level\":$(j $st),\"Text\":$(j $note)}"); done < $CAP/Raw/findings-$fw.txt
    done
    local findings; findings=$(jarr $items)

    items=()
    if [[ -f $CAP/Raw/warnings.txt ]]; then
        while IFS= read -r line; do items+=("$(j $line)"); done < $CAP/Raw/warnings.txt
    fi
    local warnings; warnings=$(jarr $items)

    local mode=root; [[ $ALLOW_NONROOT == yes ]] && ! cs_is_root && mode='test (no sudo)'
    {
        print -r -- "{"
        print -r -- "  \"Tool\": \"Cinesys Storage Diagnostics for macOS\","
        print -r -- "  \"Version\": $(j $CINESYS_VERSION),"
        print -r -- "  \"Platform\": \"macOS\","
        print -r -- "  \"Host\": $(j $HOSTTAG),"
        print -r -- "  \"ComputerName\": $(j "$(scutil --get ComputerName 2>/dev/null)"),"
        print -r -- "  \"OS\": $(j "macOS $(sw_vers -productVersion) ($(sw_vers -buildVersion))"),"
        print -r -- "  \"Model\": $(j "$(sysctl -n hw.model 2>/dev/null)"),"
        print -r -- "  \"Status\": $(j $cstatus),"
        print -r -- "  \"Label\": $(j $LABEL),"
        print -r -- "  \"Arguments\": $(j $ARGS_TEXT),"
        print -r -- "  \"Mode\": $(j $mode),"
        print -r -- "  \"Started\": $(j $STARTED),"
        print -r -- "  \"Stopped\": $(j $stopped),"
        print -r -- "  \"IntervalSeconds\": $INTERVAL,"
        print -r -- "  \"PacketCapture\": $(j $PACKET_MODE),"
        print -r -- "  \"IoTrace\": $(j $IOTRACE),"
        print -r -- "  \"Targets\": $servers,"
        print -r -- "  \"Storage\": $storage,"
        print -r -- "  \"Shares\": $shares,"
        print -r -- "  \"Interfaces\": $ifaces,"
        print -r -- "  \"Collectors\": $collectors,"
        print -r -- "  \"Coverage\": $cov,"
        print -r -- "  \"Findings\": $findings,"
        print -r -- "  \"Warnings\": $warnings"
        print -r -- "}"
    } > $f
}
