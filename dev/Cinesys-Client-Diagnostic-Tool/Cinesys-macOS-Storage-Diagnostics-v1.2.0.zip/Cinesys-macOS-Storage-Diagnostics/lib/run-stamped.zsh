#!/bin/zsh
# Runs a command and writes every output line prefixed with the time it was
# read (epoch seconds with microseconds) to a file:
#     zsh lib/run-stamped.zsh <out file> [--filter <regex>] <command> [args...]
# nettop, iostat and powermetrics flush each line, so the stamp is the time
# the sample was produced. Stops the command on SIGTERM.

zmodload zsh/datetime
out=$1; shift
filter=""
if [[ $1 == --filter ]]; then filter=$2; shift 2; fi

cpid=""
trap '[[ -n $cpid ]] && kill -TERM $cpid 2>/dev/null' TERM INT HUP

"$@" 2>>"$out.err" > >(
    while IFS= read -r l; do
        [[ -n $filter && ! $l =~ $filter ]] && continue
        print -r -- "$EPOCHREALTIME,$l"
    done >> "$out"
) &
cpid=$!
wait $cpid
# wait returns early when the trap fires; give the command a moment to exit.
for i in 1 2 3 4 5; do kill -0 $cpid 2>/dev/null || break; sleep 0.2; done
kill -KILL $cpid 2>/dev/null
exit 0
