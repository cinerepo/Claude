# Snapshots, hardware inventory and topology. Sourced by Start and Stop after
# common.zsh and the capture's Raw/config.zsh.
#
#   cs_snapshot Pre|Post   -> Snapshot-Pre.txt / Snapshot-Post.txt
#   cs_inventory           -> System-Inventory.txt / System-Inventory.json
#   cs_topology Pre|Post   -> Topology-Pre.txt / Topology-Post.txt and
#                             Raw/findings-pre.txt / Raw/findings-post.txt

# One section: title, then a command line run through eval with a timeout.
cs_sec() {
    print -r -- ""
    print -r -- "===== $1 ====="
    print -r -- "\$ $2"
    cs_timeout ${3:-60} eval "$2" 2>&1
}

cs_ntp_server() {
    local s
    s=$(awk '/^server /{print $2; exit}' /etc/ntp.conf 2>/dev/null)
    print -r -- ${s:-time.apple.com}
}

cs_show_smb_pre() {
    local f=$CAP/Raw/smb-log-pre.txt
    print -r -- "$(grep -c '^[0-9]\{4\}-' $f) lines (all of them in Raw/smb-log-pre.txt); newest 200:"
    grep '^[0-9]\{4\}-' $f | tail -200
}

cs_snapshot() {
    local when=$1 f=$CAP/Snapshot-$1.txt m s i
    cs_log "Writing Snapshot-$when.txt ..."
    {
        print -r -- "Cinesys Storage Diagnostics for macOS $CINESYS_VERSION - $when-capture snapshot"
        print -r -- "Host: $HOSTTAG   Written: $(cs_now)"

        cs_sec 'CLOCK' 'date; date -u; print -r -- "Time zone: $(readlink /etc/localtime | sed "s|.*/zoneinfo/||")"; uptime'
        cs_sec 'CLOCK OFFSET (sntp, query only)' "sntp -t 3 $(cs_ntp_server)" 10
        cs_sec 'OPERATING SYSTEM' 'sw_vers; uname -a'

        cs_sec 'SMB MOUNTS' 'mount | grep -i smbfs'
        cs_sec 'SMB SHARE ATTRIBUTES (version, signing, encryption)' 'cs_as_user smbutil statshares -a'
        cs_sec 'SMB SESSIONS AND CHANNELS' 'cs_as_user smbutil multichannel -a'
        cs_sec 'SMB CLIENT SETTINGS (nsmb.conf)' 'for f in /etc/nsmb.conf ${SMB_HOME:-/nonexistent}/Library/Preferences/nsmb.conf; do print "--- $f"; [[ -f $f ]] && cat $f || print "(not present)"; done'
        cs_sec 'FINDER .DS_Store ON NETWORK SHARES' 'cs_as_user defaults read com.apple.desktopservices 2>&1 || print "(no desktopservices settings: .DS_Store files are written to shares)"'
        for m in $MOUNTS; do
            cs_sec "SPOTLIGHT ON $m" "mdutil -s ${(q)m}" 15
        done
        cs_sec 'SMB TCP CONNECTIONS' 'netstat -an -p tcp | grep -E "\.445 "'
        for s in $SERVER_IPS; do
            cs_sec "TCP CONNECTIONS TO $s (${TARGET_ROLE[$s]:-})" "netstat -an -p tcp | grep -F ' $s.'"
        done

        cs_sec 'INTERFACES' 'ifconfig -a'
        cs_sec 'HARDWARE PORTS' 'networksetup -listallhardwareports'
        cs_sec 'NETWORK SERVICE ORDER' 'networksetup -listnetworkserviceorder'
        for i in $WATCH_IFS; do
            cs_sec "LINK $i (${CS_HWPORT[$i]:-})" "networksetup -getmedia $i; networksetup -getMTU $i" 15
        done
        cs_sec 'NETWORK SERVICES' 'networksetup -listallnetworkservices'
        cs_sec 'ROUTING TABLE' 'netstat -rn'
        cs_sec 'DEFAULT ROUTE' 'route -n get default'
        cs_sec 'NETWORK REACHABILITY ORDER' 'scutil --nwi'
        cs_sec 'DNS' 'scutil --dns'
        cs_sec 'PROXY' 'scutil --proxy'
        cs_sec 'ARP / NEIGHBORS' 'arp -an'
        cs_sec 'INTERFACE COUNTERS' 'netstat -ibn'
        cs_sec 'TCP CONNECTION STATES' 'netstat -an -p tcp | awk '"'"'/^tcp/ {s[$6]++} END {for (i in s) print i, s[i]}'"'"
        cs_sec 'TCP CONNECTIONS PER APPLICATION' 'lsof -nP -iTCP 2>/dev/null | awk '"'"'NR>1 {print $1}'"'"' | sort | uniq -c | sort -rn' 30
        cs_sec 'PROTOCOL CONTROL BLOCKS' 'sysctl net.inet.tcp.pcbcount'
        cs_sec 'ACTIVE SOCKETS' 'netstat -anv' 30
        cs_sec 'TCP SETTINGS' 'sysctl net.inet.tcp'
        cs_sec 'IP SETTINGS' 'sysctl net.inet.ip'
        cs_sec 'UDP SETTINGS' 'sysctl net.inet.udp'
        cs_sec 'PROTOCOL STATISTICS' 'netstat -s' 30
        if cs_is_root; then
            cs_sec 'PACKET FILTER STATUS' 'pfctl -s info' 15
            cs_sec 'PACKET FILTER RULES' 'pfctl -s rules' 15
            cs_sec 'PACKET FILTER NAT' 'pfctl -s nat' 15
            # Skywalk (the newer macOS network stack): which adapter and route
            # each flow is bound to, and drops at the driver level.
            cs_sec 'SKYWALK FLOWS' 'skywalkctl flow -n' 30
            cs_sec 'SKYWALK FLOW ROUTES' 'skywalkctl flow-route -n' 30
            cs_sec 'SKYWALK INTERFACES' 'skywalkctl interface' 30
            cs_sec 'SKYWALK STATISTICS' 'skywalkctl netstat -s' 30
        fi
        for s in $SERVER_IPS; do
            cs_sec "ROUTE TO $s" "route -n get $s"
            cs_sec "PING $s" "ping -n -c 5 -t 8 $s" 15
            cs_sec "PING $s 1500-BYTE PACKETS, DON'T FRAGMENT" "ping -n -D -s 1472 -c 3 -t 6 $s" 10
            for i in $WATCH_IFS; do
                local mtu; mtu=$(cs_if_mtu $i)
                if (( ${mtu:-0} > 1500 )); then
                    cs_sec "PING $s 9000-BYTE PACKETS, DON'T FRAGMENT" "ping -n -D -s 8972 -c 3 -t 6 $s" 10
                    break
                fi
            done
        done
        for i in $STORAGE_IFS; do
            if cs_is_wifi $i && cs_is_root; then cs_sec "WI-FI ($i)" 'wdutil info' 20; fi
        done

        cs_sec 'POWER SETTINGS' 'pmset -g; pmset -g batt'
        cs_sec 'THERMAL STATE' 'pmset -g therm'
        cs_sec 'SLEEP ASSERTIONS' 'pmset -g assertions'
        cs_sec 'SYSTEM EXTENSIONS (security / network / file system add-ons)' 'systemextensionsctl list'
        cs_sec 'THIRD-PARTY KERNEL EXTENSIONS' 'kmutil showloaded --list-only 2>/dev/null | grep -v com.apple || print "(none)"' 30
        cs_sec 'DEVICE MANAGEMENT (MDM)' 'profiles status -type enrollment'
        cs_sec 'TIME MACHINE' 'tmutil status'
        cs_sec 'SPOTLIGHT ON SYSTEM VOLUME' 'mdutil -s /'

        cs_sec 'TOP PROCESSES BY CPU' 'top -l 1 -o cpu -n 30 -stats pid,command,cpu,mem,threads,state'
        cs_sec 'PROCESSES (name and path only)' 'ps -Ao pid,ppid,user,%cpu,%mem,rss,etime,comm'
        cs_sec 'MEMORY' 'vm_stat; memory_pressure | tail -3; sysctl vm.swapusage hw.memsize'
        cs_sec 'VOLUMES' 'df -h'
        cs_sec 'DISKS' 'diskutil list'

        if [[ $when != Post ]]; then
            # Full hour kept in Raw/smb-log-pre.txt; the snapshot shows the count and the newest lines.
            cs_timeout 90 $CS_LOG show --last 1h --style compact --predicate "$CS_SMB_PREDICATE" > $CAP/Raw/smb-log-pre.txt 2>&1
            cs_sec 'SMB CLIENT LOG, LAST HOUR' cs_show_smb_pre
        fi
    } > $f 2>&1
}

# ---------------------------------------------------------------------------
# Hardware inventory (written once, at Start)
# ---------------------------------------------------------------------------
CS_SP_TYPES=(SPHardwareDataType SPSoftwareDataType SPMemoryDataType SPStorageDataType SPNVMeDataType
    SPSerialATADataType SPEthernetDataType SPNetworkDataType SPThunderboltDataType SPPCIDataType
    SPUSBDataType SPUSBHostDataType SPFibreChannelDataType SPSASDataType SPPowerDataType SPDisplaysDataType)

cs_inventory() {
    cs_log "Writing System-Inventory.txt ..."
    local types=() t
    # Not every data type exists on every macOS version; keep the ones that do.
    local known; known=$(system_profiler -listDataTypes 2>/dev/null)
    for t in $CS_SP_TYPES; do print -r -- $known | grep -qx $t && types+=($t); done
    local full; full=$(cs_timeout 120 system_profiler $types 2>/dev/null)
    cs_timeout 120 system_profiler -json $types > $CAP/System-Inventory.json 2>/dev/null
    hw() { print -r -- $full | awk -F': ' -v k="$1" '{x=$1; sub(/^ +/,"",x)} x==k {print $2; exit}' }
    {
        print -r -- "Cinesys Storage Diagnostics for macOS $CINESYS_VERSION - system inventory"
        print -r -- "Written: $(cs_now)"
        print -r -- ""
        print -r -- "SUMMARY"
        print -r -- "-------"
        printf '%-24s %s\n' 'Computer name' "$(scutil --get ComputerName 2>/dev/null)"
        printf '%-24s %s\n' 'Model' "$(hw 'Model Name') ($(hw 'Model Identifier'))"
        printf '%-24s %s\n' 'Model number' "$(hw 'Model Number')"
        local chip; chip=$(hw 'Chip'); [[ -z $chip ]] && chip="$(hw 'Processor Name') $(hw 'Processor Speed')"
        printf '%-24s %s\n' 'Chip / processor' "$chip"
        printf '%-24s %s\n' 'Cores' "$(hw 'Total Number of Cores')"
        printf '%-24s %s\n' 'Memory' "$(hw 'Memory')"
        printf '%-24s %s\n' 'Serial number' "$(hw 'Serial Number (system)')"
        printf '%-24s %s\n' 'Firmware' "$(hw 'System Firmware Version')"
        printf '%-24s %s\n' 'macOS' "$(sw_vers -productVersion) ($(sw_vers -buildVersion))"
        printf '%-24s %s\n' 'Up since' "$(sysctl -n kern.boottime | sed 's/.*} //')"
        print -r -- ""
        print -r -- "NETWORK ADAPTERS"
        print -r -- "----------------"
        local i
        for i in ${(ok)CS_HWPORT}; do
            [[ $i == (bridge*|vlan*) ]] && continue
            printf '%-7s %-34s %-10s %s\n' $i "${CS_HWPORT[$i]}" "$(cs_if_status $i)" "$(cs_if_media $i)"
        done
        print -r -- ""
        print -r -- "ETHERNET ADAPTER DETAILS (driver, bus, vendor)"
        print -r -- "----------------------------------------------"
        print -r -- $full | awk '/^Ethernet:/{on=1; next} on && /^[A-Za-z]/{on=0} on'
        print -r -- ""
        print -r -- "FULL DETAIL (system_profiler ${types[*]})"
        print -r -- "-----------"
        print -r -- $full
    } > $CAP/System-Inventory.txt
}

# ---------------------------------------------------------------------------
# Topology and findings
# ---------------------------------------------------------------------------
cs_topology() {
    local when=$1 f=$CAP/Topology-$1.txt ff=$CAP/Raw/findings-${(L)1}.txt
    : > $ff
    finding() { print -r -- "$1|$2" >> $ff }
    local tbl; tbl=$(cs_ipv4_table)
    local s i ip mask rif gw conn line m
    local stat; stat=$(cs_as_user smbutil statshares -a 2>/dev/null)
    local sess; sess=$(cs_smb_sessions)
    {
        print -r -- "Cinesys Storage Diagnostics for macOS $CINESYS_VERSION - topology ($when-capture)"
        print -r -- "Host: $HOSTTAG   Written: $(cs_now)"
        print -r -- ""
        print -r -- "INTERFACES WITH AN IPv4 ADDRESS"
        print -r -- "-------------------------------"
        printf '%-8s %-32s %-16s %-11s %-9s %-6s %s\n' Device 'Hardware port' 'Address' 'Netmask' 'Status' 'MTU' 'Media / service order'
        for line in ${(f)tbl}; do
            i=${line%% *}; [[ $i == lo0 ]] && continue
            ip=${${line#* }%% *}; mask=${line##* }
            printf '%-8s %-32s %-16s %-11s %-9s %-6s %s (order %s)\n' $i "${CS_HWPORT[$i]:-?}" $ip $mask "$(cs_if_status $i)" "$(cs_if_mtu $i)" "$(cs_if_media $i)" "${CS_ORDER[$i]:-n/a}"
        done

        for s in $SERVER_IPS; do
            print -r -- ""
            print -r -- "SERVER $s ${SERVER_NAME[$s]:+(${SERVER_NAME[$s]}) }- ${TARGET_ROLE[$s]:-}"
            print -r -- "------------------------------------------------------------"
            rif=$(cs_route_if $s); gw=$(cs_route_gw $s)
            print -r -- "Route:            $rif ${CS_HWPORT[$rif]:-} ${${gw:+via gateway $gw}:-same subnet (no gateway)}"
            print -r -- "Link:             $(cs_if_status $rif) $(cs_if_media $rif), MTU $(cs_if_mtu $rif)"
            local -a used=()
            local cl cd cp
            for conn in ${(f)"$(cs_conn_ifs $s)"}; do
                cl=${conn%% *}; cd=${${conn#* }%% *}; cp=${conn##* }
                print -r -- "Connection:       from $cl on $cd ${CS_HWPORT[$cd]:-} to port(s) $cp"
                used+=($cd)
            done
            (( ${#used} )) || print -r -- "Connection:       none open right now"
            used=(${(u)used})

            # Findings for this server
            local u
            for u in $used; do
                if cs_is_wifi $u; then finding WARN "Storage traffic to $s (${TARGET_ROLE[$s]:-}) is going over Wi-Fi ($u). Wired performance cannot be judged from this capture."; fi
                [[ -n $rif && $u != $rif ]] && finding WARN "The connection to $s uses $u but the route now points to $rif. The connection was opened over a different adapter."
                local md; md=$(cs_if_media $u)
                case $md in
                    *10baseT*|*100baseTX*) finding WARN "$u (${CS_HWPORT[$u]:-}) links at $md. Expect at most 1-12 MB/s." ;;
                    *1000baseT*) finding INFO "$u (${CS_HWPORT[$u]:-}) links at 1 Gb/s ($md): the ceiling is about 110 MB/s." ;;
                esac
                [[ $md == *half-duplex* ]] && finding WARN "$u is running half duplex ($md)."
            done
            (( ${#used} > 1 )) && finding INFO "Traffic to $s uses ${#used} adapters at once: ${used[*]}."
            if [[ -n $rif ]] && cs_is_wifi $rif && (( ${#used} == 0 )); then finding WARN "The route to $s goes over Wi-Fi ($rif)."; fi
            [[ $rif == utun* || $rif == ipsec* || $rif == ppp* ]] && finding WARN "The route to $s goes through a VPN tunnel ($rif)."
            if [[ $s == 127.* ]]; then
                local mp port who="" fwd
                for mp in $MOUNTS; do
                    [[ ${MOUNT_SERVER[$mp]} == $s ]] || continue
                    port=${${MOUNT_INST[$mp]#\\\\}%%\\*}; [[ $port == *:<-> ]] && port=${port##*:} || port=445
                    fwd=$(lsof -nP -iTCP:$port -sTCP:LISTEN -Fc 2>/dev/null | sed -n 's/^c//p' | head -1)
                    who+="${MOUNT_INST[$mp]} (local port $port${fwd:+, opened by $fwd}), "
                done
                finding WARN "Storage goes through a local port forward or tunnel: ${who%, }. Adapter and connection numbers describe the tunnel, not the path to the real server."
            fi

            # Other interfaces on the server's subnet: macOS then picks by service order
            local sip mi ii; sip=$(cs_ip2int $s)
            local -a same=()
            for line in ${(f)tbl}; do
                i=${line%% *}; [[ $i == lo0 ]] && continue
                ip=${${line#* }%% *}; mask=${line##* }
                mi=$(( mask )); ii=$(cs_ip2int $ip)
                (( (ii & mi) == (sip & mi) )) && same+=($i)
            done
            if (( ${#same} > 1 )); then
                local desc="" x
                for x in $same; do desc+="$x ${CS_HWPORT[$x]:-} (service order ${CS_ORDER[$x]:-n/a}), "; done
                finding WARN "${#same} adapters have an address on the same subnet as $s: ${desc%, }. macOS chooses one by service order, so traffic can move between adapters."
            fi
            [[ -n $gw ]] && finding INFO "$s is reached through a router ($gw), not on the local subnet."
        done

        # Path MTU: don't-fragment pings at 1500 and at the adapter's MTU, and
        # the largest size that passes when the large one fails.
        if (( ${#SERVER_IPS} )); then
            print -r -- ""
            print -r -- "PATH MTU (don't-fragment pings)"
            print -r -- "-------------------------------"
            local pm res big pmt pmi pn=0 pr
            for s in $SERVER_IPS; do
                [[ $s == 127.* ]] && continue
                (( ++pn > 12 )) && { print -r -- "(only the first 12 targets tested)"; break }
                pmi=$(cs_route_if $s); pmt=$(cs_if_mtu $pmi); pmt=${pmt:-1500}
                read -r res big pm pr <<< "$(cs_pmtu $s $pmt)"
                printf '%-15s %-34s via %s, MTU %s: 1500 %s, at MTU %s, largest that passes %s -> %s\n' $s "${TARGET_ROLE[$s]:-}" "$pmi" $pmt $pm $pr $big $res
                case $res in
                    SilentDrop) finding WARN "$pmi has MTU $pmt, but larger packets to $s (${TARGET_ROLE[$s]:-}) get no answer while $big-byte packets do. A switch port or VLAN on the path, or $s's own interface, is set to a smaller MTU." ;;
                    RouterRefused) finding WARN "$pmi has MTU $pmt, but a router on the path to $s (${TARGET_ROLE[$s]:-}) refuses packets above $big bytes ('fragmentation needed'). A routed hop or firewall uses a smaller MTU." ;;
                    NoReply) finding INFO "No reply to pings from $s (${TARGET_ROLE[$s]:-}); ICMP may be blocked, so the path MTU could not be tested." ;;
                esac
            done
        fi

        print -r -- ""
        print -r -- "SMB MOUNTS"
        print -r -- "----------"
        for m in $MOUNTS; do
            local blk; blk=$(print -r -- $stat | awk -v share="${${MOUNT_SHARE[$m]}//\%20/ }" '
                /^[^ \t=-]/ { cur=$0; sub(/[ \t]+$/,"",cur) } cur==share && NF>=2 { print }')
            local ver sign enc sl rcc mc
            ver=$(print -r -- $blk | awk '$1=="SMB_VERSION"{print $2; exit}')
            sign=$(print -r -- $blk | awk '$1=="SMB_CURR_SIGN_ALGORITHM"{print $2; exit}')
            enc=$(print -r -- $blk | awk '$1=="SMB_CURR_ENCRYPT_ALGORITHM"{print $2; exit}')
            line=$(print -r -- $sess | grep -F -- "$m|" | head -1)
            rcc=$(print -r -- $line | awk -F'|' '{print $6}'); mc=$(print -r -- $line | awk -F'|' '{print $7}')
            print -r -- "${MOUNT_INST[$m]} on $m"
            print -r -- "    SMB version ${ver:-?}, signing ${sign:-off}, encryption ${enc:-?}, multichannel ${mc:-?}, reconnects ${rcc:-?}"
            [[ -n $ver && $ver != SMB_3* ]] && finding WARN "${MOUNT_INST[$m]} negotiated $ver (not SMB 3)."
            [[ -n $sign && $sign != OFF ]] && finding INFO "${MOUNT_INST[$m]} is signed ($sign). Signing costs CPU on both ends."
            [[ -n $enc && $enc != OFF ]] && finding INFO "${MOUNT_INST[$m]} is encrypted ($enc)."
            [[ -n $rcc && $rcc != 0 ]] && finding WARN "${MOUNT_INST[$m]} has reconnected $rcc time(s) since it was mounted."
            if mdutil -s "$m" 2>/dev/null | grep -qi 'Indexing enabled'; then finding INFO "Spotlight indexing is enabled on $m."; fi
        done
        (( ${#MOUNTS} )) || print -r -- "(no SMB mounts)"

        # Storage found by the detectors (Storage-*.txt has the detail)
        print -r -- ""
        print -r -- "STORAGE FOUND"
        print -r -- "-------------"
        local -a det r; det=()
        [[ -f $CAP/Raw/storage-${(L)when}.txt ]] && det=(${(f)"$(<$CAP/Raw/storage-${(L)when}.txt)"})
        [[ -z $det && -f $CAP/Raw/storage-pre.txt ]] && det=(${(f)"$(<$CAP/Raw/storage-pre.txt)"})
        for line in $det; do
            r=("${(@s:|:)line}")
            printf '%-9s %-10s %-16s %-6s %-28s %s\n' $r[1] $r[5] $r[2] $r[3] $r[4] $r[6]
        done
        (( ${#det} )) || print -r -- "(no network or SAN storage found: whole-Mac capture)"
        local dj=${(F)det}
        if print -r -- $dj | grep -q '^STORNEXT|'; then
            if print -r -- $dj | grep -q '^STORNEXT|.*|gateway|' && ! print -r -- $dj | grep -q '^STORNEXT|.*|flow|DLC'; then
                finding WARN "StorNext DLC gateways are listed by cvadmin but no connection to any of them is open."
            fi
            print -r -- $dj | grep -q '^STORNEXT|.*|mdc|' || finding INFO "A StorNext/Xsan client is set up but no metadata controller was found (cvadmin needs sudo; see Storage-$when.txt)."
        fi
        if print -r -- $dj | grep -q '^ISCSI|.*|initiator|' && ! print -r -- $dj | grep -qE '^ISCSI\|.*\|(portal|disk)\|'; then
            finding INFO "An iSCSI initiator is installed but no iSCSI session or iSCSI disk was found."
        fi
        print -r -- $dj | grep -q '^FC|.*|hba|' && system_profiler SPFibreChannelDataType 2>/dev/null | grep -qiE 'link down|no link|offline' && \
            finding WARN "A Fibre Channel port reports link down or offline (Storage-$when.txt, FIBRE CHANNEL)."
        if cs_is_root && pfctl -s rules 2>/dev/null | grep -vE '^(scrub-)?anchor "com\.apple' | grep -q .; then
            finding INFO "Packet filter (pf) rules beyond the macOS defaults are loaded (Snapshot, PACKET FILTER RULES)."
        fi
        (( ${#SERVER_IPS} )) || finding INFO "No network storage was found or named; this is a whole-Mac capture. Use --target to watch a server."

        # Avid NEXIS: its data is UDP, so UDP drops and IP fragments matter
        if print -r -- $dj | grep -q '^NEXIS|'; then
            local nxm; nxm=$(print -r -- $dj | grep '^NEXIS|.*|mount|' | cut -d'|' -f4 | paste -sd' ' -)
            finding INFO "The Avid NEXIS client is installed${nxm:+ (workspaces: $nxm)}. Its data is UDP: the summary shows it under OTHER NETWORK TRAFFIC. Name the NEXIS engines with --target to test the path to them."
        fi
        local us rf
        us=$(netstat -s -p udp 2>/dev/null | awk '/dropped due to full socket buffers$/ {print $1; exit}')
        rf=$(netstat -s -p ip 2>/dev/null | awk '/fragments dropped/ {d += $1} END {print d + 0}')
        print -r -- "${us:-0} ${rf:-0}" > $CAP/Raw/udpstats-${(L)when}.txt
        if [[ $when == Post && -f $CAP/Raw/udpstats-pre.txt ]]; then
            local u0 r0; read -r u0 r0 < $CAP/Raw/udpstats-pre.txt
            (( ${us:-0} > u0 )) && finding WARN "$(( us - u0 )) UDP datagram(s) were dropped during the capture because a socket receive buffer was full (UDP storage traffic such as Avid NEXIS loses data and has to retry)."
            (( ${rf:-0} > r0 )) && finding WARN "$(( rf - r0 )) IP fragment(s) were dropped during the capture (large UDP datagrams are being split and lost; check the MTU end to end)."
        fi

        # Machine-wide findings
        local pm; pm=$(pmset -g 2>/dev/null)
        print -r -- $pm | grep -Eq 'lowpowermode[[:space:]]+1' && finding WARN "Low Power Mode is on: CPU and network throughput are reduced."
        pmset -g batt 2>/dev/null | grep -q "Battery Power" && finding WARN "The Mac is running on battery."
        pmset -g therm 2>/dev/null | grep -Eiq 'thermal warning level.*[1-9]|CPU_Speed_Limit[[:space:]]*=[[:space:]]*[0-9]{1,2}$' && finding WARN "A thermal or CPU speed limit is recorded (see Snapshot, THERMAL STATE)."
        # "bundle id (kind)" for each active third-party system extension
        local ext; ext=$(systemextensionsctl list 2>/dev/null | awk -F'\t' '
            /^--- / { kind=$0; sub(/^--- com\.apple\.system_extension\./,"",kind); sub(/ .*/,"",kind); next }
            /\[activated enabled\]/ { id=$4; sub(/ \(.*/,"",id); if (id !~ /^com\.apple\./) printf "%s%s (%s)", (n++ ? ", " : ""), id, kind }')
        if [[ -n $ext ]]; then
            if [[ $ext == *endpoint_security* || $ext == *network_extension* ]]; then
                finding INFO "Third-party system extensions are active: $ext. Endpoint security and network extensions inspect file or network I/O and can slow SMB."
            else
                finding INFO "Third-party system extensions are active: $ext."
            fi
        fi
        tmutil status 2>/dev/null | grep -q 'Running = 1' && finding WARN "A Time Machine backup is running."
        if [[ $when != Post ]]; then
            local rc; rc=$(grep -c 'smb_iod_start_reconnect\|smb_iod_reconnect' $CAP/Raw/smb-log-pre.txt 2>/dev/null)
            (( ${rc:-0} > 0 )) && finding WARN "The SMB client logged $rc reconnect message(s) in the last hour before this snapshot (Raw/smb-log-pre.txt)."
        fi

        print -r -- ""
        print -r -- "FINDINGS"
        print -r -- "--------"
        if [[ -s $ff ]]; then
            awk -F'|' '{printf "%-5s %s\n", $1, $2}' $ff
        else
            print -r -- "(none)"
        fi
    } > $f 2>&1
}
