# Builds Cinesys-Performance.csv from the raw collector files.
#   awk -v servers="ip ip" -v host=HOST -v iv=1 -f build-csv.awk \
#       [Raw/cpu.txt] [Raw/nettop.txt] [Raw/powermetrics.txt] Raw/sampler.csv
# sampler.csv must come last: its rows (one per tick) are the output rows and
# the other sources are joined to them by epoch second.

BEGIN { FS = ","; ns = split(servers, SV, " "); n = split(smb, SB, " "); for (k = 1; k <= n; k++) ISSMB[SB[k]] = 1 }

function rest(s) { return substr(s, index(s, ",") + 1) }

# iostat -n0 -C: "us sy id 1m 5m 15m". The first data row is the average
# since boot and is skipped.
FILENAME ~ /cpu\.txt$/ {
    n = split(rest($0), f, " ")
    if (n >= 3 && f[1] ~ /^[0-9]+$/ && f[2] ~ /^[0-9]+$/ && f[3] ~ /^[0-9]+$/) {
        if (++cpurows == 1) next
        s = int($1); cus[s] = f[1]; csy[s] = f[2]; cid[s] = f[3]; if (n >= 4) cld[s] = f[4]
        havecpu = 1
    }
    next
}

# nettop -m tcp -x: one header line per sample, then one line per flow.
# Cumulative per-flow counters; the bytes moved since the flow's previous
# line are credited to the second they were seen in.
FILENAME ~ /nettop\.txt$/ {
    if ($2 == "time") { for (i = 2; i <= NF; i++) col[$i] = i; next }
    if (!("bytes_in" in col)) next
    flow = $3
    r = flow; sub(/.*<->/, "", r)
    rip = r; sub(/[:.][0-9]+$/, "", rip)
    ok = 0; for (k = 1; k <= ns; k++) if (rip == SV[k]) ok = 1
    if (!ok) next
    s = int($1); key = rip
    bi = $(col["bytes_in"]) + 0; bo = $(col["bytes_out"]) + 0
    du = $(col["rx_dupe"]) + 0; oo = $(col["rx_ooo"]) + 0; rt = $(col["re-tx"]) + 0
    rtt = $(col["rtt_avg"]); v = rtt + 0
    if (rtt ~ /us/) v = v / 1000; else if (rtt ~ /[0-9] s$/) v = v * 1000
    if (seen[s, key, flow]++ == 0) nconn[s, key]++
    if (flow in lbi) {
        if (bi >= lbi[flow]) nrx[s, key] += bi - lbi[flow]
        if (bo >= lbo[flow]) ntx[s, key] += bo - lbo[flow]
        if (du >= ldu[flow]) ndu[s, key] += du - ldu[flow]
        if (oo >= loo[flow]) noo[s, key] += oo - loo[flow]
        if (rt >= lrt[flow]) nrt[s, key] += rt - lrt[flow]
    }
    if (v > nrtt[s, key]) nrtt[s, key] = v
    w = $(col["rcvsize"]) + 0; if (w > nrw[s, key]) nrw[s, key] = w
    w = $(col["tx_win"]) + 0;  if (w > ntw[s, key]) ntw[s, key] = w
    lbi[flow] = bi; lbo[flow] = bo; ldu[flow] = du; loo[flow] = oo; lrt[flow] = rt
    hasnet[s, key] = 1; havenet = 1
    next
}

# powermetrics --samplers cpu_power,thermal (Apple silicon prints per-CPU
# active residency; Intel Macs do not, so only thermal pressure is used there).
FILENAME ~ /powermetrics\.txt$/ {
    line = rest($0)
    if (line ~ /\*\*\* Sampled/) { ps = int($1); next }
    if (line ~ /^CPU [0-9]+ active residency/) {
        split(line, a, " "); c = a[2] + 0
        p = line; sub(/.*residency: */, "", p); sub(/%.*/, "", p)
        core[ps, c] = p; if (c + 1 > ncore) ncore = c + 1
    } else if (line ~ /pressure level/) {
        p = line; sub(/.*: */, "", p)
        tv = (p ~ /Nominal/) ? 0 : (p ~ /Moderate/) ? 1 : (p ~ /Heavy/) ? 2 : (p ~ /Trapping/) ? 3 : (p ~ /Sleeping/) ? 4 : ""
        therm[ps] = tv; havetherm = 1
    }
    next
}

FILENAME ~ /sampler\.csv$/ {
    if (FNR == 1) {
        # physical adapters (en*: Ethernet, Wi-Fi, Thunderbolt, USB) for the
        # traffic no storage connection accounts for
        nf = split($0, HC, ",")
        for (k = 1; k <= nf; k++) {
            if (HC[k] ~ /Network Interface\(en[0-9]+[ )].*Bytes Received\/sec/) PRX[++npr] = k
            if (HC[k] ~ /Network Interface\(en[0-9]+[ )].*Bytes Sent\/sec/) PTX[++npt] = k
        }
        h = substr($0, index($0, ",") + 1)
        pre = "\"\\\\" host "\\"
        if (havecpu) h = h "," pre "Processor Information(_Total)\\% Processor Time\"," pre "Processor Information(_Total)\\% User Time\"," pre "Processor Information(_Total)\\% Privileged Time\"," pre "System\\Load Average 1m\""
        if (havenet) for (k = 1; k <= ns; k++) {
            # SMB servers keep the Windows-style name; other targets (DLC gateway,
            # iSCSI portal, NFS server, MDC) are "Storage Connection".
            o = pre ((SV[k] in ISSMB) ? "SMB Client Connection(" : "Storage Connection(") SV[k] ")\\"
            h = h "," o "Bytes Received/sec\"," o "Bytes Sent/sec\"," o "Retransmitted Bytes/sec\"," o "Duplicate Bytes Received/sec\"," o "Out-of-Order Bytes Received/sec\"," o "Round Trip Time ms\"," o "Receive Window Bytes\"," o "Send Window Bytes\"," o "Connections\""
        }
        for (c = 0; c < ncore; c++) h = h "," pre "Processor Information(0," c ")\\% Processor Time\""
        if (havetherm) h = h "," pre "Thermal\\Pressure Level\""
        if (npr) h = h "," pre "Network Unattributed(_Total)\\Bytes Received/sec\"," pre "Network Unattributed(_Total)\\Bytes Sent/sec\""
        print h
        next
    }
    s = $1 + 0
    out = substr($0, index($0, ",") + 1)
    if (havecpu) {
        if (s in cid) out = out "," (100 - cid[s]) "," cus[s] "," csy[s] "," cld[s]
        else out = out ",,,,"
    }
    if (havenet) for (k = 1; k <= ns; k++) {
        key = SV[k]
        if ((s, key) in hasnet)
            out = out "," sprintf("%.0f,%.0f,%.0f,%.0f,%.0f,%.3f,%d,%d,%d", nrx[s, key] / iv, ntx[s, key] / iv, nrt[s, key] / iv, ndu[s, key] / iv, noo[s, key] / iv, nrtt[s, key], nrw[s, key], ntw[s, key], nconn[s, key])
        else out = out ",,,,,,,,,"
    }
    for (c = 0; c < ncore; c++) out = out "," (((s, c) in core) ? core[s, c] : "")
    if (havetherm) out = out "," ((s in therm) ? therm[s] : "")
    if (npr) {
        split($0, RV, ","); ux = 0; uy = 0
        for (k = 1; k <= npr; k++) ux += RV[PRX[k]]
        for (k = 1; k <= npt; k++) uy += RV[PTX[k]]
        if (havenet) for (k = 1; k <= ns; k++) if ((s, SV[k]) in hasnet) { ux -= nrx[s, SV[k]] / iv; uy -= ntx[s, SV[k]] / iv }
        out = out "," sprintf("%.0f,%.0f", ux > 0 ? ux : 0, uy > 0 ? uy : 0)
    }
    print out
}
