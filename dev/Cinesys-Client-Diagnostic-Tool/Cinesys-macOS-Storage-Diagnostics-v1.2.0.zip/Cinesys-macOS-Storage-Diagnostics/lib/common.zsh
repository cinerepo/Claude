# Shared functions for the Cinesys macOS capture scripts. Sourced, not run.
# The caller sets CINESYS_ROOT (the toolkit folder) before sourcing.

zmodload zsh/datetime
zmodload zsh/zselect 2>/dev/null
zmodload zsh/mathfunc

CINESYS_VERSION=$(<"$CINESYS_ROOT/VERSION.txt")
CINESYS_STATE=/var/tmp/cinesys-macos-capture.state
CINESYS_DEFAULT_OUTPUT=/Users/Shared/Cinesys-Storage-Diagnostics
# In zsh, `log` is a builtin; the unified log tool must be called by path.
CS_LOG=/usr/bin/log

# Lines the unified log is searched for: SMB client (kernel smbfs), mounting,
# authentication.
CS_SMB_PREDICATE='senderImagePath CONTAINS[c] "smbfs" OR process == "mount_smbfs" OR process == "NetAuthSysAgent" OR process == "NetAuthAgent" OR subsystem == "com.apple.smb"'

cs_now() { strftime '%Y-%m-%d %H:%M:%S' $EPOCHSECONDS }

# Messages go to the screen and, once a capture folder exists, to Capture-Log.txt.
cs_log() {
    print -r -- "$*"
    [[ -n ${CAP:-} && -d $CAP ]] && print -r -- "$(cs_now)  $*" >> "$CAP/Capture-Log.txt"
}
cs_warn() {
    print -r -- "WARNING: $*" >&2
    if [[ -n ${CAP:-} && -d $CAP ]]; then
        print -r -- "$(cs_now)  WARNING: $*" >> "$CAP/Capture-Log.txt"
        print -r -- "$*" >> "$CAP/Raw/warnings.txt"
    fi
}
cs_die() { print -r -- "ERROR: $*" >&2; exit 1 }

cs_json() {
    # JSON string literal
    local s=$1
    s=${s//\\/\\\\}; s=${s//\"/\\\"}; s=${s//$'\t'/\\t}; s=${s//$'\r'/}; s=${s//$'\n'/\\n}
    print -rn -- "\"$s\""
}

# Runs a command, killing it after $1 seconds.
cs_timeout() {
    local secs=$1; shift
    "$@" &
    local p=$!
    # The watcher must not hold the caller's output open (a $(...) would wait
    # for it), and zselect is a builtin, so no sleep process is left behind.
    ( zselect -t $(( secs * 100 )); kill -TERM $p 2>/dev/null ) >/dev/null 2>&1 &
    local w=$!
    wait $p 2>/dev/null
    local rc=$?
    kill $w 2>/dev/null; wait $w 2>/dev/null
    return $rc
}

# SMB mounts belong to the user who mounted them; smbutil only lists the
# caller's own sessions, so under sudo it runs as that user.
cs_as_user() {
    if [[ $EUID -eq 0 && ${SMB_RUN_AS:-user} == user && -n ${SMB_USER:-} && $SMB_USER != root ]]; then
        sudo -u "$SMB_USER" "$@"
    else
        "$@"
    fi
}

cs_is_root() { [[ $EUID -eq 0 ]] }

# ---------------------------------------------------------------------------
# Interfaces
# ---------------------------------------------------------------------------
typeset -gA CS_HWPORT CS_ORDER
cs_load_hwports() {
    # device -> hardware port name ("Wi-Fi", "USB 10/100/1000 LAN", "Thunderbolt Ethernet Slot 1")
    CS_HWPORT=()
    local name="" line
    for line in ${(f)"$(networksetup -listallhardwareports 2>/dev/null)"}; do
        case $line in
            "Hardware Port: "*) name=${line#Hardware Port: } ;;
            "Device: "*) CS_HWPORT[${line#Device: }]=$name ;;
        esac
    done
    # device -> position in the network service order ("-" when disabled)
    CS_ORDER=()
    local pos=""
    for line in ${(f)"$(networksetup -listnetworkserviceorder 2>/dev/null)"}; do
        if [[ $line == '('[0-9]*')'* ]]; then pos=${${line#\(}%%\)*}
        elif [[ $line == '(*)'* ]]; then pos=disabled
        elif [[ $line == *"Device: "* ]]; then
            local dev=${${line##*Device: }%\)}
            [[ -n $dev && -z ${CS_ORDER[$dev]:-} ]] && CS_ORDER[$dev]=$pos
        fi
    done
}

cs_if_label() {
    # "en7 USB 10/100/1000 LAN"
    local n=${CS_HWPORT[$1]:-}
    [[ -n $n ]] && print -r -- "$1 $n" || print -r -- "$1"
}

cs_if_status() { ifconfig "$1" 2>/dev/null | awk -F': ' '/status:/{print $2; exit}' }
cs_if_media()  { ifconfig "$1" 2>/dev/null | awk -F': ' '/media:/{print $2; exit}' }
cs_if_mtu()    { ifconfig "$1" 2>/dev/null | awk '/mtu/{for(i=1;i<NF;i++) if($i=="mtu"){print $(i+1); exit}}' }
cs_is_wifi()   { [[ ${CS_HWPORT[$1]:-} == (Wi-Fi|AirPort)* ]] }

# "dev ip netmask(hex)" for every IPv4 address
cs_ipv4_table() {
    ifconfig 2>/dev/null | awk '/^[a-z]/{i=$1; sub(":$","",i)} /^[ \t]+inet /{m=""; for(k=1;k<NF;k++) if($k=="netmask") m=$(k+1); print i, $2, m}'
}

cs_ip2int() {
    local -a o; o=(${(s:.:)1})
    (( ${#o} == 4 )) || { print 0; return }
    print $(( (o[1] << 24) + (o[2] << 16) + (o[3] << 8) + o[4] ))
}

cs_resolve() {
    # name or IP -> IPv4
    if [[ $1 == <0-255>.<0-255>.<0-255>.<0-255> ]]; then print -r -- $1; return; fi
    local ip
    ip=$(dscacheutil -q host -a name "$1" 2>/dev/null | awk '/^ip_address:/{print $2; exit}')
    print -r -- ${ip:-$1}
}

cs_route_if() { route -n get "$1" 2>/dev/null | awk '/interface:/{print $2; exit}' }
cs_route_gw() { route -n get "$1" 2>/dev/null | awk '/gateway:/{print $2; exit}' }

# Live TCP connections to an IP, by local address: "localip dev ports"
# (ports = the server's ports, comma-separated). Optional second argument
# limits it to one server port.
cs_conn_ifs() {
    local srv=$1 want=${2:-} line ip dev ports
    local tbl; tbl=$(cs_ipv4_table)
    for line in ${(f)"$(netstat -an -p tcp 2>/dev/null | awk -v s="$srv" -v w="$want" '
        $1 ~ /^tcp4/ && $6 == "ESTABLISHED" {
            n = split($4, a, "."); m = split($5, b, ".")
            if (n != 5 || m != 5) next
            if (b[1] "." b[2] "." b[3] "." b[4] != s || (w != "" && b[5] != w)) next
            l = a[1] "." a[2] "." a[3] "." a[4]
            if (!((l, b[5]) in seen)) { seen[l, b[5]] = 1; p[l] = p[l] (p[l] == "" ? "" : ",") b[5] }
        }
        END { for (l in p) print l, p[l] }')"}; do
        ip=${line% *}; ports=${line#* }
        dev=$(print -r -- $tbl | awk -v ip=$ip '$2==ip{print $1; exit}')
        print -r -- "$ip ${dev:-unknown} $ports"
    done
}

# ---------------------------------------------------------------------------
# SMB mounts and sessions
# ---------------------------------------------------------------------------
# "mountpoint|server|share" for every smbfs mount
cs_smb_mounts() {
    mount 2>/dev/null | awk '/\(smbfs/{
        line=$0
        src=line; sub(/ on .*/,"",src)
        mp=line; sub(/^.* on /,"",mp); sub(/ \(smbfs.*$/,"",mp)
        sub(/^\/\//,"",src); sub(/^[^@\/]*@/,"",src)
        srv=src; sub(/\/.*/,"",srv)
        sh=src; sub(/^[^\/]*\//,"",sh)
        print mp "|" srv "|" sh
    }'
}

# "mountpoint|rx_bytes|tx_bytes|rx_pkts|tx_pkts|reconnects|multichannel|server_ips"
# from smbutil multichannel -a (cumulative per session)
cs_smb_sessions() {
    cs_as_user smbutil multichannel -a 2>/dev/null | awk '
        function flush(){ if(m!="") print m "|" rx "|" tx "|" rxp "|" txp "|" rc "|" mc "|" ips; m=""; rx=tx=rxp=txp=rc=""; mc=""; ips="" }
        /^Session: /{ flush(); m=substr($0,10) }
        /Multichannel ON:/{ s=$0; sub(/.*Multichannel ON: /,"",s); sub(/,.*/,"",s); mc=s }
        /Reconnect Count:/{ s=$0; sub(/.*Reconnect Count: /,"",s); sub(/[^0-9].*/,"",s); rc=s }
        /Total RX Bytes:/{ rx=$4; s=$0; sub(/.*Packets: /,"",s); sub(/\).*/,"",s); rxp=s }
        /Total TX Bytes:/{ tx=$4; s=$0; sub(/.*Packets: /,"",s); sub(/\).*/,"",s); txp=s }
        /\]/{ s=$0; sub(/.*\][ \t]+/,"",s); split(s,a,/[ \t]+/); if(a[1] ~ /^[0-9a-fA-F.:]+$/ && index(ips,a[1])==0) ips=(ips==""?a[1]:ips "," a[1]) }
        END{ flush() }'
}

# ---------------------------------------------------------------------------
# Capture state
# ---------------------------------------------------------------------------
cs_read_state() {
    [[ -f $CINESYS_STATE ]] || return 1
    CAP=$(<"$CINESYS_STATE")
    [[ -d $CAP ]] || return 1
    return 0
}

# Records a background collector: name, pid, output file.
cs_add_collector() {
    print -r -- "$1	$2	$(cs_now)	$3" >> "$CAP/Raw/collectors.tsv"
}

# True if pid is alive and its command line contains the expected text
# (guards against a recycled pid).
cs_pid_is() {
    local cmd
    cmd=$(ps -p "$1" -o command= 2>/dev/null) || return 1
    [[ $cmd == *"$2"* ]]
}

cs_bytes_h() {
    local b=${1:-0}
    if (( b >= 1073741824 )); then printf '%.1f GB' $(( b / 1073741824.0 ))
    elif (( b >= 1048576 )); then printf '%.1f MB' $(( b / 1048576.0 ))
    else printf '%d KB' $(( b / 1024 )); fi
}

cs_dir_bytes() { du -sk "$1" 2>/dev/null | awk '{print $1*1024}' }

# ---------------------------------------------------------------------------
# Path MTU: don't-fragment pings
# ---------------------------------------------------------------------------
# cs_pmtu_probe <ip> <payload> [count] -> ok | toobig (a router answered
# "fragmentation needed") | local (bigger than this Mac's MTU) | silent
cs_pmtu_probe() {
    local out
    out=$(ping -n -D -s $2 -c ${3:-2} -t ${3:-2} $1 2>&1)
    if [[ $out == *"bytes from"* ]]; then print ok
    elif [[ ${(L)out} == *"frag needed"* ]]; then print toobig
    elif [[ ${(L)out} == *"message too long"* ]]; then print local
    else print silent; fi
}

# cs_pmtu <ip> <interface mtu> -> "Result LargestPassing Probe1500 ProbeAtMtu"
#   Result: OK | SilentDrop (switch port, VLAN or target interface at a smaller
#   MTU) | RouterRefused (a routed hop answered "fragmentation needed") |
#   NoReply (ICMP blocked: not testable)
cs_pmtu() {
    local ip=$1 mtu=${2:-1500} base big=- lo hi mid r fail bp
    (( mtu < 1500 )) && bp=$(( mtu - 28 )) || bp=1472
    base=$(cs_pmtu_probe $ip $bp)
    if [[ $base != ok ]]; then
        [[ $(cs_pmtu_probe $ip 32) == ok ]] || { print "NoReply - $base -"; return }
        lo=32; hi=$bp; fail=$base
    elif (( mtu > 1500 )); then
        big=$(cs_pmtu_probe $ip $(( mtu - 28 )))
        [[ $big == ok ]] && { print "OK $mtu $base $big"; return }
        lo=$bp; hi=$(( mtu - 28 )); fail=$big
    else
        print "OK $(( bp + 28 )) $base -"; return
    fi
    while (( hi - lo > 1 )); do
        mid=$(( (lo + hi) / 2 ))
        r=$(cs_pmtu_probe $ip $mid 1)
        if [[ $r == ok ]]; then lo=$mid; else hi=$mid; [[ $r == toobig ]] && fail=toobig; fi
    done
    if [[ $fail == toobig ]]; then print "RouterRefused $(( lo + 28 )) $base $big"; else print "SilentDrop $(( lo + 28 )) $base $big"; fi
}
