#!/bin/zsh
# Per-second sampler. Started in the background by Start-CinesysCapture.sh:
#     zsh lib/sampler.zsh <capture folder>
# Writes Raw/sampler.csv: epoch, PerfMon-style time, then one column per
# counter. Rates are computed from cumulative counters over the real elapsed
# time between samples. Stops on SIGTERM.

CAP=$1
CINESYS_ROOT=${0:A:h:h}
source "$CINESYS_ROOT/lib/common.zsh"
source "$CAP/Raw/config.zsh"

OUT=$CAP/Raw/sampler.csv
running=1
trap 'running=0' TERM INT HUP

typeset -A cur prev
typeset -a cols disks

# One "key value" line per counter, from every source, into $cur.
read_counters() {
    cur=()
    local k v
    # NIC counters: the <Link#> row of netstat -ibn. The Address column is
    # empty for some interfaces, so fields are counted from the end.
    while read -r k v; do cur[$k]=$v; done < <(netstat -ibn 2>/dev/null | awk -v ifs=" ${WATCH_IFS[*]} " '
        $3 ~ /^<Link#/ && index(ifs, " " $1 " ") {
            print "if." $1 ".ipkts", $(NF-6); print "if." $1 ".ierrs", $(NF-5); print "if." $1 ".ibytes", $(NF-4)
            print "if." $1 ".opkts", $(NF-3); print "if." $1 ".oerrs", $(NF-2); print "if." $1 ".obytes", $(NF-1) }')

    # SMB sessions (cumulative bytes per mount)
    local line m rest
    for line in ${(f)"$(cs_smb_sessions)"}; do
        m=${line%%|*}; rest=(${(s:|:)line})
        cur[smb.$m.rx]=${rest[2]}; cur[smb.$m.tx]=${rest[3]}
        cur[smb.$m.rxp]=${rest[4]}; cur[smb.$m.txp]=${rest[5]}; cur[smb.$m.rc]=${rest[6]}
    done

    # TCP (all of TCP on this Mac; macOS reports IPv4 and IPv6 together).
    # Needs root; without it every value reads 0.
    if [[ $TCP_STATS == yes ]]; then
        while read -r k v; do cur[$k]=$v; done < <(netstat -s -p tcp 2>/dev/null | awk '
            /packets? sent$/ && !s { print "tcp.sent", $1; s=1 }
            /data packets? \(.*\) retransmitted/ { print "tcp.rexmt", $1 }
            /packets? received$/ && !r { print "tcp.recv", $1; r=1 }
            /duplicate acks?$/ { print "tcp.dupack", $1 }
            /out-of-order packets?/ { print "tcp.ooo", $1 }
            /retransmit timeouts?$/ { print "tcp.rto", $1 }')
    fi

    # UDP and IP fragments (readable without root). Avid NEXIS moves its data
    # over UDP; full socket buffers and failed reassembly are how it loses data.
    while read -r k v; do cur[$k]=$v; done < <(netstat -s -p udp 2>/dev/null | awk '
        /datagrams received$/ && !r { print "udp.recv", $1; r = 1 }
        /with incomplete header$|with bad data length field$|with bad checksum$/ { e += $1 }
        /dropped due to no socket$/ { print "udp.noport", $1 }
        /dropped due to full socket buffers$/ { print "udp.fullsock", $1 }
        /datagrams output$/ && !o { print "udp.sent", $1; o = 1 }
        END { print "udp.err", e + 0 }')
    while read -r k v; do cur[$k]=$v; done < <(netstat -s -p ip 2>/dev/null | awk '
        /fragments received$/ && !f { print "ip.frag", $1; f = 1 }
        /fragments dropped/ { d += $1 }
        END { print "ip.fragfail", d + 0 }')

    # Memory (pages)
    while read -r k v; do cur[$k]=$v; done < <(vm_stat 2>/dev/null | awk -F: '
        NR==1 { if (match($0,/page size of [0-9]+/)) print "vm.pagesize", substr($0,RSTART+13,RLENGTH-13); next }
        { v=$2; gsub(/[ .]/,"",v); k=$1; gsub(/"/,"",k); gsub(/ /,"_",k); print "vm." k, v }')
    cur[vm.pressure]=$(sysctl -n kern.memorystatus_vm_pressure_level 2>/dev/null)
    cur[vm.level]=$(sysctl -n kern.memorystatus_level 2>/dev/null)

    # Disks: cumulative bytes, operations and total time (ns) per whole disk
    while read -r k v; do cur[$k]=$v; done < <(ioreg -r -c IOBlockStorageDriver -w0 -l -d 3 2>/dev/null | awk '
        /"Statistics" = \{/ { s=$0; have=1; next }
        have && /"BSD Name" = "disk[0-9]+"$/ {
            d=$0; sub(/.*"BSD Name" = "/,"",d); sub(/".*/,"",d)
            n=split("Bytes (Read)|Bytes (Write)|Operations (Read)|Operations (Write)|Total Time (Read)|Total Time (Write)|Errors (Read)|Errors (Write)", f, "|")
            split("rb|wb|ro|wo|rt|wt|re|we", key, "|")
            for (i=1;i<=n;i++) { p="\"" f[i] "\"="; j=index(s,p); if (j) { x=substr(s,j+length(p)); sub(/[^0-9].*/,"",x); print "disk." d "." key[i], x } }
            have=0 }')
}

# Row builders: append one value to $v without forking a subshell.
ar() {
    # per-second rate of a cumulative counter; empty when missing or reset
    local a=${cur[$1]:-} b=${prev[$1]:-} r
    if [[ -z $a || -z $b ]] || (( a < b )); then v+=(""); return; fi
    printf -v r '%.3f' $(( (a - b) / dt )); v+=($r)
}
ac() { v+=("${cur[$1]:-}") }
amb() {
    local r
    if [[ -z ${cur[$1]:-} ]]; then v+=(""); return; fi
    printf -v r '%.1f' $(( ${cur[$1]} * ps / mb )); v+=($r)
}
alat() {
    # average seconds per operation over the interval
    local o1=${prev[disk.$1.$2o]:-} o2=${cur[disk.$1.$2o]:-} t1=${prev[disk.$1.$2t]:-} t2=${cur[disk.$1.$2t]:-} r
    if [[ -z $o1 || -z $o2 || -z $t1 || -z $t2 ]] || (( o2 < o1 )); then v+=(""); return; fi
    if (( o2 > o1 )); then printf -v r '%.6f' $(( (t2 - t1) / 1e9 / (o2 - o1) )); v+=($r); else v+=(0); fi
}
aerr() {
    local a1=${prev[disk.$1.re]:-} a2=${cur[disk.$1.re]:-} b1=${prev[disk.$1.we]:-} b2=${cur[disk.$1.we]:-} r
    if [[ -z $a1 || -z $a2 || -z $b1 || -z $b2 ]]; then v+=(""); return; fi
    printf -v r '%.3f' $(( (a2 - a1 + b2 - b1) / dt )); v+=($r)
}

build_header() {
    local h="\\\\$HOSTTAG" i m inst dk c
    cols=('"epoch"' '"(PDH-CSV 4.0) (Local Time)"')
    for i in $WATCH_IFS; do
        inst=${IF_LABEL[$i]:-$i}
        for c in 'Bytes Received/sec' 'Bytes Sent/sec' 'Packets Received/sec' 'Packets Sent/sec' 'Packets Received Errors/sec' 'Packets Outbound Errors/sec'; do
            cols+=("\"$h\\Network Interface($inst)\\$c\"")
        done
    done
    for m in $MOUNTS; do
        inst=${MOUNT_INST[$m]}
        for c in 'Read Bytes/sec' 'Write Bytes/sec' 'Packets Received/sec' 'Packets Sent/sec' 'Reconnect Count'; do
            cols+=("\"$h\\SMB Client Shares($inst)\\$c\"")
        done
    done
    if [[ $TCP_STATS == yes ]]; then
        for c in 'Segments Sent/sec' 'Segments Received/sec' 'Segments Retransmitted/sec' 'Duplicate Acks Received/sec' 'Out-of-Order Segments Received/sec' 'Retransmit Timeouts/sec'; do
            cols+=("\"$h\\TCPv4\\$c\"")
        done
    fi
    for c in 'Datagrams Received/sec' 'Datagrams Sent/sec' 'Datagrams Received Errors/sec' 'Receive Buffer Errors/sec' 'Datagrams No Port/sec'; do
        cols+=("\"$h\\UDPv4\\$c\"")
    done
    for c in 'Fragments Received/sec' 'Fragment Re-assembly Failures/sec'; do
        cols+=("\"$h\\IPv4\\$c\"")
    done
    for c in 'Available MBytes' 'Free MBytes' 'Active MBytes' 'Inactive MBytes' 'Wired MBytes' 'Compressed MBytes' 'File-backed MBytes' 'Pageins/sec' 'Pageouts/sec' 'Compressions/sec' 'Decompressions/sec' 'Pressure Level' 'Memory Status Level %'; do
        cols+=("\"$h\\Memory\\$c\"")
    done
    disks=(${(ou)${${(k)cur[(I)disk.*.wb]}#disk.}%.wb})
    for dk in $disks; do
        for c in 'Disk Read Bytes/sec' 'Disk Write Bytes/sec' 'Disk Reads/sec' 'Disk Writes/sec' 'Avg. Disk sec/Read' 'Avg. Disk sec/Write' 'Disk Errors/sec'; do
            cols+=("\"$h\\PhysicalDisk($dk)\\$c\"")
        done
    done
    print -r -- ${(j:,:)cols} > $OUT
}

write_row() {
    local -a v
    local ms=${${t#*.}[1,3]} i m dk r avail
    local mb=1048576.0 ps=${cur[vm.pagesize]:-16384}
    v=("$tsec" "\"$(strftime '%m/%d/%Y %H:%M:%S' $tsec).$ms\"")
    for i in $WATCH_IFS; do
        ar if.$i.ibytes; ar if.$i.obytes; ar if.$i.ipkts; ar if.$i.opkts; ar if.$i.ierrs; ar if.$i.oerrs
    done
    for m in $MOUNTS; do
        ar smb.$m.rx; ar smb.$m.tx; ar smb.$m.rxp; ar smb.$m.txp; ac smb.$m.rc
    done
    if [[ $TCP_STATS == yes ]]; then
        ar tcp.sent; ar tcp.recv; ar tcp.rexmt; ar tcp.dupack; ar tcp.ooo; ar tcp.rto
    fi
    ar udp.recv; ar udp.sent; ar udp.err; ar udp.fullsock; ar udp.noport; ar ip.frag; ar ip.fragfail
    avail=""
    [[ -n ${cur[vm.Pages_free]:-} ]] && printf -v avail '%.1f' $(( (${cur[vm.Pages_free]} + ${cur[vm.Pages_inactive]:-0} + ${cur[vm.Pages_speculative]:-0} + ${cur[vm.Pages_purgeable]:-0}) * ps / mb ))
    v+=("$avail")
    amb vm.Pages_free; amb vm.Pages_active; amb vm.Pages_inactive; amb vm.Pages_wired_down; amb vm.Pages_occupied_by_compressor; amb vm.File-backed_pages
    ar vm.Pageins; ar vm.Pageouts; ar vm.Compressions; ar vm.Decompressions; ac vm.pressure; ac vm.level
    for dk in $disks; do
        ar disk.$dk.rb; ar disk.$dk.wb; ar disk.$dk.ro; ar disk.$dk.wo; alat $dk r; alat $dk w; aerr $dk
    done
    print -r -- ${(j:,:)v} >> $OUT
}

# Ticks on a fixed schedule (start + n * interval) so the clock does not drift.
start=$EPOCHREALTIME
n=0
read_counters
build_header
prev=("${(@kv)cur}")
tprev=$EPOCHREALTIME
while (( running )); do
    (( n++ ))
    next=$(( start + n * INTERVAL ))
    wait_cs=$(( int((next - EPOCHREALTIME) * 100) ))
    (( wait_cs > 0 )) && zselect -t $wait_cs 2>/dev/null
    (( running )) || break
    t=$EPOCHREALTIME
    tsec=${t%.*}
    read_counters
    dt=$(( t - tprev ))
    (( dt <= 0 )) && dt=1
    write_row
    prev=("${(@kv)cur}")
    tprev=$t
done
