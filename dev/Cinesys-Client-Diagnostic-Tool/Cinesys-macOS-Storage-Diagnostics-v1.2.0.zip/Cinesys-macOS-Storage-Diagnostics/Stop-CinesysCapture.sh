#!/bin/zsh
[ -z "$ZSH_VERSION" ] && exec /bin/zsh "$0" "$@"
# Stops the running capture, writes the post-capture snapshot, builds
# Cinesys-Performance.csv and Capture-Summary.txt, and packs the summary zip.
#
#     sudo zsh Stop-CinesysCapture.sh
#     sudo zsh Stop-CinesysCapture.sh --no-package

CINESYS_ROOT=${0:A:h}
source "$CINESYS_ROOT/lib/common.zsh"

PACKAGE=yes
AUTO_CAP=""
while (( $# )); do
    case $1 in
        --no-package) PACKAGE=no; shift ;;
        --auto) AUTO_CAP=$2; shift 2 ;;   # used by the automatic stop
        -h|--help) print "Usage: sudo zsh Stop-CinesysCapture.sh [--no-package]"; exit 0 ;;
        *) cs_die "Unknown option: $1" ;;
    esac
done

cs_read_state || cs_die "No capture is running (nothing recorded in $CINESYS_STATE)."
# The automatic stop only acts on the capture that started it.
[[ -n $AUTO_CAP && $AUTO_CAP != $CAP ]] && exit 0
source $CAP/Raw/config.zsh
if ! cs_is_root && [[ $ALLOW_NONROOT != yes ]]; then
    cs_die "Run with sudo:  sudo zsh $0"
fi
if [[ -f $CAP/Raw/stopping ]]; then cs_die "This capture is already being stopped: $CAP"; fi
print -r -- $$ > $CAP/Raw/stopping

source $CINESYS_ROOT/lib/snapshot.zsh
source $CINESYS_ROOT/lib/detect.zsh
source $CINESYS_ROOT/lib/manifest.zsh
cs_load_hwports
[[ -n $AUTO_CAP ]] && cs_log "Automatic stop (time limit reached)."
cs_log "Stopping capture $CAP ..."

# ---------------------------------------------------------------------------
# Collectors
# ---------------------------------------------------------------------------
STOPPED=$(cs_now)
: > $CAP/Raw/collector-status.tsv
while IFS=$'\t' read -r name pid started out match; do
    [[ -n $AUTO_CAP && $name == AutoStop ]] && { print -r -- "$name	Finished	$STOPPED" >> $CAP/Raw/collector-status.tsv; continue }
    if cs_pid_is $pid "$match"; then
        pkill -TERM -P $pid 2>/dev/null
        kill -TERM $pid 2>/dev/null
        for i in {1..25}; do kill -0 $pid 2>/dev/null || break; sleep 0.2; done
        if kill -0 $pid 2>/dev/null; then pkill -KILL -P $pid 2>/dev/null; kill -KILL $pid 2>/dev/null; fi
        print -r -- "$name	Stopped	$STOPPED" >> $CAP/Raw/collector-status.tsv
    else
        print -r -- "$name	Had already exited	" >> $CAP/Raw/collector-status.tsv
        [[ $name == (KeepAwake|AutoStop) ]] || cs_warn "$name was no longer running when the capture was stopped. See Raw/$name.log."
    fi
done < <(tail -r $CAP/Raw/collectors.tsv)
cs_log "Collectors stopped."

# ---------------------------------------------------------------------------
# Post-capture state
# ---------------------------------------------------------------------------
cs_snapshot Post
cs_detect $CAP/Storage-Post.txt
print -rl -- $CS_DET > $CAP/Raw/storage-post.txt
cs_topology Post

# SMB client log and sleep/wake for the capture window, in the format the
# Windows analyzer reads (Storage-Events-*.csv).
cs_log "Writing Storage-Events-SMB.csv ..."
logsrc=$CAP/Raw/smb-log-stream.txt
if ! grep -q '^[0-9]\{4\}-' $logsrc 2>/dev/null; then
    cs_timeout 120 $CS_LOG show --start "$STARTED" --end "$STOPPED" --style compact --predicate "$CS_SMB_PREDICATE" > $CAP/Raw/smb-log-window.txt 2>&1
    logsrc=$CAP/Raw/smb-log-window.txt
fi
{
    print -r -- 'TimeCreated,Provider,Id,Level,Message'
    awk '
        function q(s) { gsub(/"/, "\"\"", s); return "\"" s "\"" }
        /^[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9] / {
            lv = $3; lvl = (lv == "E") ? "Error" : (lv == "F") ? "Critical" : (lv == "I") ? "Information" : (lv == "Db") ? "Verbose" : "Information"
            proc = $4; sub(/\[.*/, "", proc); first = 5; prov = proc
            if ($5 ~ /^\(.*\)$/) { prov = substr($5, 2, length($5) - 2); first = 6 }
            msg = ""; for (i = first; i <= NF; i++) msg = msg (i > first ? " " : "") $i
            print $1 " " $2 "," q(prov) ",0," lvl "," q(msg)
        }' $logsrc
    pmset -g log 2>/dev/null | awk -v a="$STARTED" -v b="$STOPPED" '
        function q(s) { gsub(/"/, "\"\"", s); return "\"" s "\"" }
        ($4 == "Sleep" || $4 == "Wake" || $4 == "DarkWake") && ($1 " " $2) >= a && ($1 " " $2) <= b {
            msg = ""; for (i = 4; i <= NF; i++) msg = msg (i > 4 ? " " : "") $i
            print $1 " " $2 ",\"powerd\",0,Warning," q(msg)
        }'
} > $CAP/Storage-Events-SMB.csv

# ---------------------------------------------------------------------------
# Cinesys-Performance.csv and Capture-Summary.txt
# ---------------------------------------------------------------------------
cs_log "Building Cinesys-Performance.csv ..."
typeset -a srcs
for f in cpu nettop powermetrics; do [[ -s $CAP/Raw/$f.txt ]] && srcs+=($CAP/Raw/$f.txt); done
if [[ -s $CAP/Raw/sampler.csv ]]; then
    awk -v servers="${SERVER_IPS[*]}" -v smb="${SMB_SERVERS[*]}" -v host=$HOSTTAG -v iv=$INTERVAL -f $CINESYS_ROOT/lib/build-csv.awk $srcs $CAP/Raw/sampler.csv > $CAP/Cinesys-Performance.csv
else
    cs_warn "The sampler recorded no data (Raw/sampler.csv is missing or empty). See Raw/Sampler.log."
fi

cs_log "Writing Capture-Summary.txt ..."
names=""
for k v in ${(kv)SERVER_NAME}; do names+="$v=$k;"; done
roles=""
for k v in ${(kv)TARGET_ROLE}; do roles+="$k=$v;"; done
{
    print -r -- "CINESYS STORAGE DIAGNOSTICS FOR macOS $CINESYS_VERSION - CAPTURE SUMMARY"
    print -r -- "=================================================================="
    print -r -- "Host:      $HOSTTAG ($(scutil --get ComputerName 2>/dev/null))"
    print -r -- "Capture:   $STARTED to $STOPPED${LABEL:+   Label: $LABEL}"
    print -r -- "Folder:    $CAP"
    [[ $ALLOW_NONROOT == yes ]] && ! cs_is_root && print -r -- "Mode:      test mode without sudo (TCP statistics, per-core CPU, packet capture and I/O trace not collected)"
    print -r -- ""
    print -r -- "COLLECTORS"
    print -r -- "----------"
    while IFS=$'\t' read -r name st at; do printf '%-14s %s\n' $name $st; done < $CAP/Raw/collector-status.tsv
    if [[ -f $CAP/Raw/collector-notes.tsv ]]; then
        while IFS=$'\t' read -r name at st note; do printf '%-14s %s: %s\n' $name $st $note; done < $CAP/Raw/collector-notes.tsv
    fi
    print -r -- ""
    print -r -- "FINDINGS"
    print -r -- "--------"
    if [[ -s $CAP/Raw/findings-pre.txt || -s $CAP/Raw/findings-post.txt ]]; then
        awk -F'|' 'FNR==NR { pre[$0]=1; printf "%-5s %s\n", $1, $2; next } !($0 in pre) { printf "%-5s %s (seen after the capture)\n", $1, $2 }' $CAP/Raw/findings-pre.txt(N) $CAP/Raw/findings-post.txt(N)
    else
        print -r -- "(none)"
    fi
    print -r -- ""
    if [[ -s $CAP/Cinesys-Performance.csv ]]; then
        awk -v stalls=$CAP/Stalls.csv -v mindrop=2 -v names="$names" -v roles="$roles" -v nexis="$(grep -c '^NEXIS|' $CAP/Raw/storage-pre.txt 2>/dev/null)" -f $CINESYS_ROOT/lib/summarize.awk $CAP/Cinesys-Performance.csv
    fi
    print -r -- "EVENTS"
    print -r -- "------"
    ne=$(( $(wc -l < $CAP/Storage-Events-SMB.csv) - 1 ))
    print -r -- "SMB client log lines and sleep/wake events in the capture window: $ne (Storage-Events-SMB.csv)"
    if (( ne > 0 )); then
        awk -F'"' 'NR>1 { m=$4; gsub(/[0-9]+/, "#", m); c[$2 ": " m]++ } END { for (k in c) printf "%6d  %s\n", c[k], k }' $CAP/Storage-Events-SMB.csv | sort -rn | head -10
    fi
    nchg=$(awk -F, 'NR>1 && $4 != "\"(baseline)\""' $CAP/Path-Health-Changes.csv 2>/dev/null | wc -l | tr -d ' ')
    print -r -- "Path changes (link, route, server reachability, mounts): $nchg (Path-Health-Changes.csv)"
    awk -F, 'NR>1 && $4 != "\"(baseline)\""' $CAP/Path-Health-Changes.csv 2>/dev/null | head -20 | sed 's/^/    /'
    print -r -- ""
    typeset -a big=($CAP/Raw/Packets*.pcapng*(N) $CAP/Raw/FS-Usage.txt(N))
    if (( ${#big} )); then
        print -r -- "LARGE FILES (not in the .summary.zip; New-CinesysPackage.sh --kind full includes them)"
        print -r -- "-------------------------------------------------------------------------------------"
        for f in $big; do printf '%-36s %s\n' ${f#$CAP/} "$(cs_bytes_h $(stat -f %z $f))"; done
        print -r -- ""
    fi
    print -r -- "NEXT STEP"
    print -r -- "---------"
    print -r -- "Engineers: run Invoke-CinesysAnalysis.ps1 (Windows toolkit) on this folder"
    print -r -- "together with the server's capture to line up both sides of each drop."
} > $CAP/Capture-Summary.txt 2>&1

cs_write_manifest Completed

# Captures are taken with sudo; hand the files to the user who ran it.
if cs_is_root && [[ -n $SMB_USER && $SMB_USER != root ]]; then
    chown -R "$SMB_USER" "$CAP" 2>/dev/null
fi
rm -f $CINESYS_STATE $CAP/Raw/stopping

print -r -- ""
sed -n '/^FINDINGS/,/^$/p' $CAP/Capture-Summary.txt
nd=$(( $(wc -l < $CAP/Stalls.csv 2>/dev/null || print 1) - 1 ))
cs_log "Throughput drops found: $(( nd < 0 ? 0 : nd )) (details in Capture-Summary.txt)"

for f in $CAP/Raw/Packets*.pcapng*(N) $CAP/Raw/FS-Usage.txt(N); do
    cs_log "Large file kept in the capture folder (not in the summary zip): $f ($(cs_bytes_h $(stat -f %z $f)))"
done
if [[ $PACKAGE == yes ]]; then
    zsh $CINESYS_ROOT/New-CinesysPackage.sh --capture "$CAP" --kind summary
fi
cs_log "Capture saved in $CAP"
