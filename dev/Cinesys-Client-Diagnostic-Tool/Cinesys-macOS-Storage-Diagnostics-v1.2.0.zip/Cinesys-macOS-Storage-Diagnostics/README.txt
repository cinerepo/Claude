CINESYS STORAGE DIAGNOSTICS FOR macOS
=====================================

This folder contains scripts that Cinesys uses to troubleshoot slow file
transfers and playback on a Mac: network shares (SMB, NFS), StorNext/Xsan
volumes (SAN or LAN client), iSCSI and Fibre Channel storage, or a Mac
that is simply slow. You run it on the Mac while the problem is happening,
then send us the result.

It only records. It does not change your network, shares or settings, and
it does not read or copy the contents of your files. It does record names
that describe your setup, such as server names, IP addresses, share names,
network adapter names and the Mac's model and serial number. The data stays
on the Mac until you send it. Docs/MANUAL.txt lists exactly what is
collected.


WHAT IT RECORDS
---------------

- Which storage the Mac uses and how it is connected (shares, StorNext,
  iSCSI, Fibre Channel, and which network adapter carries each one).
- Every second: how fast each mounted share or storage connection is
  reading and writing, the traffic and errors on each network adapter, the
  connections' round trip time and retransmissions, memory, CPU and disk
  activity.
- Messages the Mac's SMB client logs while the capture runs, such as
  disconnects and reconnects.
- A snapshot of the setup before and after: network adapters and their link
  speed, routing and DNS, which adapter reaches the server, SMB version and
  signing, power
  and sleep settings, and installed add-ons that can affect file transfers
  (for example security or VPN software).
- A hardware inventory of the Mac (model, chip, memory, serial number,
  network adapters and their drivers, Thunderbolt and PCI devices).
- Every 5 seconds: whether each adapter is up, which adapter the server is
  reached through, and whether each share is still mounted.
- Only if Cinesys asks for it: packet headers (never the data inside
  the packets), or a trace of every file read and write of one application.


BEFORE YOU START
----------------

- An administrator account on the Mac (you will be asked for its password).
- macOS 12 or later. Nothing needs to be installed.
- At least 5 GB free on the startup disk.
- Mount the share or volume you are having trouble with first (for a
  share: Finder > Go > Connect to Server). The scripts find everything that
  is mounted or connected when you start.
- Plug in the power adapter if it is a laptop, and use the network
  connection you normally use for this work.


HOW TO RUN IT
-------------

1. Copy this whole folder to the Mac, for example to your Desktop.

2. Open Terminal (Applications > Utilities > Terminal).

3. Type "cd " (with a space), drag the folder from Finder into the Terminal
   window, and press Return. If macOS asks whether Terminal may access the
   folder, click OK.

4. Start the capture:

       sudo zsh Start-CinesysCapture.sh

   Type your Mac password when asked (nothing appears while you type).
   Wait until it says "Capture running". This takes about half a minute.

5. Reproduce the problem. For example, start the copy that slows down or
   play the file that stutters. Write down the time you saw the problem; it
   helps us find it in the data.

   Ten to thirty minutes is usually enough. You can close the Terminal
   window; the capture keeps running. It stops by itself after 12 hours.

6. Stop the capture (open Terminal and go to the folder again if you closed
   it):

       sudo zsh Stop-CinesysCapture.sh

   Leave the window open until it says "Capture saved in ...". This takes
   about 15 seconds.


WHAT TO SEND US
---------------

Stop prints a line like:

    Package: /Users/Shared/Cinesys-Storage-Diagnostics/<MAC NAME>_<DATE>-<TIME>.summary.zip

Send that file using the upload link your Cinesys engineer gave you. It is
usually under 10 MB. To find it in Finder: Go > Go to Folder, and type
/Users/Shared/Cinesys-Storage-Diagnostics

Please also tell us:
- the time(s) you saw the problem,
- what you were doing (for example "copied a 50 GB folder from the
  desktop to the Projects share"),
- which other machines you ran the Cinesys scripts on, if any.

You can look at the results yourself: Capture-Summary.txt in the capture
folder lists what was found.


QUICK CHECK (NO RECORDING)
--------------------------

If Cinesys only asks for a check of the Mac, run this instead of steps 4-6.
It takes about a minute and prints where the result was saved; send the
.summary.zip it names.

    sudo zsh Get-CinesysStorageInfo.sh


IF CINESYS ASKS FOR A SPECIFIC OPTION
-------------------------------------

Add the option to the Start command. Do not use these unless asked.
(Cinesys engineers: the option guide is Docs/Engineer-Guide.txt.)

    --target 10.0.0.25              Only watch this server.
    --duration 30                   Stop by itself after 30 minutes.
    --packet-capture headers        Also record packet headers.
    --io-trace "Premiere"           Record every file read and write of one application
                                    (start the application first).
    --label "test 2"                A note stored with the capture.

Example:

    sudo zsh Start-CinesysCapture.sh --target 10.0.0.25 --duration 30


OTHER COMMANDS
--------------

Check whether a capture is running (no password needed):

    zsh Get-CinesysCaptureStatus.sh

Abandon a capture without finishing it (whatever was recorded is kept):

    sudo zsh Cancel-CinesysCapture.sh

Pack a capture again, using the capture folder that Stop printed:

    zsh New-CinesysPackage.sh --capture "<the capture folder>"

Pack everything, including packet headers (only if Cinesys asks):

    zsh New-CinesysPackage.sh --capture "<the capture folder>" --kind full


IF SOMETHING GOES WRONG
-----------------------

It says "No network storage found"
    It still records the Mac itself. If the problem is with a share or
    volume, mount it first, stop, and start again.

"A capture is already running"
    A previous capture was never stopped. Run Stop (or Cancel), then Start
    again.

"Run with sudo"
    Type sudo in front of the command, as shown above.

A line starting with WARNING
    Part of the recording could not start. The rest still runs and is still
    useful. Send the capture anyway.

The Mac restarted or went to sleep during the capture
    Run Stop when it is back. Send us the folder anyway.


REMOVING IT
-----------

Nothing is installed. Delete this folder, and delete
/Users/Shared/Cinesys-Storage-Diagnostics when you no longer need the
captures.
