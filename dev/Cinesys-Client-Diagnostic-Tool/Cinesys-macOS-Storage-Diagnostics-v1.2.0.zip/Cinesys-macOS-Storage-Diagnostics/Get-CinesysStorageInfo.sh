#!/bin/zsh
[ -z "$ZSH_VERSION" ] && exec /bin/zsh "$0" "$@"
# Quick check of a client Mac, no capture: what storage it uses (SMB, NFS,
# StorNext/Xsan SAN or DLC, iSCSI, Fibre Channel, NVMe-oF), how it is
# connected, network configuration, hardware inventory and findings.
# Takes about a minute and only reads.
#
#     sudo zsh Get-CinesysStorageInfo.sh
#     sudo zsh Get-CinesysStorageInfo.sh --target 10.1.2.3

CINESYS_ROOT=${0:A:h}
source "$CINESYS_ROOT/lib/common.zsh"

usage() {
    cat <<EOF
Cinesys Storage Diagnostics for macOS $CINESYS_VERSION - storage and network check

Usage: sudo zsh Get-CinesysStorageInfo.sh [options]

  --target NAME|IP   Also check the path to this server (repeat or comma-separate).
  --output FOLDER    Where the result goes. Default: $CINESYS_DEFAULT_OUTPUT
  -h, --help         This text.

Without sudo it still runs, but StorNext (cvadmin), packet filter and Skywalk
details are left out.
EOF
}

typeset -a ARG_SERVERS
OUTPUT=$CINESYS_DEFAULT_OUTPUT
ARGS_TEXT="$*"
while (( $# )); do
    case $1 in
        --target|--server) ARG_SERVERS+=(${(s:,:)2}); shift 2 ;;
        --output) OUTPUT=$2; shift 2 ;;
        -h|--help) usage; exit 0 ;;
        *) usage; cs_die "Unknown option: $1" ;;
    esac
done
cs_is_root || print -r -- "Note: without sudo, StorNext (cvadmin), packet filter and Skywalk details are left out."

# Settings the shared snapshot and manifest code expects
INTERVAL=1; LABEL=""; PACKET_MODE=none; IOTRACE=""; ALLOW_NONROOT=yes
SMB_USER=${SUDO_USER:-$USER}
SMB_HOME=$(dscl . -read /Users/$SMB_USER NFSHomeDirectory 2>/dev/null | awk '{print $2}')
HOSTTAG=$(scutil --get LocalHostName 2>/dev/null || hostname -s)
SMB_RUN_AS=user
if cs_is_root && smbutil multichannel -a 2>/dev/null | grep -q '^Session:'; then SMB_RUN_AS=root; fi
cs_load_hwports

START_EPOCH=$EPOCHSECONDS
STARTED=$(cs_now)
CAP=$OUTPUT/${HOSTTAG}_$(strftime '%Y%m%d-%H%M%S' $START_EPOCH)_info
mkdir -p $CAP/Raw || cs_die "Cannot create $CAP"
chmod 755 $OUTPUT $CAP 2>/dev/null

source $CINESYS_ROOT/lib/detect.zsh
source $CINESYS_ROOT/lib/discover.zsh
source $CINESYS_ROOT/lib/snapshot.zsh
source $CINESYS_ROOT/lib/manifest.zsh

cs_log "Cinesys Storage Diagnostics for macOS $CINESYS_VERSION - storage and network check"
cs_log "Folder: $CAP"
cs_log "Looking for network and SAN storage ..."
cs_discover $CAP/Storage-Info.txt
print -rl -- $CS_DET > $CAP/Raw/storage-info.txt
for s in $SERVER_IPS; do cs_log "Target: $s ${SERVER_NAME[$s]:+(${SERVER_NAME[$s]}) }- ${TARGET_ROLE[$s]}"; done
for i in $WATCH_IFS; do cs_log "Adapter: ${IF_LABEL[$i]}$( (( ${STORAGE_IFS[(Ie)$i]} )) && print ' (carries storage traffic)')"; done

cs_snapshot Info
cs_inventory
cs_topology Info
STOPPED=$(cs_now)
cs_write_manifest Info

if cs_is_root && [[ -n $SMB_USER && $SMB_USER != root ]]; then chown -R "$SMB_USER" "$CAP" 2>/dev/null; fi

print -r -- ""
print -r -- "STORAGE FOUND (Storage-Info.txt)"
sed -n '/^FOUND/,/^$/p' $CAP/Storage-Info.txt | sed '1,2d'
sed -n '/^STORNEXT \/ XSAN CLIENT MODE/,/^$/p' $CAP/Storage-Info.txt
if [[ -s $CAP/Raw/findings-info.txt ]]; then
    print -r -- "FINDINGS (Topology-Info.txt)"
    awk -F'|' '{printf "  %-5s %s\n", $1, $2}' $CAP/Raw/findings-info.txt
    print -r -- ""
fi
zsh $CINESYS_ROOT/New-CinesysPackage.sh --capture "$CAP" --kind summary
cs_log "Saved in $CAP"
