#!/bin/zsh
[ -z "$ZSH_VERSION" ] && exec /bin/zsh "$0" "$@"
# Starts a Cinesys storage capture on a Mac (client side).
#
#     sudo zsh Start-CinesysCapture.sh                       all storage found on the Mac
#     sudo zsh Start-CinesysCapture.sh --target 10.1.2.3     one server, gateway or portal
#     sudo zsh Start-CinesysCapture.sh --target 10.1.2.3 --duration 30 --packet-capture headers
#
# With no storage found it still runs: a whole-Mac capture (adapters, disks,
# CPU, memory, path to the default gateway).
#
# Run --help for every option. Docs/MANUAL.txt describes what is collected.

CINESYS_ROOT=${0:A:h}
source "$CINESYS_ROOT/lib/common.zsh"

usage() {
    cat <<EOF
Cinesys Storage Diagnostics for macOS $CINESYS_VERSION

Usage: sudo zsh Start-CinesysCapture.sh [options]

  --target NAME|IP       Server to watch: SMB or NFS server, StorNext MDC or DLC
                         gateway, iSCSI portal (repeat or comma-separate).
                         Default: everything found (shares, mounts, sessions).
  --server NAME|IP       Same as --target.
  --output FOLDER        Where capture folders go. Default: $CINESYS_DEFAULT_OUTPUT
  --duration MINUTES     Stop automatically after this many minutes.
  --max-hours HOURS      Safety stop if nobody runs Stop. Default: 12
  --interval SECONDS     Sample interval. Default: 1
  --label TEXT           A note stored with the capture (e.g. "copy test 2").
  --packet-capture MODE  none (default) or headers: first bytes of each packet to
                         and from the targets.
  --packet-size BYTES    Bytes kept per packet with headers. Default: 128
  --packet-file-mb MB    Size of each packet file. Default: 512
  --packet-files N       Packet files kept (oldest overwritten). Default: 4
  --io-trace NAMES       Per-call file I/O trace (fs_usage) of these processes,
                         comma-separated names or PIDs. Large; use for short tests.
  --io-trace-mb MB       I/O trace size limit. Default: 2048
  --no-power-metrics     Skip per-core CPU and thermal sampling (powermetrics).
  --allow-nonroot        Engineer test mode without sudo: TCP statistics, per-core
                         CPU, packet capture and I/O trace are not available.
  -h, --help             This text.
EOF
}

# ---------------------------------------------------------------------------
# Options
# ---------------------------------------------------------------------------
typeset -a ARG_SERVERS
OUTPUT=$CINESYS_DEFAULT_OUTPUT
DURATION=0
MAX_HOURS=12
INTERVAL=1
LABEL=""
PACKET_MODE=none
PACKET_SIZE=128
PACKET_FILE_MB=512
PACKET_FILES=4
IOTRACE=""
IOTRACE_MAX_MB=2048
POWER_METRICS=yes
ALLOW_NONROOT=no
MIN_FREE_MB=2048
ARGS_TEXT="$*"

while (( $# )); do
    case $1 in
        --server|--target) ARG_SERVERS+=(${(s:,:)2}); shift 2 ;;
        --output) OUTPUT=$2; shift 2 ;;
        --duration) DURATION=$2; shift 2 ;;
        --max-hours) MAX_HOURS=$2; shift 2 ;;
        --interval) INTERVAL=$2; shift 2 ;;
        --label) LABEL=$2; shift 2 ;;
        --packet-capture) PACKET_MODE=$2; shift 2 ;;
        --packet-size) PACKET_SIZE=$2; shift 2 ;;
        --packet-file-mb) PACKET_FILE_MB=$2; shift 2 ;;
        --packet-files) PACKET_FILES=$2; shift 2 ;;
        --io-trace) IOTRACE=$2; shift 2 ;;
        --io-trace-mb) IOTRACE_MAX_MB=$2; shift 2 ;;
        --no-power-metrics) POWER_METRICS=no; shift ;;
        --allow-nonroot) ALLOW_NONROOT=yes; shift ;;
        -h|--help) usage; exit 0 ;;
        *) usage; cs_die "Unknown option: $1" ;;
    esac
done

[[ $PACKET_MODE == (none|headers) ]] || cs_die "--packet-capture must be none or headers."
[[ $INTERVAL == <1-60> ]] || cs_die "--interval must be 1 to 60 seconds."
[[ $DURATION == <-> && $MAX_HOURS == <1-> ]] || cs_die "--duration and --max-hours must be whole numbers."

if ! cs_is_root; then
    if [[ $ALLOW_NONROOT == yes ]]; then
        print -r -- "Test mode without sudo: TCP statistics, per-core CPU, packet capture and I/O trace are skipped."
        PACKET_MODE=none; IOTRACE=""; POWER_METRICS=no
    else
        cs_die "Run with sudo:  sudo zsh $0 ${ARGS_TEXT}"
    fi
fi

# ---------------------------------------------------------------------------
# One capture at a time
# ---------------------------------------------------------------------------
if [[ -f $CINESYS_STATE ]]; then
    old=$(<$CINESYS_STATE)
    alive=0
    if [[ -f $old/Raw/collectors.tsv ]]; then
        while IFS=$'\t' read -r name pid started out match; do
            cs_pid_is $pid "$match" && alive=1
        done < $old/Raw/collectors.tsv
    fi
    if (( alive )); then
        cs_die "A capture is already running: $old
Stop it first:  sudo zsh $CINESYS_ROOT/Stop-CinesysCapture.sh"
    fi
    print -r -- "Note: removing the record of an earlier capture that is no longer running ($old)."
    rm -f $CINESYS_STATE
fi

# ---------------------------------------------------------------------------
# What to watch: servers, mounts, interfaces
# ---------------------------------------------------------------------------
SMB_USER=${SUDO_USER:-$USER}
SMB_HOME=$(dscl . -read /Users/$SMB_USER NFSHomeDirectory 2>/dev/null | awk '{print $2}')
HOSTTAG=$(scutil --get LocalHostName 2>/dev/null || hostname -s)
cs_load_hwports

source $CINESYS_ROOT/lib/detect.zsh
source $CINESYS_ROOT/lib/discover.zsh
print -r -- "Looking for network and SAN storage ..."
DETECT_TMP=$(mktemp -d /tmp/cinesys-detect.XXXXXX)
cs_discover $DETECT_TMP/Storage-Pre.txt

TCP_STATS=no
cs_is_root && TCP_STATS=yes

# smbutil lists only the caller's SMB sessions. Under sudo, use root if root
# sees them, otherwise run it as the user who mounted the shares.
SMB_RUN_AS=user
if cs_is_root && smbutil multichannel -a 2>/dev/null | grep -q '^Session:'; then SMB_RUN_AS=root; fi

# ---------------------------------------------------------------------------
# Capture folder and configuration
# ---------------------------------------------------------------------------
START_EPOCH=$EPOCHSECONDS
STARTED=$(cs_now)
CAP=$OUTPUT/${HOSTTAG}_$(strftime '%Y%m%d-%H%M%S' $START_EPOCH)
# The label goes in the folder name too, so captures are easy to tell apart.
labeltag=${${LABEL//[^A-Za-z0-9._-]/-}[1,40]}
[[ -n $labeltag ]] && CAP=${CAP}_$labeltag
mkdir -p $CAP/Raw || cs_die "Cannot create $CAP"
chmod 755 $OUTPUT $CAP 2>/dev/null
print -r -- $CAP > $CINESYS_STATE
: > $CAP/Raw/collectors.tsv

{
    typeset -p HOSTTAG INTERVAL TCP_STATS SMB_USER SMB_HOME SMB_RUN_AS START_EPOCH STARTED LABEL ARGS_TEXT
    typeset -p PACKET_MODE PACKET_SIZE PACKET_FILE_MB PACKET_FILES IOTRACE IOTRACE_MAX_MB POWER_METRICS MIN_FREE_MB DURATION MAX_HOURS ALLOW_NONROOT
    typeset -p SERVER_IPS SERVER_NAME TARGET_ROLE SMB_SERVERS MOUNTS MOUNT_INST MOUNT_SHARE MOUNT_SERVER STORAGE_IFS WATCH_IFS IF_LABEL
} > $CAP/Raw/config.zsh
mv $DETECT_TMP/Storage-Pre.txt $CAP/Storage-Pre.txt 2>/dev/null
print -rl -- $CS_DET > $CAP/Raw/storage-pre.txt
rm -rf $DETECT_TMP

cs_log "Cinesys Storage Diagnostics for macOS $CINESYS_VERSION"
cs_log "Capture folder: $CAP"
[[ -n $LABEL ]] && cs_log "Label: $LABEL"
for s in $SERVER_IPS; do cs_log "Target: $s ${SERVER_NAME[$s]:+(${SERVER_NAME[$s]}) }- ${TARGET_ROLE[$s]}"; done
for m in $MOUNTS; do cs_log "Share:  ${MOUNT_INST[$m]} on $m"; done
for i in $WATCH_IFS; do cs_log "Adapter: ${IF_LABEL[$i]}$( (( ${STORAGE_IFS[(Ie)$i]} )) && print ' (carries storage traffic)')"; done
(( ${#SERVER_IPS} )) || cs_log "No network storage found: whole-Mac capture (adapters, disks, CPU, memory). Use --target to name a server."
(( ${#ARG_SERVERS} && ${#MOUNTS} == 0 && ${#SMB_SERVERS} )) && cs_warn "No SMB share from ${ARG_SERVERS[*]} is mounted. Per-share counters need the share mounted before Start."
[[ $ALLOW_NONROOT == yes ]] && cs_warn "Test mode without sudo: TCP statistics, per-core CPU, packet capture and I/O trace are not collected."

# ---------------------------------------------------------------------------
# Collectors (background, survive the Terminal window closing)
# ---------------------------------------------------------------------------
start_bg() {
    # name, match text for the pid check, output file, command...
    local name=$1 match=$2 out=$3; shift 3
    nohup "$@" >> $CAP/Raw/$name.log 2>&1 &!
    local pid=$!
    print -r -- "$name	$pid	$(cs_now)	${out:--}	$match" >> $CAP/Raw/collectors.tsv
}
ZSH=/bin/zsh
start_bg Sampler 'lib/sampler.zsh' Raw/sampler.csv $ZSH $CINESYS_ROOT/lib/sampler.zsh $CAP
sampler_pid=$!
start_bg PathHealth 'lib/pathhealth.zsh' Path-Health-Samples.csv $ZSH $CINESYS_ROOT/lib/pathhealth.zsh $CAP
start_bg Cpu 'Raw/cpu.txt' Raw/cpu.txt $ZSH $CINESYS_ROOT/lib/run-stamped.zsh $CAP/Raw/cpu.txt iostat -n0 -C -w $INTERVAL
# Per-connection TCP to the targets, whatever the port (DLC and iSCSI ports vary)
if (( ${#SERVER_IPS} )); then
    rx=${(j:|:)${SERVER_IPS//./\\.}}
    start_bg Connections 'Raw/nettop.txt' Raw/nettop.txt $ZSH $CINESYS_ROOT/lib/run-stamped.zsh $CAP/Raw/nettop.txt --filter "^time,|<->($rx)[:.][0-9]" nettop -m tcp -L 0 -s $INTERVAL -n -x
fi
start_bg SmbLog 'log stream' Raw/smb-log-stream.txt $ZSH -c 'exec "$@" > "$0"' $CAP/Raw/smb-log-stream.txt $CS_LOG stream --style compact --predicate "$CS_SMB_PREDICATE"
if [[ $POWER_METRICS == yes ]]; then
    start_bg PowerMetrics 'Raw/powermetrics.txt' Raw/powermetrics.txt $ZSH $CINESYS_ROOT/lib/run-stamped.zsh $CAP/Raw/powermetrics.txt \
        --filter '\*\*\* Sampled|active residency|HW active frequency|pressure level|^CPU [0-9]+ frequency' \
        powermetrics --samplers cpu_power,thermal -i $(( INTERVAL * 1000 ))
fi
if [[ $PACKET_MODE == headers ]]; then
    if (( ${#SERVER_IPS} )); then
        filt="tcp and (${(j: or :)${SERVER_IPS/#/host }})"
        # One tcpdump per adapter, on the adapter itself. Not pktap: tcpdump
        # raises the snapshot length to 512 KB on pktap, which would keep
        # whole packets (file contents) instead of --packet-size bytes.
        typeset -a pifs=($STORAGE_IFS)
        if (( ! ${#pifs} )); then
            for s in $SERVER_IPS; do r=$(cs_route_if $s); [[ -n $r ]] && pifs+=($r); done
        fi
        pifs=(${(u)pifs})
        (( ${#pifs} )) || pifs=(${WATCH_IFS[1]})
        for i in $pifs; do
            start_bg PacketCapture-$i "tcpdump -i $i " Raw/Packets-$i.pcapng tcpdump -i $i -P -n -s $PACKET_SIZE -C $PACKET_FILE_MB -W $PACKET_FILES -w $CAP/Raw/Packets-$i.pcapng $filt
        done
    else
        cs_warn "Packet capture skipped: no storage target. Name one with --target."
    fi
fi
if [[ -n $IOTRACE ]]; then
    # fs_usage matches names against the kernel's short process name, so long
    # application names are turned into PIDs here (exact name first, then any
    # process whose command line contains it, which includes its helpers).
    typeset -a iopids
    for p in ${(s:,:)IOTRACE}; do
        if [[ $p == <-> ]]; then iopids+=($p); continue; fi
        found=(${(f)"$(pgrep -x -- $p 2>/dev/null)"})
        (( ${#found} )) || found=(${(f)"$(pgrep -f -- $p 2>/dev/null)"})
        # not this script or the sudo that runs it (their command lines contain the name too)
        typeset -a keep=()
        for q in $found; do [[ $(ps -p $q -o command= 2>/dev/null) == *CinesysCapture* ]] || keep+=($q); done
        found=($keep)
        if (( ${#found} )); then iopids+=($found); cs_log "I/O trace: '$p' is PID ${found[*]}"
        else cs_warn "I/O trace: no running process matches '$p'. Start the application before the capture."; fi
    done
    if (( ${#iopids} )); then
        start_bg IoTrace 'fs_usage' Raw/FS-Usage.txt $ZSH -c 'exec fs_usage -w -f filesys "$@" > "$0"' $CAP/Raw/FS-Usage.txt ${(u)iopids}
    fi
fi
# Keep the Mac awake while the sampler runs.
start_bg KeepAwake 'caffeinate' '' caffeinate -i -s -w $sampler_pid
# Automatic stop: --duration, or the safety limit.
limit=$(( MAX_HOURS * 3600 ))
(( DURATION > 0 && DURATION * 60 < limit )) && limit=$(( DURATION * 60 ))
start_bg AutoStop 'Stop-CinesysCapture.sh --auto' '' $ZSH -c "sleep $limit; exec $ZSH ${(q)CINESYS_ROOT}/Stop-CinesysCapture.sh --auto ${(q)CAP}"

# Collectors that die straight away (missing permission, unsupported option)
sleep 3
while IFS=$'\t' read -r name pid started out match; do
    if ! kill -0 $pid 2>/dev/null; then
        err=$(tail -3 $CAP/Raw/$name.log $CAP/Raw/*.err(N) 2>/dev/null | grep -v '^==>' | grep -v '^$' | tail -2 | tr '\n' ' ')
        cs_warn "$name did not start or stopped immediately. ${err}"
        print -r -- "$name	$(cs_now)	Failed at start	$err" >> $CAP/Raw/collector-notes.tsv
    elif [[ $name == PacketCapture-* ]] && grep -q 'snaplen raised' $CAP/Raw/$name.log 2>/dev/null; then
        # Never keep whole packets: stop it rather than record file contents.
        kill -TERM $pid 2>/dev/null
        cs_warn "$name stopped: tcpdump would not limit packets to $PACKET_SIZE bytes on this adapter."
        print -r -- "$name	$(cs_now)	Stopped early	would not limit packets to $PACKET_SIZE bytes" >> $CAP/Raw/collector-notes.tsv
    fi
done < $CAP/Raw/collectors.tsv

# ---------------------------------------------------------------------------
# Snapshot, inventory, topology (after the collectors, so data starts at once)
# ---------------------------------------------------------------------------
source $CINESYS_ROOT/lib/snapshot.zsh
source $CINESYS_ROOT/lib/manifest.zsh
cs_snapshot Pre
cs_inventory
cs_topology Pre
cs_write_manifest Running

print -r -- ""
if [[ -s $CAP/Raw/findings-pre.txt ]]; then
    print -r -- "Found before the capture (details in Topology-Pre.txt):"
    awk -F'|' '{printf "  %-5s %s\n", $1, $2}' $CAP/Raw/findings-pre.txt
    print -r -- ""
fi
cs_log "Capture running. Reproduce the problem now (copy, playback, render)."
if (( DURATION > 0 )); then
    cs_log "It stops by itself after $DURATION minutes. To stop earlier:"
else
    cs_log "When done, stop it with:"
fi
cs_log "    sudo zsh $CINESYS_ROOT/Stop-CinesysCapture.sh"
cs_log "Check on it with:  zsh $CINESYS_ROOT/Get-CinesysCaptureStatus.sh"
