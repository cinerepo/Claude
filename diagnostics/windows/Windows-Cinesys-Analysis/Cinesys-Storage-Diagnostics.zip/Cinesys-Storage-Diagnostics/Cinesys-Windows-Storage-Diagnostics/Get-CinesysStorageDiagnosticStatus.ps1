﻿[CmdletBinding()]
param([string]$Root = "C:\Cinesys\Storage-Diagnostic")
Write-Host "===== WPR =====" -ForegroundColor Cyan
& wpr.exe -status
Write-Host "`n===== PERFMON COLLECTORS =====" -ForegroundColor Cyan
foreach($short in @("Disk","Network","CPU","Memory","SMB-Client","SMB-Server","SMB-Direct")){
    $name="Cinesys Storage Diagnostic - $short"
    & logman query "$name" 2>$null | Select-String "Status|Name"
}
Write-Host "`n===== CURRENT CAPTURE =====" -ForegroundColor Cyan
$current=Join-Path $Root "CurrentCapture.txt"
if(Test-Path $current){Get-Content $current}else{"None"}
