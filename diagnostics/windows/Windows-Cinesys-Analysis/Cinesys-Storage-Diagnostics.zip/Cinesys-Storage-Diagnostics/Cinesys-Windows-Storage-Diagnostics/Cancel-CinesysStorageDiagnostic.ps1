﻿#requires -RunAsAdministrator
[CmdletBinding()]
param([string]$Root = "C:\Cinesys\Storage-Diagnostic")
& wpr.exe -cancel 2>$null
foreach($short in @("Disk","Network","CPU","Memory","SMB-Client","SMB-Server","SMB-Direct")){
    & logman stop "Cinesys Storage Diagnostic - $short" 2>$null | Out-Null
}
Remove-Item (Join-Path $Root "CurrentCapture.txt") -Force -ErrorAction SilentlyContinue
Write-Host "Active Cinesys capture cancelled. ETW trace was not saved." -ForegroundColor Yellow
