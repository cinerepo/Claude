﻿#requires -RunAsAdministrator
[CmdletBinding()]
param(
    [string]$Root = "C:\Cinesys\Storage-Diagnostic",
    [ValidateSet("General","StorageDeep")]
    [string]$TraceProfile = "General"
)

$ErrorActionPreference = "Stop"
$stamp = Get-Date -Format "yyyyMMdd-HHmmss"
$capture = Join-Path $Root ("Captures\" + $env:COMPUTERNAME + "_" + $stamp)
New-Item -ItemType Directory -Force -Path $capture | Out-Null
$sets = @("Disk","Network","CPU","Memory","SMB-Client","SMB-Server","SMB-Direct")

# Persist capture metadata so Stop uses exactly the same run.
@"
Host=$env:COMPUTERNAME
Started=$(Get-Date -Format o)
TraceProfile=$TraceProfile
CapturePath=$capture
"@ | Set-Content (Join-Path $capture "Capture-Metadata.txt")

# State snapshot if the v1 snapshot script is installed beside this script or under Root.
$snapshot = @(
    (Join-Path $PSScriptRoot "Snapshot-State.ps1"),
    (Join-Path $Root "Snapshot-State.ps1")
) | Where-Object { Test-Path $_ } | Select-Object -First 1
if ($snapshot) {
    & $snapshot -OutputFile (Join-Path $capture "PreCapture-State.txt")
}

# Start existing PerfMon/logman collectors.
foreach ($short in $sets) {
    $name = "Cinesys Storage Diagnostic - $short"
    & logman query "$name" *> $null
    if ($LASTEXITCODE -eq 0) {
        & logman start "$name" | Out-Null
    }
}

# Make sure no abandoned Cinesys WPR session is active.
$status = (& wpr.exe -status 2>&1 | Out-String)
if ($LASTEXITCODE -eq 0 -and $status -notmatch "not recording|no recording") {
    throw "WPR reports an active recording. Stop/cancel the existing WPR recording before starting Cinesys capture.`n$status"
}

# GeneralProfile is deliberately the production-safe default.
# StorageDeep adds built-in resource profiles when they are present on this OS.
if ($TraceProfile -eq "General") {
    & wpr.exe -start GeneralProfile
    if ($LASTEXITCODE -ne 0) { throw "Failed to start WPR GeneralProfile." }
}
else {
    $profilesText = (& wpr.exe -profiles 2>&1 | Out-String)
    $requested = @("GeneralProfile")
    foreach ($candidate in @("DiskIO","FileIO","Network")) {
        if ($profilesText -match "(?im)^\s*$([regex]::Escape($candidate))\s") {
            $requested += $candidate
        }
    }

    # WPR accepts multiple -start profile clauses.
    $args = @()
    foreach ($p in $requested) { $args += @("-start",$p) }
    & wpr.exe @args
    if ($LASTEXITCODE -ne 0) {
        throw "Failed to start WPR StorageDeep profiles: $($requested -join ', ')"
    }
    ("WPR profiles: " + ($requested -join ", ")) | Add-Content (Join-Path $capture "Capture-Metadata.txt")
}

$capture | Set-Content (Join-Path $Root "CurrentCapture.txt")
Write-Host ""
Write-Host "Cinesys Windows Storage Diagnostic capture started." -ForegroundColor Green
Write-Host "Capture: $capture"
Write-Host "ETW profile: $TraceProfile"
Write-Host ""
Write-Host "Reproduce the problem, then run Stop-CinesysStorageDiagnostic.ps1."
