# Cinesys Windows Storage Diagnostics v2

This version combines the existing Cinesys PerfMon collectors with Windows Performance Recorder (WPR) / Event Tracing for Windows (ETW).

## What gets captured

### PerfMon / BLG
- Disk
- Network/TCP
- CPU/DPC/interrupts
- Memory
- SMB Client
- SMB Server
- SMB Direct (when available)

### ETW / ETL
Default `General` mode uses Microsoft's built-in `GeneralProfile`, which captures a broad kernel performance trace suitable for WPA analysis.

Optional `StorageDeep` mode requests GeneralProfile plus available built-in DiskIO, FileIO and Network profiles. Use this for short, targeted reproductions after the lighter General capture shows that deeper tracing is warranted.

### State
Pre/post snapshots include disk/volume, iSCSI, MPIO/MSDSM, NIC/RSS/RDMA, SMB and recent storage-related System events.

## Start

Run elevated:

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\Start-CinesysStorageDiagnostic.ps1
```

Reproduce the issue.

## Stop

```powershell
.\Stop-CinesysStorageDiagnostic.ps1
```

The capture directory will contain `Cinesys-Windows-Storage.etl`. Open it in Windows Performance Analyzer.

## Deep mode

For a short targeted trace:

```powershell
.\Start-CinesysStorageDiagnostic.ps1 -TraceProfile StorageDeep
```

Do not use deep tracing for arbitrarily long unattended captures. ETW is powerful instrumentation and additional providers increase trace volume and analysis cost.

## Status / emergency cancel

```powershell
.\Get-CinesysStorageDiagnosticStatus.ps1
.\Cancel-CinesysStorageDiagnostic.ps1
```

Cancel discards the active WPR recording.

## WPA workflow

Start with these Graph Explorer areas when present:

1. System Activity / Processes and Threads
2. Computation / CPU Usage (Sampled)
3. Computation / CPU Usage (Precise)
4. Storage / Disk Usage
5. Storage / File I/O
6. DPC/ISR
7. Networking

Use PerfMon to identify the timestamp of a throughput/latency event, then select that same interval in WPA and zoom into it.

### Storage question
If PerfMon shows write latency rising at 14:32:17, use WPA to inspect the corresponding Disk Usage / File I/O interval, processes/threads issuing I/O, CPU scheduling, and DPC/ISR behavior.

### Network question
If TCP retransmissions or throughput change in PerfMon, inspect the same interval in WPA's networking and CPU/DPC views.

## WPA installation
WPR.exe command-line capture is built into modern Windows. WPA is supplied with the Windows Performance Toolkit in the Windows ADK.

## Design choice: memory mode
The default WPR invocation uses WPR's normal memory-mode behavior. This is intentional for field diagnostics: memory logging uses bounded circular buffers, while file mode can continue growing until disk space is exhausted. Use short captures and stop soon after reproducing the issue.

CINESYS STORAGE DIAGNOSTICS - DISKSPD TEST TEMPLATES
====================================================

Use a dedicated test file/path. Do not casually run write or random-write workloads against production storage.
Examples use: E:\Cinesys-Test\test.dat

COMMON OPTIONS
-c20G/-c100G/-c200G = test file size
-b1M = 1 MiB I/O, useful for large sequential/media workloads
-b4K = 4 KiB I/O, useful for small-block/random IOPS testing
-oN = outstanding I/O per worker (queue depth)
-tN = worker threads
-w0 = 100% reads
-w100 = 100% writes
-w30 = 30% writes / 70% reads
-r = random I/O
-dN = measured duration in seconds
-WN = warm-up duration in seconds
-Sh = disable software caching and hardware write caching for the test
-L = collect latency percentile statistics

01 - SEQUENTIAL READ QD1
Purpose: Simple single-stream sequential read baseline for large-file/media read performance.
Command: diskspd.exe -c20G -b1M -o1 -t1 -w0 -d60 -W10 -Sh -L E:\Cinesys-Test\test.dat

02 - SEQUENTIAL WRITE QD1
Purpose: Simple single-stream sequential write baseline; useful for exposing basic read/write asymmetry.
Command: diskspd.exe -c20G -b1M -o1 -t1 -w100 -d60 -W10 -Sh -L E:\Cinesys-Test\test.dat

03 - SEQUENTIAL READ QD8
Purpose: Large sequential reads with more outstanding I/O to test throughput scaling.
Command: diskspd.exe -c100G -b1M -o8 -t1 -w0 -d300 -W30 -Sh -L E:\Cinesys-Test\test.dat

04 - SEQUENTIAL WRITE QD8
Purpose: Sustained large sequential writes with moderate queue depth; useful for media ingest and SAN testing.
Command: diskspd.exe -c100G -b1M -o8 -t1 -w100 -d300 -W30 -Sh -L E:\Cinesys-Test\test.dat

05 - SUSTAINED WRITE 10 MINUTES
Purpose: Look for cache exhaustion, controller destage behavior, thermal throttling, periodic stalls, or throughput collapse hidden by short tests.
Command: diskspd.exe -c200G -b1M -o8 -t1 -w100 -d600 -W30 -Sh -L E:\Cinesys-Test\test.dat

06 - 4K RANDOM READ QD32
Purpose: Small-block random-read IOPS/latency test. Focus on IOPS and latency percentiles rather than MB/s.
Command: diskspd.exe -c20G -b4K -r -o32 -t1 -w0 -d120 -W30 -Sh -L E:\Cinesys-Test\test.dat

07 - 4K RANDOM WRITE QD32
Purpose: Small-block random-write IOPS/latency test. Aggressive workload; use carefully on shared storage.
Command: diskspd.exe -c20G -b4K -r -o32 -t1 -w100 -d120 -W30 -Sh -L E:\Cinesys-Test\test.dat

08 - 4K RANDOM 70% READ / 30% WRITE
Purpose: Mixed transactional-style workload for simultaneous small-block reads and writes.
Command: diskspd.exe -c20G -b4K -r -o32 -t4 -w30 -d120 -W30 -Sh -L E:\Cinesys-Test\test.dat

09 - MULTI-WORKER MEDIA READ
Purpose: Approximate multiple concurrent large sequential readers; 4 workers at QD4 allow roughly 16 outstanding I/Os total.
Command: diskspd.exe -c100G -b1M -o4 -t4 -w0 -d300 -W30 -Sh -L E:\Cinesys-Test\test.dat

10 - MULTI-WORKER MEDIA WRITE
Purpose: Approximate multiple concurrent large sequential writers and observe scaling under multiple streaming workloads.
Command: diskspd.exe -c100G -b1M -o4 -t4 -w100 -d300 -W30 -Sh -L E:\Cinesys-Test\test.dat

QUEUE-DEPTH RESPONSE CURVE
Purpose: Determine where additional outstanding I/O stops buying throughput and starts primarily increasing latency. Keep everything identical except -o.
QD1 : diskspd.exe -c20G -b1M -o1 -t1 -w100 -d60 -W10 -Sh -L E:\Cinesys-Test\test.dat
QD2 : diskspd.exe -c20G -b1M -o2 -t1 -w100 -d60 -W10 -Sh -L E:\Cinesys-Test\test.dat
QD4 : diskspd.exe -c20G -b1M -o4 -t1 -w100 -d60 -W10 -Sh -L E:\Cinesys-Test\test.dat
QD8 : diskspd.exe -c20G -b1M -o8 -t1 -w100 -d60 -W10 -Sh -L E:\Cinesys-Test\test.dat
QD16: diskspd.exe -c20G -b1M -o16 -t1 -w100 -d60 -W10 -Sh -L E:\Cinesys-Test\test.dat
QD32: diskspd.exe -c20G -b1M -o32 -t1 -w100 -d60 -W10 -Sh -L E:\Cinesys-Test\test.dat

For each test record: throughput, IOPS, average latency, p95 latency, and p99 latency.

CINESYS WORKFLOW
1. Start Cinesys Storage Diagnostics.
2. Run ONE controlled DiskSpd workload.
3. Stop DiskSpd.
4. Stop Cinesys Storage Diagnostics.
5. Record DiskSpd throughput, IOPS, average latency, and latency percentiles.
6. Use PerfMon to locate throughput collapses, latency spikes, queue growth, TCP/network changes, CPU/DPC activity, and memory pressure.
7. Inspect the same time interval in WPA/ETW for I/O, process/thread, CPU scheduling, DPC/ISR, and driver behavior.
8. Change one workload variable at a time when comparing tests.

The goal is not simply the highest benchmark number. The goal is to understand how the storage path responds to a controlled workload and identify where performance stops scaling or becomes unstable.

## Future work
- Cinesys custom `.wprp` with explicitly tuned ETW buffers and storage/SMB/iSCSI providers.
- Cinesys WPA view profile (`.wpaProfile`) with prebuilt storage-analysis layouts.
- Automated BLG event detection that emits timestamps/regions-of-interest for WPA.
- Native PLA diagnostic rules/report integration.
