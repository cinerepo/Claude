﻿[CmdletBinding()]
param([Parameter(Mandatory=$true)][string]$Etl)
if(!(Test-Path $Etl)){throw "ETL not found: $Etl"}
$wpa = @(
 "$env:ProgramFiles\Windows Kits\10\Windows Performance Toolkit\wpa.exe",
 "${env:ProgramFiles(x86)}\Windows Kits\10\Windows Performance Toolkit\wpa.exe"
) | Where-Object { $_ -and (Test-Path $_) } | Select-Object -First 1
if(!$wpa){
    throw "WPA.exe was not found. Install Windows Performance Analyzer from the Windows Performance Toolkit/ADK."
}
Start-Process $wpa -ArgumentList ('"{0}"' -f (Resolve-Path $Etl))
