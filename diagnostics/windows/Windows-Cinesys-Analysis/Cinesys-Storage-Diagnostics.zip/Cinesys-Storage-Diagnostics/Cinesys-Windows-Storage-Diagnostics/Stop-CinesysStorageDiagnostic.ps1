﻿#requires -RunAsAdministrator
[CmdletBinding()]
param([string]$Root = "C:\Cinesys\Storage-Diagnostic")

$ErrorActionPreference = "Continue"
$current = Join-Path $Root "CurrentCapture.txt"
if (!(Test-Path $current)) { throw "No CurrentCapture.txt found under $Root." }
$capture = (Get-Content $current -Raw).Trim()
if (!(Test-Path $capture)) { throw "Capture directory not found: $capture" }

$sets = @("Disk","Network","CPU","Memory","SMB-Client","SMB-Server","SMB-Direct")

# Stop WPR first so the exact end of the reproduced issue is preserved.
$etl = Join-Path $capture "Cinesys-Windows-Storage.etl"
Write-Host "Stopping and merging ETW trace..." -ForegroundColor Cyan
& wpr.exe -stop $etl "Cinesys Windows Storage Diagnostic"
$wprExit = $LASTEXITCODE

# Stop PerfMon collectors.
foreach ($short in $sets) {
    $name = "Cinesys Storage Diagnostic - $short"
    & logman stop "$name" 2>$null | Out-Null
}

# Post state snapshot.
$snapshot = @(
    (Join-Path $PSScriptRoot "Snapshot-State.ps1"),
    (Join-Path $Root "Snapshot-State.ps1")
) | Where-Object { Test-Path $_ } | Select-Object -First 1
if ($snapshot) {
    & $snapshot -OutputFile (Join-Path $capture "PostCapture-State.txt")
}

"Stopped=$(Get-Date -Format o)" | Add-Content (Join-Path $capture "Capture-Metadata.txt")
if (Test-Path $etl) {
    $size = (Get-Item $etl).Length
    "ETLBytes=$size" | Add-Content (Join-Path $capture "Capture-Metadata.txt")
}

Remove-Item $current -Force -ErrorAction SilentlyContinue

Write-Host ""
if ($wprExit -eq 0 -and (Test-Path $etl)) {
    Write-Host "Capture complete." -ForegroundColor Green
    Write-Host "ETL: $etl"
    Write-Host ""
    Write-Host "Open the ETL in Windows Performance Analyzer (WPA)."
} else {
    Write-Warning "PerfMon/state capture stopped, but WPR did not produce the expected ETL. Check WPR output above."
}
Write-Host "Capture directory: $capture"
