﻿[CmdletBinding()]
param([Parameter(Mandatory=$true)][string]$OutputFile)
$ErrorActionPreference = "Continue"
New-Item -ItemType Directory -Force -Path (Split-Path $OutputFile -Parent) | Out-Null
"=== CINESYS WINDOWS STORAGE DIAGNOSTIC STATE SNAPSHOT ===" | Set-Content $OutputFile
"Timestamp: $(Get-Date -Format o)" | Add-Content $OutputFile
"Computer: $env:COMPUTERNAME`n" | Add-Content $OutputFile
function Section($title,[scriptblock]$cmd){
 "`n===== $title =====" | Add-Content $OutputFile
 try{(& $cmd 2>&1|Out-String -Width 300)|Add-Content $OutputFile}catch{"ERROR: $_"|Add-Content $OutputFile}
}
Section "OS" { Get-ComputerInfo | Select WindowsProductName,WindowsVersion,OsBuildNumber,CsManufacturer,CsModel }
Section "PHYSICAL DISKS" { Get-Disk | Format-Table -AutoSize }
Section "VOLUMES" { Get-Volume | Format-Table -AutoSize }
Section "ISCSI SESSIONS" { Get-IscsiSession | Format-List * }
Section "ISCSI CONNECTIONS" { Get-IscsiConnection | Format-List * }
Section "MSDSM DEFAULT POLICY" { Get-MSDSMGlobalDefaultLoadBalancePolicy }
Section "MSDSM SUPPORTED HARDWARE" { Get-MSDSMSupportedHW | Format-Table -AutoSize }
Section "MPCLAIM DISKS" { mpclaim -s -d }
Section "MPCLAIM MPIO DISKS" { mpclaim -s -m }
Section "NETWORK ADAPTERS" { Get-NetAdapter | Sort Name | Format-Table -AutoSize }
Section "RSS" { Get-NetAdapterRss | Format-List * }
Section "RDMA" { Get-NetAdapterRdma | Format-Table -AutoSize }
Section "SMB CONNECTIONS" { Get-SmbConnection | Format-Table -AutoSize }
Section "SMB MULTICHANNEL" { Get-SmbMultichannelConnection | Format-Table -AutoSize }
Section "SMB CLIENT INTERFACES" { Get-SmbClientNetworkInterface | Format-Table -AutoSize }
Section "SMB SERVER INTERFACES" { Get-SmbServerNetworkInterface | Format-Table -AutoSize }
Section "SMB SESSIONS" { Get-SmbSession | Format-Table -AutoSize }
Section "SMB CLIENT CONFIG" { Get-SmbClientConfiguration | Format-List * }
Section "SMB SERVER CONFIG" { Get-SmbServerConfiguration | Format-List * }
Section "RECENT STORAGE SYSTEM EVENTS" {
 Get-WinEvent -FilterHashtable @{LogName='System';StartTime=(Get-Date).AddHours(-4)} |
 Where-Object {$_.ProviderName -match 'disk|stor|iscsi|mpio|ntfs|partmgr' -or $_.Id -in 9,20,27,39,43,55,98,129,153,157,507} |
 Select TimeCreated,Id,ProviderName,LevelDisplayName,Message | Format-List
}
